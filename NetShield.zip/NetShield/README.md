# NetShield v1.0 – Windows Personal Firewall & Network Traffic Monitoring System
*Defensive Network Security Platform* – academic project for authorized use on your own Windows 10/11 computer or lab.

NetShield **monitors, analyzes and manages**; Windows Defender Firewall **enforces**. It never disables the firewall, hides rules/processes, captures credentials, persists itself, or sends traffic. No AI/ML.

## Windows installation
1. Install Python 3.11+ from python.org (tick *Add python.exe to PATH*).
2. Verify: `python --version`
3. Create environment: `python -m venv venv`
4. Activate: `venv\Scripts\activate`
5. Install: `pip install -r requirements.txt`
6. Initialise DB: `python main.py --init-db` (optional `python main.py --check` prints environment checks)
7. Run: `python main.py`

**Administrator rights**: monitoring works as a normal user (some process paths may be unavailable). Creating/enabling/disabling/deleting firewall rules and TShark capture need an elevated terminal (*Run as administrator*). NetShield never elevates itself; without elevation it shows *"Administrator privileges are required for firewall rule management."*

Optional: Wireshark/TShark (https://www.wireshark.org) for external analysis; not required.

## Safe demonstration workflow
1. Start NetShield (as Administrator for step 8). 2. **Firewall** page: check status. 3. **Monitor → Start Monitoring**.
4. Open a browser and visit any site. 5. Watch the browser's TCP/443 rows; 6. identify the process (also on **Processes**).
7. **Rules → New Rule…**: Outbound, Block, TCP, Remote Port `4444`, Profile Private, name `Block_Test_Port`, description *Academic firewall testing rule*. Review the effect text, confirm → "Rule created successfully."
8. (Lab only) generate a connection to your own test listener on port 4444 (e.g. `python -m http.server 4444` on a second machine in your lab, then browse to it). The attempt is shown as **Blocked** and a *Blocked Connection* event/alert is raised.
9. View the event in **Alerts**; 10. **Rules → Delete** the temporary rule; 11. **Reports → Generate All**.
No malicious traffic is used at any point.

## Project layout
See `docs/04_System_Architecture.md`. Tests: `python -m pytest -q`. Academic documents: `docs/01…13`.

## Security notes
Input validation for every rule field; `subprocess` with argument lists only (`shell=False`), paths passed via environment variables to PowerShell; parameterised SQL (SQLAlchemy); CSV-injection and HTML escaping in reports; capture-file size/packet limits; audit log for sensitive actions; no secrets or API keys.
