"""NetShield configuration: constants, paths, default settings and validation."""
from __future__ import annotations

import os
from dataclasses import dataclass
from pathlib import Path

from dotenv import load_dotenv

APP_NAME = "NetShield"
APP_SUBTITLE = "Windows Personal Firewall & Network Traffic Monitoring System"
APP_VERSION = "1.0"
APP_TAGLINE = "Defensive Network Security Platform"

DISCLAIMER = ("Suspicious activity does not necessarily indicate malicious activity. "
              "Manual investigation is required.")
ADMIN_MSG_RULES = "Administrator privileges are required for firewall rule management."
ADMIN_MSG_GENERAL = "Some firewall management functions require Administrator privileges."

BASE_DIR = Path(__file__).resolve().parent
load_dotenv(BASE_DIR / ".env")


def _env_path(name: str, default: Path) -> Path:
    value = os.getenv(name)
    return Path(value).expanduser().resolve() if value else default


DATA_DIR = _env_path("NETSHIELD_DATA_DIR", BASE_DIR / "data")
LOG_DIR = _env_path("NETSHIELD_LOG_DIR", BASE_DIR / "logs")
REPORT_DIR = _env_path("NETSHIELD_REPORT_DIR", BASE_DIR / "reports")
EXPORT_DIR = _env_path("NETSHIELD_EXPORT_DIR", BASE_DIR / "exports")
DB_PATH = _env_path("NETSHIELD_DB_PATH", DATA_DIR / "netshield.db")
LOG_LEVEL = os.getenv("NETSHIELD_LOG_LEVEL", "INFO").upper()

MAX_PCAP_BYTES = 200 * 1024 * 1024      # refuse capture files larger than this
MAX_PCAP_PACKETS = 200_000              # stop parsing after this many packets
MAX_TSHARK_SECONDS = 300                # hard limit for optional lab captures
PERIODS = ("Last 5 minutes", "Last hour", "Today", "Last 7 days")


@dataclass(frozen=True)
class SettingSpec:
    label: str
    kind: str                # int | bool | choice | path | path_opt | str
    default: object
    lo: int | None = None
    hi: int | None = None
    choices: tuple = ()


def _env_int(name: str, default: int) -> int:
    try:
        return int(os.getenv(name, default))
    except ValueError:
        return default


SETTING_SPECS: dict[str, SettingSpec] = {
    "refresh_interval": SettingSpec("Refresh interval (s)", "int", _env_int("NETSHIELD_REFRESH_INTERVAL", 3), 1, 60),
    "log_retention_days": SettingSpec("Log retention (days)", "int", 30, 1, 365),
    "max_db_size_mb": SettingSpec("Maximum database size (MB)", "int", 500, 10, 5000),
    "max_display_rows": SettingSpec("Maximum displayed rows", "int", 2000, 100, 20000),
    "repeat_threshold": SettingSpec("Repeated-connection threshold", "int", 15, 3, 1000),
    "repeat_window_seconds": SettingSpec("Repeated-connection window (s)", "int", 120, 10, 3600),
    "burst_threshold": SettingSpec("Connection burst threshold (per cycle)", "int", 80, 10, 5000),
    "alert_cooldown_seconds": SettingSpec("Alert cool-down (s)", "int", 300, 10, 86400),
    "report_dir": SettingSpec("Report directory", "path", str(REPORT_DIR)),
    "wireshark_path": SettingSpec("Wireshark path", "path_opt", ""),
    "network_interface": SettingSpec("Network interface (blank = all)", "str", ""),
    "theme": SettingSpec("Theme", "choice", "dark", choices=("dark", "midnight")),
    "auto_start_monitoring": SettingSpec("Start monitoring automatically", "bool", False),
}


def default_settings() -> dict:
    return {k: s.default for k, s in SETTING_SPECS.items()}


def _to_bool(value) -> bool:
    if isinstance(value, bool):
        return value
    return str(value).strip().lower() in ("1", "true", "yes", "on")


def validate_settings(raw: dict) -> tuple[dict, list[str]]:
    """Return (clean_settings, errors). Invalid values fall back to defaults."""
    from app.utils.validators import ValidationError, validate_directory

    clean, errors = default_settings(), []
    for key, spec in SETTING_SPECS.items():
        if key not in raw:
            continue
        value = raw[key]
        try:
            if spec.kind == "int":
                n = int(str(value).strip())
                if not spec.lo <= n <= spec.hi:
                    raise ValueError(f"must be between {spec.lo} and {spec.hi}")
                clean[key] = n
            elif spec.kind == "bool":
                clean[key] = _to_bool(value)
            elif spec.kind == "choice":
                if value not in spec.choices:
                    raise ValueError(f"must be one of {', '.join(spec.choices)}")
                clean[key] = value
            elif spec.kind == "path":
                clean[key] = str(validate_directory(str(value)))
            elif spec.kind == "path_opt":
                text = str(value or "").strip()
                if text:
                    if any(ord(ch) < 32 for ch in text) or '"' in text or not text.lower().endswith(".exe"):
                        raise ValueError("must be a path to an .exe file")
                clean[key] = text
            else:  # str
                text = str(value or "").strip()
                if len(text) > 100 or any(ord(ch) < 32 for ch in text):
                    raise ValueError("invalid text")
                clean[key] = text
        except (ValueError, ValidationError) as exc:
            errors.append(f"{spec.label}: {exc}")
    return clean, errors
