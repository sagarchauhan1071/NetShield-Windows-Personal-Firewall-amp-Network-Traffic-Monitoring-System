"""NetShield entry point.

Usage:
    python main.py              start the GUI
    python main.py --init-db    create/verify the SQLite database and exit
    python main.py --check      print environment checks and exit
"""
from __future__ import annotations

import argparse
import sys

import config
from app.utils.logger import get_logger, setup_logging


def environment_report() -> int:
    from app.core.firewall import FirewallManager
    from app.core.monitor import get_network_interfaces
    from app.core.tools import detect_tools, is_admin, system_info

    print(f"{config.APP_NAME} v{config.APP_VERSION} – {config.APP_TAGLINE}")
    for k, v in system_info().items():
        print(f"{k:18}: {v}")
    if not is_admin():
        print(config.ADMIN_MSG_GENERAL)
    for t in detect_tools():
        print(f"{t.name:18}: {'Installed' if t.installed else 'Not installed'} {t.version} {t.path} {t.message}".rstrip())
    print("Firewall           :", {k: v for k, v in FirewallManager().get_status().items() if k != "overall"})
    print("Interfaces         :", ", ".join(f"{i['name']} ({i['status']})" for i in get_network_interfaces()))
    return 0


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(description=config.APP_SUBTITLE)
    ap.add_argument("--init-db", action="store_true", help="initialise the database and exit")
    ap.add_argument("--check", action="store_true", help="print environment checks and exit")
    args = ap.parse_args(argv)
    setup_logging(config.LOG_DIR, config.LOG_LEVEL)
    log = get_logger("main")

    if args.check:
        return environment_report()
    from app.context import create_context
    ctx = create_context()
    if args.init_db:
        print(f"Database ready: {ctx.db.path}")
        return 0

    from PySide6.QtWidgets import QApplication
    from app.ui.main_window import MainWindow
    from app.ui.theme import build_stylesheet

    app = QApplication(sys.argv)
    app.setApplicationName(config.APP_NAME)
    app.setStyleSheet(build_stylesheet(ctx.settings["theme"]))
    window = MainWindow(ctx)
    window.show()
    log.info("NetShield started (admin=%s)", ctx.admin)
    code = app.exec()
    ctx.db.dispose()
    return code


if __name__ == "__main__":
    sys.exit(main())
