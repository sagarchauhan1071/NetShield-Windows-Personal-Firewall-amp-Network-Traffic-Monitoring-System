import socket
import struct

import pytest

from app.services.pcapture_service import PcapError, analyze_pcap, decode_packet
from app.utils.validators import ValidationError


def eth_ipv4_tcp(src, dst, sport, dport, proto=6):
    l4 = struct.pack("!HHIIBBHHH", sport, dport, 0, 0, 5 << 4, 2, 0, 0, 0) if proto == 6 else struct.pack("!HHHH", sport, dport, 8, 0)
    ip = struct.pack("!BBHHHBBH4s4s", 0x45, 0, 20 + len(l4), 0, 0, 64, proto, 0, socket.inet_aton(src), socket.inet_aton(dst))
    return b"\x00" * 12 + b"\x08\x00" + ip + l4


def write_pcap(path, frames):
    with open(path, "wb") as f:
        f.write(struct.pack("<IHHiIII", 0xA1B2C3D4, 2, 4, 0, 0, 65535, 1))
        for i, fr in enumerate(frames):
            f.write(struct.pack("<IIII", 1700000000 + i, 0, len(fr), len(fr)) + fr)


def write_pcapng(path, frames):
    shb = struct.pack("<IIIHHqI", 0x0A0D0D0A, 28, 0x1A2B3C4D, 1, 0, -1, 28)
    idb = struct.pack("<IIHHII", 1, 20, 1, 0, 65535, 20)
    out = shb + idb
    for fr in frames:
        pad = (-len(fr)) % 4
        total = 32 + len(fr) + pad
        out += struct.pack("<IIIIIII", 6, total, 0, 0, 1000, len(fr), len(fr)) + fr + b"\x00" * pad + struct.pack("<I", total)
    path.write_bytes(out)


FRAMES = [eth_ipv4_tcp("10.0.0.2", "93.184.216.34", 50000, 443), eth_ipv4_tcp("10.0.0.2", "93.184.216.34", 50001, 443),
          eth_ipv4_tcp("10.0.0.2", "8.8.8.8", 5353, 53, proto=17), b"\x00" * 20]


def test_decode_packet():
    assert decode_packet(1, FRAMES[0]) == ("10.0.0.2", "93.184.216.34", 50000, 443, "TCP")
    assert decode_packet(1, FRAMES[2])[4] == "UDP"
    assert decode_packet(1, FRAMES[3]) is None


@pytest.mark.parametrize("writer,name,fmt", [(write_pcap, "a.pcap", "pcap"), (write_pcapng, "a.pcapng", "pcapng")])
def test_summary(tmp_path, writer, name, fmt):
    p = tmp_path / name
    writer(p, FRAMES)
    s = analyze_pcap(p)
    assert s.fmt == fmt and s.total_packets == 4 and s.parsed_packets == 3
    assert s.protocols["TCP"] == 2 and s.protocols["UDP"] == 1
    assert s.top_dest_ips[0] == ("93.184.216.34", 2)
    assert ("TCP/443", 2) in s.top_ports
    assert s.packets[0]["dst_port"] == 443


def test_rejects_bad_files(tmp_path):
    bad = tmp_path / "x.pcap"; bad.write_bytes(b"not a capture at all, just text")
    with pytest.raises(PcapError):
        analyze_pcap(bad)
    with pytest.raises(ValidationError):
        analyze_pcap(tmp_path / "missing.pcap")
    txt = tmp_path / "x.txt"; txt.write_text("x")
    with pytest.raises(ValidationError):
        analyze_pcap(txt)


def test_packet_limit(tmp_path):
    p = tmp_path / "a.pcap"; write_pcap(p, FRAMES * 5)
    s = analyze_pcap(p, max_packets=6)
    assert s.truncated and s.total_packets == 6
