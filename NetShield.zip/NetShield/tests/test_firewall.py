import pytest

from app.core.firewall import (AdminRequiredError, FirewallError, FirewallManager, build_add_rule_args, build_delete_args,
                               managed_name, parse_netsh_profiles, parse_profile_json, rule_matches_connection,
                               verdict_for, firewall_overall, describe_rule_effect)
from app.core.monitor import ConnectionInfo
from app.services.firewall_service import ConfirmationRequired, FirewallService
from app.utils.helpers import CommandResult
from app.utils.validators import ValidationError, validate_rule
from datetime import datetime

RULE = {"rule_name": "NetShield_Block_Test_Port", "direction": "Outbound", "action": "Block", "protocol": "TCP",
        "remote_port": "4444", "profile": "Private", "description": "Academic firewall testing rule"}


def conn(**kw):
    d = dict(pid=1, process_name="x.exe", exe_path=r"C:\x.exe", local_ip="10.0.0.2", local_port=50000,
             remote_ip="8.8.8.8", remote_port=4444, protocol="TCP", status="SYN_SENT", timestamp=datetime.now())
    d.update(kw)
    return ConnectionInfo(**d)


def test_add_rule_args_are_a_list_without_shell_metachar_concat():
    rule = validate_rule(RULE)
    args = build_add_rule_args(rule)
    assert isinstance(args, list) and args[0] == "netsh"
    assert "remoteport=4444" in args and "dir=out" in args and "action=block" in args and "profile=private" in args


def test_injection_in_values_rejected():
    for bad in ({"rule_name": "a&calc"}, {"description": 'x" & calc'}, {"remote_ip": "1.1.1.1; whoami"}):
        with pytest.raises(ValidationError):
            validate_rule({**RULE, **bad})


def test_managed_name_prefix():
    assert managed_name("Test") == "NetShield_Test"
    assert managed_name("NetShield_Test") == "NetShield_Test"
    with pytest.raises(ValidationError):
        managed_name("")


def test_parsers():
    assert parse_profile_json('[{"Name":"Domain","Enabled":"True"},{"Name":"Private","Enabled":"False"}]') == {"Domain": "ON", "Private": "OFF"}
    text = "Domain Profile Settings:\n----\nState                                 ON\nPrivate Profile Settings:\nState OFF\n"
    assert parse_netsh_profiles(text) == {"Domain": "ON", "Private": "OFF"}
    assert firewall_overall({"Domain": "ON", "Private": "OFF", "Public": "ON"}) == "PARTIAL"


def test_manager_requires_admin_and_prefix():
    m = FirewallManager(admin_check=lambda: False, runner=lambda a, **k: CommandResult(True, 0, "", ""))
    with pytest.raises(AdminRequiredError):
        m.create_rule(validate_rule(RULE))
    m2 = FirewallManager(admin_check=lambda: True, runner=lambda a, **k: CommandResult(True, 0, "", ""))
    with pytest.raises(FirewallError):
        m2.delete_rule("Windows_Core_Rule")


def test_matching_and_verdicts():
    rule = {**validate_rule(RULE), "id": 1}
    assert rule_matches_connection(rule, conn())
    assert not rule_matches_connection(rule, conn(remote_port=443))
    assert not rule_matches_connection(rule, conn(protocol="UDP"))
    assert verdict_for(rule, conn()) == "Blocked"
    assert verdict_for(rule, conn(status="ESTABLISHED")) == "Conflict"
    assert "BLOCK outbound" in describe_rule_effect(rule)


def test_service_flow(repos):
    calls = []
    mgr = FirewallManager(admin_check=lambda: True, runner=lambda a, **k: (calls.append(a), CommandResult(True, 0, "", ""))[1])
    svc = FirewallService(repos, mgr)
    with pytest.raises(ConfirmationRequired):
        svc.create_rule(RULE)
    saved = svc.create_rule({**RULE, "rule_name": "Block_Test_Port"}, confirmed=True)
    assert saved["rule_name"] == "NetShield_Block_Test_Port" and calls
    svc.set_enabled(saved["rule_name"], False, confirmed=True)
    assert repos.rules.get(saved["rule_name"])["enabled"] is False
    svc.delete_rule(saved["rule_name"], confirmed=True)
    assert repos.rules.get(saved["rule_name"]) is None
    actions = [a["action"] for a in repos.audit.list()]
    assert {"Firewall rule created", "Firewall rule deleted", "Firewall rule disabled"} <= set(actions)


def test_failed_netsh_does_not_store_rule(repos):
    mgr = FirewallManager(admin_check=lambda: True, runner=lambda a, **k: CommandResult(False, 1, "", "denied"))
    with pytest.raises(FirewallError):
        FirewallService(repos, mgr).create_rule(RULE, confirmed=True)
    assert repos.rules.list() == []
