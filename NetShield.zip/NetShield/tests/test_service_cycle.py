from datetime import datetime

from app.core.monitor import ConnectionInfo
from app.services.connection_service import MonitoringService
from config import default_settings


def conn(i, **kw):
    d = dict(pid=5, process_name="app.exe", exe_path=r"C:\app.exe", local_ip="10.0.0.2", local_port=50000 + i,
             remote_ip="8.8.8.8", remote_port=4444, protocol="TCP", status="SYN_SENT", timestamp=datetime.now())
    d.update(kw)
    return ConnectionInfo(**d)


def test_cycle_logs_new_connections_once_and_applies_block_rule(repos):
    repos.rules.add({"rule_name": "NetShield_B", "direction": "Outbound", "action": "Block", "protocol": "TCP",
                     "remote_port": "4444", "profile": "Any", "enabled": True})
    svc = MonitoringService(repos, default_settings())
    first = svc.run_cycle(lambda cache: [conn(0, remote_port=443, status="ESTABLISHED")])
    assert first.established == 1
    res = svc.run_cycle(lambda cache: [conn(0, remote_port=443, status="ESTABLISHED"), conn(1)])
    blocked = [r for r in res.rows if r["action"] == "Blocked"]
    assert len(blocked) == 1 and blocked[0]["rule"] == "NetShield_B"
    svc.run_cycle(lambda cache: [conn(0, remote_port=443, status="ESTABLISHED"), conn(1)])
    assert repos.connections.count() == 2                               # no duplicate log rows
    assert repos.connections.count({"action": "Blocked"}) == 1
    assert any(e["event_type"] == "Blocked Connection" for e in repos.events.list())
