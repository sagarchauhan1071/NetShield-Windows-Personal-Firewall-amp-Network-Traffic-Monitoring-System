import csv
import json

from app.services.report_service import ReportService, _csv_safe, build_recommendations
from config import default_settings

LIVE = [{"process_name": "chrome.exe", "pid": 1, "local_ip": "10.0.0.2", "local_port": 5000, "remote_ip": "8.8.8.8",
         "remote_port": 443, "protocol": "TCP", "status": "ESTABLISHED"},
        {"process_name": "svc.exe", "pid": 2, "local_ip": "0.0.0.0", "local_port": 135, "remote_ip": "", "remote_port": 0,
         "protocol": "TCP", "status": "LISTEN"}]


def svc(repos, tmp_path):
    s = default_settings(); s["report_dir"] = str(tmp_path)
    return ReportService(repos, s, lambda: {"Domain": "OFF", "Private": "ON", "Public": "ON"})


def test_all_formats(repos, tmp_path):
    service = svc(repos, tmp_path)
    for fmt in ("json", "csv", "html", "pdf"):
        p = service.generate(fmt, "Today", LIVE)
        assert p.exists() and p.stat().st_size > 100
    assert len(repos.reports.list()) == 4
    assert any(a["action"] == "Report generated" for a in repos.audit.list())


def test_report_content_and_language(repos, tmp_path):
    service = svc(repos, tmp_path)
    data = json.loads(service.generate("json", "Today", LIVE).read_text())
    titles = [s["title"] for s in data["sections"]]
    assert len(titles) == 13 and titles[0].startswith("1. Executive Summary") and titles[-1].startswith("13. Appendix")
    text = json.dumps(data).lower()
    assert "malware detected" not in text and "manual investigation is required" in text
    assert "disabled" in text                                           # firewall recommendation


def test_csv_injection_guard(repos, tmp_path):
    assert _csv_safe("=cmd|' /C calc'!A0").startswith("'")
    service = svc(repos, tmp_path)
    repos.events.add({"event_type": "Suspicious Connection", "severity": "LOW", "description": "=HYPERLINK(\"x\")"})
    rows = list(csv.reader(open(service.generate("csv", "Today", LIVE), encoding="utf-8-sig")))
    assert not any(c.startswith("=") for r in rows for c in r)


def test_html_escapes(repos, tmp_path):
    repos.events.add({"event_type": "Suspicious Connection", "severity": "LOW", "description": "<script>alert(1)</script>"})
    html = svc(repos, tmp_path).generate("html", "Today", LIVE).read_text()
    assert "<script>alert" not in html


def test_recommendations():
    recs = build_recommendations({"Domain": "OFF"}, False, 100, 3, 0)
    assert len(recs) >= 5
