import sys
from pathlib import Path

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from app.database.database import Database  # noqa: E402
from app.database.repositories import Repos  # noqa: E402


@pytest.fixture()
def repos(tmp_path):
    db = Database(tmp_path / "test.db")
    db.init_db()
    yield Repos(db)
    db.dispose()
