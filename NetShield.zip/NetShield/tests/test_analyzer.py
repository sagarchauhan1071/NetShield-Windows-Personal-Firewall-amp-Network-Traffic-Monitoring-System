from datetime import datetime

from app.core.alerts import AlertEngine
from app.core.analyzer import (SecurityAnalyzer, Severity, classify_destination, classify_listening,
                               firewall_status_findings, severity_to_risk)
from app.core.monitor import ConnectionInfo
from config import default_settings


def c(i=0, **kw):
    d = dict(pid=10, process_name="app.exe", exe_path=r"C:\app.exe", local_ip="10.0.0.2", local_port=50000 + i,
             remote_ip="93.184.216.34", remote_port=443, protocol="TCP", status="ESTABLISHED", timestamp=datetime.now())
    d.update(kw)
    return ConnectionInfo(**d)


def test_severity_classification():
    assert classify_destination("8.8.8.8", 4444)[0] == Severity.MEDIUM
    assert classify_destination("8.8.8.8", 443) is None
    assert classify_destination("192.168.1.1", 4444) is None          # private: not an indicator
    assert classify_destination("8.8.8.8", 8123)[0] == Severity.INFO
    assert classify_listening("127.0.0.1", 9999) == Severity.LOW
    assert classify_listening("0.0.0.0", 9999) == Severity.MEDIUM
    assert severity_to_risk(Severity.HIGH) == "High"


def test_new_application_and_listening_port_after_baseline():
    a = SecurityAnalyzer(default_settings(), known_processes={"old.exe"})
    assert not [f for f in a.analyze([c(process_name="old.exe")]) if f.event_type == "Unknown Process"]
    f = a.analyze([c(process_name="old.exe"), c(1, process_name="new.exe")])
    assert any(x.event_type == "Unknown Process" and "new.exe" in x.description for x in f)
    listen = c(2, process_name="old.exe", status="LISTEN", remote_ip="", remote_port=0, local_ip="0.0.0.0", local_port=9999)
    assert any(x.event_type == "New Listening Port" for x in a.analyze([c(process_name="old.exe"), listen]))
    assert not a.analyze([c(process_name="old.exe"), listen])          # reported once only


def test_first_cycle_is_silent_baseline():
    a = SecurityAnalyzer(default_settings())
    listen = c(status="LISTEN", remote_ip="", remote_port=0, local_ip="0.0.0.0", local_port=9999)
    assert a.analyze([listen, c(1)]) == []


def test_repeated_connections():
    s = default_settings(); s["repeat_threshold"] = 5
    a = SecurityAnalyzer(s, known_processes={"app.exe"})
    a.analyze([c(0)])
    found = []
    for i in range(1, 8):
        found += a.analyze([c(j) for j in range(i + 1)])
    assert any(f.event_type == "Repeated Connection" for f in found)


def test_burst_and_watchlist():
    s = default_settings(); s["burst_threshold"] = 10
    a = SecurityAnalyzer(s, known_processes={"app.exe"})
    a.analyze([c(0)])
    f = a.analyze([c(i, status="SYN_SENT", remote_port=4444) for i in range(20)])
    assert any(x.severity == Severity.HIGH and "Large number" in x.description for x in f)
    assert any("watch list" in x.description for x in f)


def test_block_rule_match_findings():
    a = SecurityAnalyzer(default_settings(), known_processes={"app.exe"})
    a.analyze([])
    conn = c(status="SYN_SENT", remote_port=4444)
    rule = {"id": 1, "rule_name": "NetShield_B", "action": "Block"}
    f = a.analyze([conn], {conn.key: {"rule": rule, "verdict": "Blocked"}})
    assert any(x.event_type == "Blocked Connection" for x in f)


def test_firewall_findings():
    f = firewall_status_findings(None, {"Domain": "OFF", "Private": "OFF", "Public": "OFF"})
    assert f[0].severity == Severity.CRITICAL and "disabled" in f[0].description
    f = firewall_status_findings({"Domain": "ON", "Private": "ON", "Public": "ON"}, {"Domain": "ON", "Private": "OFF", "Public": "ON"})
    assert any("changed from ON to OFF" in x.description for x in f)
    assert firewall_status_findings(None, {"Domain": "ON", "Private": "ON", "Public": "ON"}) == []


def test_alert_engine_dedup_and_persistence(repos):
    t = [1000.0]
    eng = AlertEngine(repos.events, repos.alerts, cooldown=60, clock=lambda: t[0])
    a = SecurityAnalyzer(default_settings(), known_processes={"x"})
    fs = firewall_status_findings(None, {"Domain": "OFF", "Private": "ON", "Public": "ON"})
    assert len(eng.process(fs)) == 1
    assert eng.process(fs) == []                                       # cooldown
    assert repos.alerts.count_new() == 1
    alert = repos.alerts.list()[0]
    repos.alerts.set_status(alert["id"], "Acknowledged")
    assert repos.alerts.count_new() == 0
    assert repos.alerts.get_with_event(alert["id"])["event"]["status"] == "Acknowledged"
