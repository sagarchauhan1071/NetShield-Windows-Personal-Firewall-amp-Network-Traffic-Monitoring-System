import pytest

from app.utils.helpers import classify_ip
from app.utils.validators import *  # noqa: F403


@pytest.mark.parametrize("bad", ["999.999.999.999", "", "abc", "1.2.3"])
def test_invalid_ip(bad):
    with pytest.raises(ValidationError):
        validate_ip(bad)


def test_valid_ip():
    assert validate_ip("192.168.1.10") == "192.168.1.10"
    assert validate_ip("::1") == "::1"


@pytest.mark.parametrize("bad", [70000, 0, -1, "abc", "", True, "1.5"])
def test_invalid_port(bad):
    with pytest.raises(ValidationError):
        validate_port(bad)


def test_port_spec():
    assert validate_port_spec("80, 443,1000-2000") == "80,443,1000-2000"
    assert validate_port_spec("any") == ""
    for bad in ("2000-1000", "80,,443", "70000"):
        with pytest.raises(ValidationError):
            validate_port_spec(bad)


def test_ip_spec():
    assert validate_ip_spec("10.0.0.0/8,1.1.1.1") == "10.0.0.0/8,1.1.1.1"
    with pytest.raises(ValidationError):
        validate_ip_spec("10.0.0.0/99")


def test_protocol_and_profile():
    assert validate_protocol("icmp") == "ICMPv4"
    with pytest.raises(ValidationError):
        validate_protocol("gre")
    assert validate_profile("private") == "Private"
    assert validate_profile("domain,private,public") == "Any"
    with pytest.raises(ValidationError):
        validate_profile("guest")


@pytest.mark.parametrize("bad", ["", "  ", "a b", 'x"y', "name;calc", "-start", "a" * 70])
def test_invalid_rule_name(bad):
    with pytest.raises(ValidationError):
        validate_rule_name(bad)


@pytest.mark.parametrize("bad", ["notapath", "chrome.exe", r"C:\Windows\evil.bat", r"C:\a\..\b.exe", r"C:\a|b.exe", "\\\\server\\x.exe"])
def test_invalid_program_path(bad):
    with pytest.raises(ValidationError):
        validate_program_path(bad)


def test_valid_program_path():
    assert validate_program_path(r"C:\Program Files\App\app.exe").endswith("app.exe")
    assert validate_program_path("") == ""


def test_ports_require_tcp_udp():
    with pytest.raises(ValidationError):
        validate_rule({"rule_name": "x", "direction": "Outbound", "action": "Block", "protocol": "ICMPv4", "remote_port": "80"})


def test_classify_ip():
    assert classify_ip("127.0.0.1") == "Loopback"
    assert classify_ip("169.254.1.1") == "Link-local"
    assert classify_ip("192.168.0.4") == "Private IP"
    assert classify_ip("8.8.8.8") == "Public IP"
    assert classify_ip("nonsense") == "Invalid"
