from datetime import datetime, timedelta

from app.database.repositories import DuplicateRuleError
import pytest


def row(**kw):
    d = dict(timestamp=datetime.now(), process_name="chrome.exe", pid=1, local_ip="10.0.0.2", local_port=50000,
             remote_ip="8.8.8.8", remote_port=443, protocol="TCP", status="ESTABLISHED", action="Observed",
             rule="", risk_level="Normal")
    d.update(kw)
    return d


def test_connection_insert_filter_pagination(repos):
    repos.connections.add_many([row(remote_port=443 + i % 2, process_name="a.exe" if i % 2 else "b.exe") for i in range(30)])
    rows, total = repos.connections.query({"process": "a.exe"}, 1, 10)
    assert total == 15 and len(rows) == 10
    assert repos.connections.count({"port": "444"}) == 15
    assert repos.connections.count({"ip": "8.8"}) == 30
    assert repos.connections.count({"process": "%"}) == 0              # wildcard characters are escaped
    assert repos.connections.count({"protocol": "UDP"}) == 0


def test_stats_and_top(repos):
    repos.connections.add_many([row(), row(protocol="UDP", remote_ip="1.1.1.1"), row(status="LISTEN", remote_ip="", remote_port=0)])
    s = repos.connections.stats(datetime.now() - timedelta(minutes=5))
    assert s["total"] == 3 and s["tcp"] == 2 and s["udp"] == 1 and s["listening"] == 1 and s["unique_remote_ips"] == 2
    assert repos.connections.top("remote_port", datetime.now() - timedelta(hours=1))[0] == (443, 2)


def test_rules_and_duplicates(repos):
    repos.rules.add({"rule_name": "NetShield_A", "direction": "Outbound", "action": "Block", "protocol": "TCP"})
    with pytest.raises(DuplicateRuleError):
        repos.rules.add({"rule_name": "NetShield_A", "direction": "Outbound", "action": "Block"})
    assert len(repos.rules.list_enabled()) == 1
    repos.rules.set_enabled("NetShield_A", False)
    assert repos.rules.list_enabled() == []


def test_processes_upsert_and_settings(repos):
    ids = repos.processes.upsert_many([{"name": "a.exe", "exe_path": "", "pid": 1, "connection_count": 2}])
    ids2 = repos.processes.upsert_many([{"name": "a.exe", "exe_path": "", "pid": 1, "connection_count": 3}])
    assert ids == ids2 and repos.processes.known_names() == {"a.exe"}
    repos.settings.set_many({"theme": "dark"})
    assert repos.settings.get_all() == {"theme": "dark"}


def test_cleanup_retention(repos):
    repos.connections.add_many([row(timestamp=datetime.now() - timedelta(days=40)), row()])
    removed = repos.db.cleanup(30, 500)
    assert removed["connections"] == 1 and repos.connections.count() == 1


def test_timeline(repos):
    repos.events.add({"event_type": "Suspicious Connection", "severity": "LOW", "description": "x"})
    assert sum(n for _, n in repos.events.timeline(datetime.now() - timedelta(hours=1))) == 1
