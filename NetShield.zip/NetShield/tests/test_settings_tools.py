import pytest

from app.core import tools
from app.core.tools import ToolInfo, detect_tools, detect_wireshark
from config import default_settings, validate_settings


def test_defaults_valid():
    clean, errors = validate_settings(default_settings())
    assert errors == [] and clean["refresh_interval"] == 3


@pytest.mark.parametrize("key,val", [("refresh_interval", 0), ("refresh_interval", "abc"), ("log_retention_days", 9999),
                                      ("theme", "neon"), ("wireshark_path", "C:\\evil.bat")])
def test_invalid_settings_rejected(key, val):
    clean, errors = validate_settings({key: val})
    assert errors and clean[key] == default_settings()[key]


def test_bool_parsing():
    assert validate_settings({"auto_start_monitoring": "true"})[0]["auto_start_monitoring"] is True
    assert validate_settings({"auto_start_monitoring": "no"})[0]["auto_start_monitoring"] is False


def test_tool_detection_never_crashes(monkeypatch):
    monkeypatch.setattr(tools.shutil, "which", lambda n: None)
    monkeypatch.setattr(tools.os.path, "isfile", lambda p: False)
    ws = detect_wireshark()
    assert isinstance(ws, ToolInfo) and not ws.installed and "was not detected" in ws.message
    names = [t.name for t in detect_tools()]
    assert names == ["Python", "Windows", "Wireshark", "TShark"]
    assert detect_tools()[0].installed


def test_admin_detection_returns_bool():
    assert tools.is_admin() in (True, False)
