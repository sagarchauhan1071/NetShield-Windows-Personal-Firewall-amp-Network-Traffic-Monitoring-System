import socket
from types import SimpleNamespace as NS

from app.core.monitor import ProcessCache, normalize_status, parse_connection, protocol_of


class FakeCache:
    def lookup(self, pid):
        return ("chrome.exe", r"C:\Program Files\Google\Chrome\chrome.exe")


def mk(status="ESTABLISHED", kind=socket.SOCK_STREAM, raddr=NS(ip="142.250.1.1", port=443)):
    return NS(laddr=NS(ip="192.168.1.10", port=52134), raddr=raddr, status=status, type=kind, pid=1234)


def test_parse_established():
    c = parse_connection(mk(), FakeCache())
    assert (c.process_name, c.pid, c.protocol, c.status) == ("chrome.exe", 1234, "TCP", "ESTABLISHED")
    assert (c.local_ip, c.local_port, c.remote_ip, c.remote_port) == ("192.168.1.10", 52134, "142.250.1.1", 443)


def test_parse_listen_and_udp_without_remote():
    c = parse_connection(mk("LISTEN", raddr=()), FakeCache())
    assert c.remote_ip == "" and c.remote_port == 0 and c.status == "LISTEN"
    assert parse_connection(mk("NONE", socket.SOCK_DGRAM, ()), FakeCache()).protocol == "UDP"


def test_status_normalisation():
    assert normalize_status("SYN_RECV") == "SYN_RECEIVED"
    assert normalize_status("CLOSE") == "CLOSED"
    assert normalize_status("") == "UNKNOWN"


def test_protocol_other():
    assert protocol_of(NS(type=99)) == "OTHER"


def test_process_cache_handles_missing_pid():
    cache = ProcessCache()
    assert cache.lookup(None)[0] == "Unknown"
    assert cache.lookup(0)[0] == "System Idle Process"
    assert cache.lookup(2**22 + 12345)[0].startswith("Unknown")
