"""Logging setup (rotating file + console)."""
from __future__ import annotations

import logging
import logging.handlers
from pathlib import Path

_configured = False


def setup_logging(log_dir, level: str = "INFO") -> None:
    global _configured
    if _configured:
        return
    Path(log_dir).mkdir(parents=True, exist_ok=True)
    root = logging.getLogger("netshield")
    root.setLevel(getattr(logging, str(level).upper(), logging.INFO))
    fmt = logging.Formatter("%(asctime)s [%(levelname)s] %(name)s: %(message)s")
    fh = logging.handlers.RotatingFileHandler(Path(log_dir) / "netshield.log", maxBytes=1_000_000,
                                              backupCount=5, encoding="utf-8")
    fh.setFormatter(fmt)
    ch = logging.StreamHandler()
    ch.setFormatter(fmt)
    root.addHandler(fh)
    root.addHandler(ch)
    _configured = True


def get_logger(name: str) -> logging.Logger:
    return logging.getLogger(f"netshield.{name}")
