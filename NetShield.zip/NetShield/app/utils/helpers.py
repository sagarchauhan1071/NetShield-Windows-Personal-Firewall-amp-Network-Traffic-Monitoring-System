"""Shared helpers: safe subprocess execution, IP classification, time periods, signatures."""
from __future__ import annotations

import ipaddress
import json
import os
import re
import socket
import subprocess
from dataclasses import dataclass
from datetime import datetime, timedelta
from pathlib import Path

from app.utils.validators import ValidationError, validate_program_path


@dataclass
class CommandResult:
    ok: bool
    returncode: int
    stdout: str
    stderr: str


def run_command(args, timeout: int = 20, env_extra: dict | None = None) -> CommandResult:
    """Run an external program safely: argument list only, never a shell."""
    if not isinstance(args, (list, tuple)) or not args or not all(isinstance(a, str) for a in args):
        raise TypeError("args must be a non-empty list of strings")
    kwargs = dict(capture_output=True, text=True, timeout=timeout, shell=False, errors="replace")
    if os.name == "nt":
        kwargs["encoding"] = "oem"
        kwargs["creationflags"] = getattr(subprocess, "CREATE_NO_WINDOW", 0)
    if env_extra:
        kwargs["env"] = {**os.environ, **env_extra}
    try:
        proc = subprocess.run(list(args), **kwargs)
    except FileNotFoundError:
        return CommandResult(False, 127, "", f"Executable not found: {args[0]}")
    except subprocess.TimeoutExpired:
        return CommandResult(False, 124, "", "Command timed out")
    except OSError as exc:
        return CommandResult(False, 1, "", str(exc))
    return CommandResult(proc.returncode == 0, proc.returncode, proc.stdout or "", proc.stderr or "")


def classify_ip(value) -> str:
    if not value:
        return "None"
    try:
        addr = ipaddress.ip_address(str(value).split("%")[0])
    except ValueError:
        return "Invalid"
    if addr.is_unspecified:
        return "Unspecified"
    if addr.is_loopback:
        return "Loopback"
    if addr.is_link_local:
        return "Link-local"
    if addr.is_multicast:
        return "Multicast"
    if addr.is_private:
        return "Private IP"
    return "Public IP" if addr.is_global else "Reserved"


def is_public_ip(value) -> bool:
    return classify_ip(value) == "Public IP"


def period_start(label: str, now: datetime | None = None) -> datetime:
    now = now or datetime.now()
    if label == "Last 5 minutes":
        return now - timedelta(minutes=5)
    if label == "Last hour":
        return now - timedelta(hours=1)
    if label == "Last 7 days":
        return now - timedelta(days=7)
    return now.replace(hour=0, minute=0, second=0, microsecond=0)  # Today


def human_bytes(n) -> str:
    n = float(n or 0)
    for unit in ("B", "KB", "MB", "GB", "TB"):
        if n < 1024 or unit == "TB":
            return f"{n:.0f} {unit}" if unit == "B" else f"{n:.1f} {unit}"
        n /= 1024
    return str(n)


def truncate(text, limit: int = 60) -> str:
    text = "" if text is None else str(text)
    return text if len(text) <= limit else text[: limit - 1] + "…"


_SIG_CMD = ("Get-AuthenticodeSignature -LiteralPath $env:NETSHIELD_TARGET | Select-Object "
            "@{n='Status';e={[string]$_.Status}}, @{n='Subject';e={$_.SignerCertificate.Subject}} "
            "| ConvertTo-Json -Compress")


def trust_label(file_exists: bool, status: str) -> str:
    if not file_exists:
        return "Executable not found – Requires Investigation"
    if status == "Valid":
        return "Signed – signature valid"
    if status == "NotSigned":
        return "Unsigned – Unknown / Requires Investigation"
    if status == "Unavailable":
        return "Signature check unavailable"
    return "Unknown / Requires Investigation"


def get_signature_info(path: str) -> dict:
    """Existence + Authenticode status. The path is passed via environment variable, never interpolated."""
    info = {"file_exists": False, "signature_status": "Unavailable", "publisher": "", "trust": ""}
    try:
        clean = validate_program_path(path)
    except ValidationError:
        info["trust"] = "Invalid path – Requires Investigation"
        return info
    if not clean:
        info["trust"] = "Executable path unknown – Requires Investigation"
        return info
    info["file_exists"] = os.path.isfile(clean)
    if os.name == "nt" and info["file_exists"]:
        res = run_command(["powershell", "-NoProfile", "-NonInteractive", "-Command", _SIG_CMD],
                          timeout=25, env_extra={"NETSHIELD_TARGET": clean})
        if res.ok and res.stdout.strip():
            try:
                data = json.loads(res.stdout)
                info["signature_status"] = data.get("Status") or "Unknown"
                m = re.search(r"CN=([^,]+)", data.get("Subject") or "")
                info["publisher"] = m.group(1).strip('" ') if m else ""
            except (ValueError, AttributeError):
                info["signature_status"] = "Unknown"
    info["trust"] = trust_label(info["file_exists"], info["signature_status"])
    return info


def reverse_dns(ip: str) -> str:
    """On-demand reverse lookup (only called when the user asks)."""
    try:
        return socket.gethostbyaddr(ip.split("%")[0])[0]
    except (OSError, ValueError):
        return ""


def now() -> datetime:
    return datetime.now()
