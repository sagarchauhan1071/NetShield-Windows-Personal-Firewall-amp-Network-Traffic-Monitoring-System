"""Input validation helpers (pure Python, no Qt, no side effects except validate_directory(create=True))."""
from __future__ import annotations

import ipaddress
import os
import re
from pathlib import Path, PureWindowsPath


class ValidationError(ValueError):
    """Raised when user-supplied input fails validation."""


PROTOCOLS = ("TCP", "UDP", "ICMPv4", "ICMPv6", "Any")
DIRECTIONS = ("Inbound", "Outbound")
ACTIONS = ("Allow", "Block")
PROFILES = ("Domain", "Private", "Public")
MAX_RULE_NAME = 64
_NAME_RE = re.compile(r"^[A-Za-z0-9][A-Za-z0-9_.\-]*$")
_BAD_PATH_CHARS = re.compile(r'[<>"|?*\x00-\x1f]')
_CTRL = re.compile(r"[\x00-\x1f\x7f]")


def validate_ip(value) -> str:
    text = "" if value is None else str(value).strip()
    if not text:
        raise ValidationError("IP address must not be empty")
    try:
        return str(ipaddress.ip_address(text))
    except ValueError:
        raise ValidationError(f"Invalid IP address: {text!r}") from None


def validate_port(value) -> int:
    if isinstance(value, bool):
        raise ValidationError("Port must be a number")
    try:
        number = int(str(value).strip())
    except ValueError:
        raise ValidationError(f"Port must be a number between 1 and 65535: {value!r}") from None
    if not 1 <= number <= 65535:
        raise ValidationError(f"Port must be between 1 and 65535: {value!r}")
    return number


def _is_any(text: str) -> bool:
    return text.strip().lower() in ("", "any", "*")


def validate_port_spec(value) -> str:
    """'' / Any, a port, a range 'a-b' or a comma list (max 20 items). Returns canonical text ('' = any)."""
    text = "" if value is None else str(value).strip()
    if _is_any(text):
        return ""
    parts = [p.strip() for p in text.split(",")]
    if len(parts) > 20:
        raise ValidationError("Too many port entries (max 20)")
    out = []
    for part in parts:
        if "-" in part:
            a, b = part.split("-", 1)
            lo, hi = validate_port(a), validate_port(b)
            if lo > hi:
                raise ValidationError(f"Invalid port range: {part!r}")
            out.append(f"{lo}-{hi}")
        else:
            out.append(str(validate_port(part)))
    return ",".join(out)


def validate_ip_spec(value) -> str:
    """'' / Any, an IP, CIDR, range 'a-b', or comma list. Returns canonical text ('' = any)."""
    text = "" if value is None else str(value).strip()
    if _is_any(text):
        return ""
    parts = [p.strip() for p in text.split(",")]
    if len(parts) > 20:
        raise ValidationError("Too many IP entries (max 20)")
    out = []
    for part in parts:
        try:
            if "/" in part:
                out.append(str(ipaddress.ip_network(part, strict=False)))
            elif "-" in part:
                a, b = (ipaddress.ip_address(x.strip()) for x in part.split("-", 1))
                if a.version != b.version or int(a) > int(b):
                    raise ValueError
                out.append(f"{a}-{b}")
            else:
                out.append(str(ipaddress.ip_address(part)))
        except ValueError:
            raise ValidationError(f"Invalid IP address, range or network: {part!r}") from None
    return ",".join(out)


def validate_protocol(value) -> str:
    mapping = {"tcp": "TCP", "udp": "UDP", "icmp": "ICMPv4", "icmpv4": "ICMPv4",
               "icmpv6": "ICMPv6", "any": "Any", "": "Any"}
    key = "" if value is None else str(value).strip().lower()
    if key not in mapping:
        raise ValidationError(f"Unsupported protocol: {value!r}")
    return mapping[key]


def validate_direction(value) -> str:
    key = str(value or "").strip().lower()
    for item in DIRECTIONS:
        if key == item.lower():
            return item
    raise ValidationError(f"Direction must be Inbound or Outbound: {value!r}")


def validate_action(value) -> str:
    key = str(value or "").strip().lower()
    for item in ACTIONS:
        if key == item.lower():
            return item
    raise ValidationError(f"Action must be Allow or Block: {value!r}")


def validate_profile(value) -> str:
    text = "" if value is None else str(value).strip().lower()
    if text in ("", "any", "all"):
        return "Any"
    chosen = set()
    for token in re.split(r"[,;\s]+", text):
        match = [p for p in PROFILES if p.lower() == token]
        if not match:
            raise ValidationError(f"Unknown firewall profile: {token!r}")
        chosen.add(match[0])
    ordered = [p for p in PROFILES if p in chosen]
    return "Any" if len(ordered) == 3 else ",".join(ordered)


def validate_rule_name(value) -> str:
    text = "" if value is None else str(value).strip()
    if not text:
        raise ValidationError("Rule name must not be empty")
    if len(text) > MAX_RULE_NAME or not _NAME_RE.match(text):
        raise ValidationError("Rule name may contain letters, digits, '_', '-' and '.' only "
                              f"(max {MAX_RULE_NAME} characters, must start with a letter or digit)")
    return text


def validate_description(value) -> str:
    text = "" if value is None else str(value).strip()
    if len(text) > 200:
        raise ValidationError("Description is limited to 200 characters")
    if _CTRL.search(text) or '"' in text:
        raise ValidationError("Description must not contain control characters or double quotes")
    return text


def validate_program_path(value, must_exist: bool = False) -> str:
    """Validate an absolute Windows .exe path. '' means 'all programs'."""
    text = "" if value is None else str(value).strip()
    if not text:
        return ""
    if len(text) > 260 or _BAD_PATH_CHARS.search(text):
        raise ValidationError(f"Invalid executable path: {text!r}")
    path = PureWindowsPath(text)
    if not path.is_absolute() or not path.drive or path.suffix.lower() != ".exe" or ".." in path.parts:
        raise ValidationError("Program path must be an absolute path to an .exe file")
    if must_exist and not os.path.isfile(text):
        raise ValidationError(f"Executable does not exist: {text!r}")
    return str(path)


def validate_rule(data: dict, must_exist_program: bool = False) -> dict:
    """Validate and normalise a firewall rule dict. Raises ValidationError."""
    protocol = validate_protocol(data.get("protocol") or "Any")
    local_port = validate_port_spec(data.get("local_port"))
    remote_port = validate_port_spec(data.get("remote_port"))
    if (local_port or remote_port) and protocol not in ("TCP", "UDP"):
        raise ValidationError("Ports can only be specified for TCP or UDP rules")
    return {
        "rule_name": validate_rule_name(data.get("rule_name")),
        "direction": validate_direction(data.get("direction")),
        "action": validate_action(data.get("action")),
        "protocol": protocol,
        "local_port": local_port,
        "remote_port": remote_port,
        "local_ip": validate_ip_spec(data.get("local_ip")),
        "remote_ip": validate_ip_spec(data.get("remote_ip")),
        "program_path": validate_program_path(data.get("program_path"), must_exist_program),
        "profile": validate_profile(data.get("profile")),
        "enabled": bool(data.get("enabled", True)),
        "description": validate_description(data.get("description")),
    }


def validate_file_size(path, max_bytes: int) -> int:
    p = Path(path)
    if not p.is_file():
        raise ValidationError(f"File not found: {p}")
    size = p.stat().st_size
    if size == 0:
        raise ValidationError("File is empty")
    if size > max_bytes:
        raise ValidationError(f"File too large ({size / 1048576:.1f} MB; limit {max_bytes / 1048576:.0f} MB)")
    return size


def validate_directory(value, create: bool = False) -> Path:
    text = "" if value is None else str(value).strip()
    if not text or _CTRL.search(text) or len(text) > 400:
        raise ValidationError("Invalid directory path")
    path = Path(text).expanduser().resolve()
    if create:
        try:
            path.mkdir(parents=True, exist_ok=True)
        except OSError as exc:
            raise ValidationError(f"Cannot create directory: {exc}") from None
        if not os.access(path, os.W_OK):
            raise ValidationError(f"Directory is not writable: {path}")
    return path


def safe_filename(name: str) -> str:
    return re.sub(r"[^A-Za-z0-9._-]", "_", str(name))[:100] or "file"
