"""Windows Defender Firewall integration (management layer only).

NetShield never replaces or disables the Windows firewall. Rules are created with
`netsh advfirewall` using argument lists (no shell), after strict validation.
Status is read through PowerShell (locale independent) with a netsh fallback.
"""
from __future__ import annotations

import ipaddress
import json
import os
import re

from app.core.tools import is_admin, is_windows
from app.utils.helpers import CommandResult, run_command
from app.utils.validators import (ValidationError, validate_profile, validate_rule_name)
from config import ADMIN_MSG_RULES

MANAGED_PREFIX = "NetShield_"
PROFILE_NAMES = ("Domain", "Private", "Public")

_PS_PROFILES = ("Get-NetFirewallProfile | Select-Object Name, "
                "@{n='Enabled';e={[string]$_.Enabled}} | ConvertTo-Json -Compress")
_PS_FIELDS = ("Select-Object DisplayName, @{n='Enabled';e={[string]$_.Enabled}}, "
              "@{n='Direction';e={[string]$_.Direction}}, @{n='Action';e={[string]$_.Action}}, "
              "@{n='Profile';e={[string]$_.Profile}}")


class FirewallError(Exception):
    pass


class AdminRequiredError(FirewallError):
    pass


def managed_name(name: str) -> str:
    """Validate and apply the NetShield_ prefix so managed rules are always identifiable."""
    clean = validate_rule_name(name)
    full = clean if clean.startswith(MANAGED_PREFIX) else MANAGED_PREFIX + clean
    return validate_rule_name(full)


# ----------------------------------------------------------------- status
def parse_profile_json(text: str) -> dict:
    data = json.loads(text)
    if isinstance(data, dict):
        data = [data]
    out = {}
    for item in data:
        name = str(item.get("Name", "")).capitalize()
        enabled = str(item.get("Enabled", "")).strip().lower() in ("true", "1")
        if name in PROFILE_NAMES:
            out[name] = "ON" if enabled else "OFF"
    return out


def parse_netsh_profiles(text: str) -> dict:
    out, current = {}, None
    for line in text.splitlines():
        s = line.strip()
        m = re.match(r"^(Domain|Private|Public) Profile Settings", s, re.I)
        if m:
            current = m.group(1).capitalize()
            continue
        m = re.match(r"^State\s+(ON|OFF)\b", s, re.I)
        if m and current:
            out[current] = m.group(1).upper()
    return out


def firewall_overall(status: dict) -> str:
    states = [status.get(p, "UNKNOWN") for p in PROFILE_NAMES]
    if all(s == "ON" for s in states):
        return "ON"
    if all(s == "OFF" for s in states):
        return "OFF"
    if any(s == "OFF" for s in states):
        return "PARTIAL"
    return "UNKNOWN"


# ----------------------------------------------------------------- rule helpers
def build_add_rule_args(rule: dict) -> list[str]:
    args = ["netsh", "advfirewall", "firewall", "add", "rule",
            f"name={rule['rule_name']}",
            f"dir={'in' if rule['direction'] == 'Inbound' else 'out'}",
            f"action={'allow' if rule['action'] == 'Allow' else 'block'}",
            f"enable={'yes' if rule.get('enabled', True) else 'no'}"]
    if rule["protocol"] != "Any":
        args.append(f"protocol={rule['protocol'].lower()}")
    for key, flag in (("local_port", "localport"), ("remote_port", "remoteport"),
                      ("local_ip", "localip"), ("remote_ip", "remoteip"), ("program_path", "program")):
        if rule.get(key):
            args.append(f"{flag}={rule[key]}")
    args.append(f"profile={rule['profile'].lower()}")
    if rule.get("description"):
        args.append(f"description={rule['description']}")
    return args


def build_delete_args(name: str) -> list[str]:
    return ["netsh", "advfirewall", "firewall", "delete", "rule", f"name={name}"]


def build_set_enabled_args(name: str, enabled: bool) -> list[str]:
    return ["netsh", "advfirewall", "firewall", "set", "rule", f"name={name}",
            "new", f"enable={'yes' if enabled else 'no'}"]


def describe_rule_effect(rule: dict) -> str:
    verb = "BLOCK" if rule["action"] == "Block" else "ALLOW"
    parts = [f"{verb} {rule['direction'].lower()} {'any protocol' if rule['protocol'] == 'Any' else rule['protocol']} traffic"]
    if rule.get("local_port"):
        parts.append(f"local port(s) {rule['local_port']}")
    if rule.get("remote_port"):
        parts.append(f"remote port(s) {rule['remote_port']}")
    if rule.get("local_ip"):
        parts.append(f"local address {rule['local_ip']}")
    if rule.get("remote_ip"):
        parts.append(f"remote address {rule['remote_ip']}")
    parts.append(f"program: {rule['program_path'] or 'all programs'}")
    parts.append(f"profile(s): {rule['profile']}")
    return (f"Rule '{rule['rule_name']}' will " + "; ".join(parts) + ".\n\n"
            "The rule is created in Windows Defender Firewall and enforced by Windows, not by NetShield. "
            "It will be visible in Windows Defender Firewall with Advanced Security and logged in the audit log.")


# ----------------------------------------------------------------- matching (observation only)
def _port_match(spec: str, port: int) -> bool:
    if not spec:
        return True
    for part in spec.split(","):
        if "-" in part:
            lo, hi = (int(x) for x in part.split("-", 1))
            if lo <= port <= hi:
                return True
        elif part.strip().isdigit() and int(part) == port:
            return True
    return False


def _ip_match(spec: str, ip: str) -> bool:
    if not spec:
        return True
    try:
        addr = ipaddress.ip_address(ip.split("%")[0])
    except ValueError:
        return False
    for part in spec.split(","):
        try:
            if "/" in part and addr in ipaddress.ip_network(part, strict=False):
                return True
            if "-" in part:
                a, b = (ipaddress.ip_address(x) for x in part.split("-", 1))
                if a.version == addr.version and int(a) <= int(addr) <= int(b):
                    return True
            elif ipaddress.ip_address(part) == addr:
                return True
        except ValueError:
            continue
    return False


def rule_matches_connection(rule: dict, conn, listening_ports: set | None = None) -> bool:
    """Does an enabled NetShield rule apply to this observed connection? (heuristic, direction-aware)"""
    if not rule.get("enabled", True):
        return False
    proto = rule.get("protocol", "Any")
    if proto not in ("Any", conn.protocol):
        return False
    has_remote = conn.status != "LISTEN" and conn.remote_port > 0
    if rule["direction"] == "Outbound":
        if not has_remote:
            return False
    else:
        is_inbound = conn.status == "LISTEN" or (listening_ports is not None and conn.local_port in listening_ports)
        if not is_inbound:
            return False
    if rule.get("program_path") and os.path.normcase(rule["program_path"]) != os.path.normcase(conn.exe_path or ""):
        return False
    if not _port_match(rule.get("local_port", ""), conn.local_port):
        return False
    if rule.get("remote_port") and not (has_remote and _port_match(rule["remote_port"], conn.remote_port)):
        return False
    if not _ip_match(rule.get("local_ip", ""), conn.local_ip):
        return False
    if rule.get("remote_ip") and not (has_remote and _ip_match(rule["remote_ip"], conn.remote_ip)):
        return False
    return True


def verdict_for(rule: dict, conn) -> str:
    """Blocked | Allowed | Conflict (established connection that matches a block rule) | Observed."""
    if rule["action"] == "Allow":
        return "Allowed"
    if conn.status == "LISTEN":
        return "Observed"
    return "Conflict" if conn.status == "ESTABLISHED" else "Blocked"


# ----------------------------------------------------------------- manager
class FirewallManager:
    def __init__(self, admin_check=is_admin, runner=run_command):
        self._admin_check, self._run = admin_check, runner

    def _require_admin(self) -> None:
        if not self._admin_check():
            raise AdminRequiredError(ADMIN_MSG_RULES)

    def get_status(self) -> dict:
        status = {p: "UNKNOWN" for p in PROFILE_NAMES}
        status["error"] = ""
        if not is_windows():
            status["error"] = "Not running on Windows"
            return status
        res = self._run(["powershell", "-NoProfile", "-NonInteractive", "-Command", _PS_PROFILES], timeout=20)
        parsed = {}
        if res.ok and res.stdout.strip():
            try:
                parsed = parse_profile_json(res.stdout)
            except (ValueError, AttributeError):
                parsed = {}
        if not parsed:
            res = self._run(["netsh", "advfirewall", "show", "allprofiles", "state"], timeout=15)
            parsed = parse_netsh_profiles(res.stdout) if res.ok else {}
            if not parsed:
                status["error"] = (res.stderr or "Unable to query Windows Defender Firewall").strip()
        status.update(parsed)
        status["overall"] = firewall_overall(status)
        return status

    def _check(self, res: CommandResult, what: str) -> CommandResult:
        if not res.ok:
            raise FirewallError(f"{what} failed: {(res.stdout + ' ' + res.stderr).strip() or 'unknown error'}")
        return res

    def create_rule(self, rule: dict) -> CommandResult:
        self._require_admin()
        return self._check(self._run(build_add_rule_args(rule)), "Creating rule")

    def delete_rule(self, name: str) -> CommandResult:
        self._require_admin()
        if not name.startswith(MANAGED_PREFIX):
            raise FirewallError("Only NetShield-managed rules can be deleted")
        validate_rule_name(name)
        return self._check(self._run(build_delete_args(name)), "Deleting rule")

    def set_enabled(self, name: str, enabled: bool) -> CommandResult:
        self._require_admin()
        if not name.startswith(MANAGED_PREFIX):
            raise FirewallError("Only NetShield-managed rules can be modified")
        validate_rule_name(name)
        return self._check(self._run(build_set_enabled_args(name, enabled)), "Updating rule")

    def query_rules(self, managed_only: bool = True, limit: int = 500) -> list[dict]:
        """Read-only listing of Windows rules (works without elevation on most systems)."""
        if not is_windows():
            return []
        where = "| Where-Object { $_.DisplayName -like 'NetShield_*' } " if managed_only else ""
        cmd = f"Get-NetFirewallRule {where}| {_PS_FIELDS} | Select-Object -First {int(limit)} | ConvertTo-Json -Compress"
        res = self._run(["powershell", "-NoProfile", "-NonInteractive", "-Command", cmd], timeout=40)
        if not res.ok or not res.stdout.strip():
            return []
        try:
            data = json.loads(res.stdout)
        except ValueError:
            return []
        return [data] if isinstance(data, dict) else list(data)
