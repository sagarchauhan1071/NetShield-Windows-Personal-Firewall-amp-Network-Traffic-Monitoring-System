"""Connection collector: psutil-based, process-aware, read-only."""
from __future__ import annotations

import socket
import time
from dataclasses import dataclass
from datetime import datetime

import psutil

CONNECTION_STATES = ("LISTEN", "ESTABLISHED", "TIME_WAIT", "CLOSE_WAIT", "SYN_SENT", "SYN_RECEIVED", "CLOSED")
_STATE_MAP = {"ESTABLISHED": "ESTABLISHED", "SYN_SENT": "SYN_SENT", "SYN_RECV": "SYN_RECEIVED",
              "FIN_WAIT1": "FIN_WAIT1", "FIN_WAIT2": "FIN_WAIT2", "TIME_WAIT": "TIME_WAIT",
              "CLOSE": "CLOSED", "DELETE_TCB": "CLOSED", "CLOSE_WAIT": "CLOSE_WAIT",
              "LAST_ACK": "LAST_ACK", "LISTEN": "LISTEN", "CLOSING": "CLOSING", "NONE": "NONE"}


class MonitorError(RuntimeError):
    """Raised when connections cannot be collected."""


def normalize_status(status) -> str:
    text = str(status or "").upper()
    return _STATE_MAP.get(text, text or "UNKNOWN")


def protocol_of(conn) -> str:
    kind = getattr(conn, "type", None)
    if kind == socket.SOCK_STREAM:
        return "TCP"
    if kind == socket.SOCK_DGRAM:
        return "UDP"
    return "OTHER"


@dataclass(frozen=True)
class ConnectionInfo:
    pid: int | None
    process_name: str
    exe_path: str
    local_ip: str
    local_port: int
    remote_ip: str
    remote_port: int
    protocol: str
    status: str
    timestamp: datetime

    @property
    def key(self) -> tuple:
        return (self.pid, self.protocol, self.local_ip, self.local_port, self.remote_ip, self.remote_port)

    def to_dict(self) -> dict:
        return {"pid": self.pid, "process_name": self.process_name, "exe_path": self.exe_path,
                "local_ip": self.local_ip, "local_port": self.local_port, "remote_ip": self.remote_ip,
                "remote_port": self.remote_port, "protocol": self.protocol, "status": self.status,
                "timestamp": self.timestamp}


class ProcessCache:
    """Small TTL cache so each cycle does not re-query every PID."""

    def __init__(self, ttl: float = 60.0, max_entries: int = 4096):
        self.ttl, self.max_entries = ttl, max_entries
        self._data: dict[int, tuple[str, str, float]] = {}

    def lookup(self, pid) -> tuple[str, str]:
        if pid is None:
            return "Unknown", ""
        if pid == 0:
            return "System Idle Process", ""
        now = time.monotonic()
        hit = self._data.get(pid)
        if hit and now - hit[2] < self.ttl:
            return hit[0], hit[1]
        try:
            proc = psutil.Process(pid)
            name = proc.name()
            try:
                exe = proc.exe() or ""
            except (psutil.AccessDenied, psutil.ZombieProcess, OSError):
                exe = ""
        except psutil.AccessDenied:
            name, exe = "Unknown (access denied)", ""
        except Exception:
            name, exe = "Unknown", ""
        if len(self._data) >= self.max_entries:
            self._data.clear()
        self._data[pid] = (name, exe, now)
        return name, exe


def _addr(addr) -> tuple[str, int]:
    if not addr:
        return "", 0
    ip = getattr(addr, "ip", None)
    port = getattr(addr, "port", None)
    if ip is None:
        ip, port = addr[0], addr[1]
    return str(ip), int(port)


def parse_connection(conn, cache, now: datetime | None = None) -> ConnectionInfo:
    """Convert a psutil connection tuple to a ConnectionInfo."""
    lip, lport = _addr(getattr(conn, "laddr", None))
    rip, rport = _addr(getattr(conn, "raddr", None))
    pid = getattr(conn, "pid", None)
    name, exe = cache.lookup(pid)
    status = normalize_status(getattr(conn, "status", ""))
    return ConnectionInfo(pid, name, exe, lip, lport, rip, rport, protocol_of(conn), status,
                          now or datetime.now())


def collect_connections(cache: ProcessCache | None = None, kind: str = "inet") -> list[ConnectionInfo]:
    cache = cache or ProcessCache()
    try:
        raw = psutil.net_connections(kind=kind)
    except psutil.AccessDenied as exc:
        raise MonitorError("Access denied while reading connections. Run NetShield as Administrator "
                           "for complete visibility.") from exc
    except OSError as exc:
        raise MonitorError(f"Unable to read connections: {exc}") from exc
    now = datetime.now()
    return [parse_connection(c, cache, now) for c in raw]


def get_network_interfaces() -> list[dict]:
    addrs, stats = psutil.net_if_addrs(), psutil.net_if_stats()
    try:
        io = psutil.net_io_counters(pernic=True)
    except Exception:
        io = {}
    rows = []
    for name, entries in addrs.items():
        mac = v4 = v6 = ""
        for a in entries:
            if a.family == psutil.AF_LINK:
                mac = a.address
            elif a.family == socket.AF_INET:
                v4 = a.address
            elif a.family == socket.AF_INET6:
                v6 = a.address.split("%")[0]
        st, c = stats.get(name), io.get(name)
        rows.append({"name": name, "mac": mac, "ipv4": v4, "ipv6": v6,
                     "status": "Connected" if st and st.isup else "Not Connected",
                     "speed": getattr(st, "speed", 0) if st else 0,
                     "bytes_sent": getattr(c, "bytes_sent", 0), "bytes_recv": getattr(c, "bytes_recv", 0),
                     "packets_sent": getattr(c, "packets_sent", 0), "packets_recv": getattr(c, "packets_recv", 0)})
    return sorted(rows, key=lambda r: r["name"].lower())


def interface_addresses(name: str) -> set[str]:
    try:
        return {a.address.split("%")[0] for a in psutil.net_if_addrs().get(name, [])
                if a.family in (socket.AF_INET, socket.AF_INET6)}
    except Exception:
        return set()


def network_status() -> str:
    try:
        up = [n for n, s in psutil.net_if_stats().items() if s.isup and not n.lower().startswith(("lo", "loopback"))]
    except Exception:
        return "Unknown"
    return f"Connected ({len(up)} interface{'s' if len(up) != 1 else ''} up)" if up else "No active network"
