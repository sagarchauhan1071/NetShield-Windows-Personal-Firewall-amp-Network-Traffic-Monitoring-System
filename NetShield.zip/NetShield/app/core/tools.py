"""Environment and tool detection (Windows version, admin rights, Python, Wireshark, TShark)."""
from __future__ import annotations

import os
import platform
import shutil
import sys
from dataclasses import dataclass, asdict

from app.utils.helpers import run_command


def is_windows() -> bool:
    return os.name == "nt"


def is_admin() -> bool:
    if not is_windows():
        return False
    try:
        import ctypes
        return bool(ctypes.windll.shell32.IsUserAnAdmin())
    except Exception:
        return False


def windows_version() -> str:
    if not is_windows():
        return f"{platform.system()} {platform.release()} (not Windows)"
    try:
        build = sys.getwindowsversion().build
        name = "Windows 11" if build >= 22000 else "Windows 10"
        return f"{name} (build {build})"
    except Exception:
        return platform.platform()


@dataclass
class ToolInfo:
    name: str
    installed: bool
    path: str = ""
    version: str = ""
    message: str = ""

    def to_dict(self) -> dict:
        return asdict(self)


_WIRESHARK_DIRS = (r"C:\Program Files\Wireshark", r"C:\Program Files (x86)\Wireshark")


def _find_exe(exe: str, configured: str = "") -> str:
    if configured and os.path.isfile(configured) and os.path.basename(configured).lower() == exe.lower():
        return configured
    found = shutil.which(exe)
    if found:
        return found
    for folder in _WIRESHARK_DIRS:
        candidate = os.path.join(folder, exe)
        if os.path.isfile(candidate):
            return candidate
    return ""


def detect_python() -> ToolInfo:
    ok = sys.version_info >= (3, 11)
    return ToolInfo("Python", True, sys.executable, platform.python_version(),
                    "" if ok else "Python 3.11 or newer is required.")


def detect_wireshark(configured: str = "") -> ToolInfo:
    if configured and not os.path.isfile(configured):
        configured = ""
    path = _find_exe("Wireshark.exe", configured if configured.lower().endswith("wireshark.exe") else "")
    if not path:
        return ToolInfo("Wireshark", False, message="Wireshark was not detected. Packet capture import "
                        "features requiring Wireshark are unavailable.")
    version = ""
    tshark = os.path.join(os.path.dirname(path), "tshark.exe")
    if os.path.isfile(tshark):
        version = _tshark_version(tshark)
    return ToolInfo("Wireshark", True, path, version, "Optional tool detected.")


def _tshark_version(path: str) -> str:
    res = run_command([path, "-v"], timeout=10)
    return res.stdout.splitlines()[0].strip() if res.ok and res.stdout else ""


def detect_tshark(configured: str = "") -> ToolInfo:
    hint = os.path.join(os.path.dirname(configured), "tshark.exe") if configured else ""
    path = _find_exe("tshark.exe", hint)
    if not path:
        return ToolInfo("TShark", False, message="TShark was not detected. Command-line capture is unavailable.")
    return ToolInfo("TShark", True, path, _tshark_version(path), "Optional tool detected.")


def detect_tools(settings: dict | None = None) -> list[ToolInfo]:
    configured = (settings or {}).get("wireshark_path", "")
    return [detect_python(), ToolInfo("Windows", is_windows(), "", windows_version(),
                                      "" if is_windows() else "NetShield is designed for Windows 10/11."),
            detect_wireshark(configured), detect_tshark(configured)]


def system_info() -> dict:
    return {"Hostname": platform.node(), "Operating system": windows_version(),
            "Architecture": platform.machine(), "Python": platform.python_version(),
            "Administrator": "Yes" if is_admin() else "No"}
