"""Transparent, rule-based traffic analysis. No AI / ML. Findings are indicators, not proof."""
from __future__ import annotations

import time
from collections import Counter, defaultdict, deque
from dataclasses import dataclass
from enum import IntEnum

from app.utils.helpers import classify_ip, is_public_ip

EVENT_TYPES = ("Suspicious Connection", "Blocked Connection", "New Listening Port", "Repeated Connection",
               "Firewall Rule Change", "Firewall Status Change", "Unknown Process", "Configuration Change")


class Severity(IntEnum):
    INFO = 0
    LOW = 1
    MEDIUM = 2
    HIGH = 3
    CRITICAL = 4

    @classmethod
    def from_name(cls, name: str) -> "Severity":
        return cls[str(name).upper()]


_RISK = {Severity.INFO: "Normal", Severity.LOW: "Low", Severity.MEDIUM: "Medium",
         Severity.HIGH: "High", Severity.CRITICAL: "Critical"}


def severity_to_risk(sev: Severity) -> str:
    return _RISK[sev]


@dataclass
class Finding:
    event_type: str
    severity: Severity
    description: str
    process: str = ""
    source_ip: str = ""
    destination_ip: str = ""
    port: int = 0
    protocol: str = ""
    key: str = ""
    conn_key: tuple | None = None
    rule_id: int | None = None
    cooldown: int | None = None


COMMON_PORTS = {20, 21, 22, 25, 53, 67, 68, 80, 110, 123, 143, 161, 389, 443, 445, 465, 514, 587, 636, 853,
                993, 995, 1900, 3389, 5222, 5228, 5353, 8080, 8443}
WATCHLIST_PORTS = {23: "Telnet (cleartext remote shell)", 1337: "commonly used by ad-hoc tools",
                   2323: "alternate Telnet", 4444: "default listener port of several remote-access/test tools",
                   5555: "ADB / ad-hoc remote tooling", 6667: "IRC", 6697: "IRC over TLS",
                   9001: "Tor relay default", 9050: "Tor SOCKS", 12345: "commonly used by ad-hoc tools",
                   31337: "historically used by remote-access tools", 54321: "commonly used by ad-hoc tools"}


def classify_destination(remote_ip: str, remote_port: int) -> tuple[Severity, str] | None:
    """Rule 5/6: unusual or watch-listed destination port on a public address."""
    if not remote_port or not is_public_ip(remote_ip):
        return None
    if remote_port in WATCHLIST_PORTS:
        return Severity.MEDIUM, f"Port {remote_port} is on the watch list ({WATCHLIST_PORTS[remote_port]})"
    if remote_port not in COMMON_PORTS and remote_port < 49152:
        return Severity.INFO, f"Unusual destination port {remote_port}"
    return None


def classify_listening(local_ip: str, local_port: int) -> Severity:
    if classify_ip(local_ip) == "Loopback":
        return Severity.LOW
    if local_ip in ("0.0.0.0", "::", "") and local_port not in COMMON_PORTS:
        return Severity.MEDIUM
    return Severity.LOW


class SecurityAnalyzer:
    """Stateful analyzer. Call analyze() once per collection cycle."""

    def __init__(self, settings: dict, known_processes=None, clock=time.time, report_unknown: bool = False):
        self.settings = settings
        self.known_processes = set(known_processes or [])
        self.known_listen: set[tuple] = set()
        self.report_unknown = report_unknown
        self.clock = clock
        self._proc_baselined = bool(self.known_processes)
        self._cycles = 0
        self._prev_keys: set = set()
        self._recent: dict[tuple, deque] = defaultdict(deque)

    def analyze(self, conns, matches: dict | None = None) -> list[Finding]:
        matches, findings, now = matches or {}, [], self.clock()
        first = self._cycles == 0
        new = [c for c in conns if c.key not in self._prev_keys]
        self._prev_keys = {c.key for c in conns}

        # Rule 1: new application making network connections
        seen_names = {}
        for c in conns:
            seen_names.setdefault(c.process_name, c)
        for name, c in seen_names.items():
            if name in self.known_processes or name.startswith("Unknown"):
                continue
            self.known_processes.add(name)
            if self._proc_baselined:
                findings.append(Finding("Unknown Process", Severity.LOW,
                                        f"New application detected making network connections: {name}",
                                        name, c.local_ip, c.remote_ip, c.remote_port, c.protocol,
                                        key=f"newapp:{name}", conn_key=c.key))
        self._proc_baselined = True

        # Rule 2: new listening port (first cycle only builds the baseline)
        for c in conns:
            listening = c.status == "LISTEN" or (c.protocol == "UDP" and not c.remote_ip)
            if not listening or (c.protocol == "UDP" and c.local_port >= 49152):
                continue
            k = (c.protocol, c.local_port)
            if k in self.known_listen:
                continue
            self.known_listen.add(k)
            if not first:
                findings.append(Finding("New Listening Port", classify_listening(c.local_ip, c.local_port),
                                        f"New listening port detected: {c.protocol}/{c.local_port} on "
                                        f"{c.local_ip or 'all addresses'} ({c.process_name})",
                                        c.process_name, c.local_ip, "", c.local_port, c.protocol,
                                        key=f"listen:{k}", conn_key=c.key))

        # Rule 3: repeated connections to the same destination
        window, threshold = self.settings["repeat_window_seconds"], self.settings["repeat_threshold"]
        flagged = set()
        if not first:
            for c in new:
                if c.status == "LISTEN" or not c.remote_ip or classify_ip(c.remote_ip) == "Loopback":
                    continue
                k = (c.process_name, c.remote_ip, c.remote_port)
                dq = self._recent[k]
                dq.append(now)
                while dq and now - dq[0] > window:
                    dq.popleft()
                if len(dq) >= threshold and k not in flagged:
                    flagged.add(k)
                    findings.append(Finding("Repeated Connection", Severity.MEDIUM,
                                            f"Repeated connection attempts detected: {c.process_name} -> "
                                            f"{c.remote_ip}:{c.remote_port} ({len(dq)} in {window}s)",
                                            c.process_name, c.local_ip, c.remote_ip, c.remote_port, c.protocol,
                                            key=f"repeat:{k}", conn_key=c.key))
            if len(self._recent) > 5000:
                self._recent = defaultdict(deque, {k: v for k, v in self._recent.items()
                                                   if v and now - v[-1] <= window})

        # Rule 4: large number of connection attempts in one cycle
        if not first:
            burst = self.settings["burst_threshold"]
            syn = [c for c in new if c.status == "SYN_SENT"]
            if len(new) >= burst or len(syn) >= burst:
                top = Counter(c.process_name for c in new).most_common(1)[0]
                sev = Severity.HIGH if len(syn) >= burst else Severity.MEDIUM
                findings.append(Finding("Suspicious Connection", sev,
                                        f"Large number of connection attempts: {len(new)} new connections "
                                        f"({len(syn)} pending SYN) in one cycle; most active: {top[0]} ({top[1]})",
                                        top[0], key="burst"))

        # Rules 5/6: destination port indicators
        for c in new:
            res = classify_destination(c.remote_ip, c.remote_port)
            if res:
                findings.append(Finding("Suspicious Connection", res[0], f"{c.process_name}: {res[1]} "
                                        f"(to {c.remote_ip})", c.process_name, c.local_ip, c.remote_ip,
                                        c.remote_port, c.protocol, key=f"port:{c.process_name}:{c.remote_port}",
                                        conn_key=c.key))

        # Rule 7: connections from processes whose identity could not be resolved
        if self.report_unknown:
            for c in conns:
                if c.process_name == "Unknown" and c.pid not in (0, 4):
                    findings.append(Finding("Unknown Process", Severity.LOW,
                                            f"Connection from an unidentified process (PID {c.pid}): "
                                            "Unknown / Requires Investigation", "Unknown", c.local_ip,
                                            c.remote_ip, c.remote_port, c.protocol, key=f"unk:{c.pid}",
                                            conn_key=c.key))

        # Rule 8: connections matching NetShield rules
        for c in new:
            m = matches.get(c.key)
            if not m or m["rule"]["action"] != "Block":
                continue
            rule = m["rule"]
            if m["verdict"] == "Blocked":
                findings.append(Finding("Blocked Connection", Severity.MEDIUM,
                                        f"Connection attempt matched block rule {rule['rule_name']}: "
                                        f"{c.process_name} -> {c.remote_ip}:{c.remote_port}",
                                        c.process_name, c.local_ip, c.remote_ip, c.remote_port, c.protocol,
                                        key=f"blocked:{rule['rule_name']}:{c.process_name}", conn_key=c.key,
                                        rule_id=rule.get("id")))
            elif m["verdict"] == "Conflict":
                findings.append(Finding("Suspicious Connection", Severity.MEDIUM,
                                        f"Established connection matches block rule {rule['rule_name']} "
                                        "(connection may pre-date the rule or the profile is not active)",
                                        c.process_name, c.local_ip, c.remote_ip, c.remote_port, c.protocol,
                                        key=f"conflict:{rule['rule_name']}:{c.process_name}", conn_key=c.key,
                                        rule_id=rule.get("id")))
        self._cycles += 1
        return findings


def firewall_status_findings(prev: dict | None, curr: dict) -> list[Finding]:
    """Rule 9: firewall configuration changes."""
    out = []
    off = [p for p in ("Domain", "Private", "Public") if curr.get(p) == "OFF"]
    if off:
        sev = Severity.CRITICAL if len(off) == 3 else Severity.HIGH
        out.append(Finding("Firewall Status Change", sev,
                           f"Windows Defender Firewall is disabled ({', '.join(off)} profile"
                           f"{'s' if len(off) > 1 else ''}).", key="fw-off:" + ",".join(off), cooldown=3600))
    if prev:
        for p in ("Domain", "Private", "Public"):
            a, b = prev.get(p, "UNKNOWN"), curr.get(p, "UNKNOWN")
            if "UNKNOWN" not in (a, b) and a != b:
                out.append(Finding("Firewall Status Change", Severity.HIGH if b == "OFF" else Severity.INFO,
                                   f"Windows Defender Firewall {p} profile changed from {a} to {b}.",
                                   key=f"fw-change:{p}:{b}", cooldown=60))
    return out
