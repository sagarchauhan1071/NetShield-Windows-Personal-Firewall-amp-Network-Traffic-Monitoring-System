"""Alert engine: de-duplicates findings, stores events and raises alerts."""
from __future__ import annotations

import time
from datetime import datetime

from app.core.analyzer import Finding, Severity

ALERT_TITLES = {
    "Unknown Process": "Application / process requires review",
    "New Listening Port": "New listening port detected",
    "Repeated Connection": "Repeated connection attempts detected",
    "Suspicious Connection": "Potentially suspicious network activity observed",
    "Blocked Connection": "Connection matched a NetShield block rule",
    "Firewall Status Change": "Firewall status",
    "Firewall Rule Change": "NetShield-managed firewall rule changed",
    "Configuration Change": "Configuration changed",
}
ALERT_STATUSES = ("New", "Acknowledged", "Dismissed", "Confirmed")


class AlertEngine:
    def __init__(self, event_repo, alert_repo, cooldown: int = 300, clock=time.time):
        self.events, self.alerts, self.cooldown, self.clock = event_repo, alert_repo, cooldown, clock
        self._last: dict[tuple, float] = {}

    def process(self, findings: list[Finding]) -> list[dict]:
        now, created = self.clock(), []
        for f in findings:
            k = (f.event_type, f.key or f.description)
            window = f.cooldown if f.cooldown is not None else self.cooldown
            last = self._last.get(k)
            if last is not None and now - last < window:
                continue
            self._last[k] = now
            event = self.events.add({
                "timestamp": datetime.now(), "event_type": f.event_type, "severity": f.severity.name,
                "process": f.process, "source_ip": f.source_ip, "destination_ip": f.destination_ip,
                "port": f.port, "protocol": f.protocol, "description": f.description,
                "status": "Open", "rule_id": f.rule_id})
            if f.severity >= Severity.LOW:
                created.append(self.alerts.add({
                    "timestamp": datetime.now(), "severity": f.severity.name,
                    "title": ALERT_TITLES.get(f.event_type, f.event_type), "message": f.description,
                    "status": "New", "event_id": event["id"]}))
        if len(self._last) > 5000:
            horizon = now - max(self.cooldown, 3600)
            self._last = {k: v for k, v in self._last.items() if v > horizon}
        return created
