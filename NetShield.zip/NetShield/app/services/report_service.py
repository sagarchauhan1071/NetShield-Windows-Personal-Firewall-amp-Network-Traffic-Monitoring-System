"""Report generation (PDF, HTML, CSV, JSON). Language distinguishes Observed / Blocked / Suspicious / Confirmed."""
from __future__ import annotations

import csv
import html
import json
from collections import Counter
from datetime import datetime
from pathlib import Path
from xml.sax.saxutils import escape

from app.core.monitor import collect_connections, get_network_interfaces
from app.core.tools import detect_tools, system_info
from app.utils.helpers import period_start, truncate
from app.utils.validators import safe_filename, validate_directory
from config import APP_NAME, APP_SUBTITLE, APP_VERSION, DISCLAIMER, PERIODS

FORMATS = ("pdf", "html", "csv", "json")


def _csv_safe(value) -> str:
    text = "" if value is None else str(value)
    return "'" + text if text[:1] in ("=", "+", "-", "@", "\t", "\r") else text


def build_recommendations(fw: dict, is_admin: bool, listening: int, suspicious: int, rules: int) -> list[str]:
    out = []
    if any(fw.get(p) == "OFF" for p in ("Domain", "Private", "Public")):
        out.append("Windows Defender Firewall appears to be disabled for at least one profile. Review the "
                   "setting in Windows Security and re-enable it unless a managed alternative is in place.")
    if all(fw.get(p) == "UNKNOWN" for p in ("Domain", "Private", "Public")):
        out.append("Firewall status could not be determined. Run NetShield on Windows (and as Administrator "
                   "if required) to verify it.")
    if not is_admin:
        out.append("NetShield was not running as Administrator; process details and rule management may be incomplete.")
    if suspicious:
        out.append("Review the listed indicators manually. They are not proof of malicious activity; verify the "
                   "executable path, publisher and destination before acting.")
    if listening > 40:
        out.append("A large number of listening ports were observed. Review services that do not need to accept connections.")
    if not rules:
        out.append("No NetShield-managed firewall rules exist. Create block rules only for traffic you have reviewed.")
    out.append("Keep Windows and installed software updated and review this report periodically.")
    return out


class ReportService:
    def __init__(self, repos, settings: dict, firewall_status_provider=None):
        self.repos, self.settings, self.fw_status = repos, settings, firewall_status_provider

    # ------------------------------------------------------------ data
    def collect(self, period: str = "Today", live_rows: list | None = None) -> dict:
        from app.core.tools import is_admin
        since = period_start(period if period in PERIODS else "Today")
        if live_rows is None:
            try:
                live_rows = [c.to_dict() for c in collect_connections()]
            except Exception:
                live_rows = []
        fw = self.fw_status() if self.fw_status else {}
        interfaces = get_network_interfaces()
        listening = [r for r in live_rows if r.get("status") == "LISTEN"]
        active = [r for r in live_rows if r.get("status") != "LISTEN"]
        rules = self.repos.rules.list()
        events = self.repos.events.list(limit=300, since=since)
        suspicious = [e for e in events if e["severity"] != "INFO" and e["event_type"] in (
            "Suspicious Connection", "Repeated Connection", "New Listening Port", "Unknown Process")]
        confirmed = [e for e in events if e["status"] == "Confirmed"]
        blocked, _ = self.repos.connections.query({"since": since, "action": "Blocked"}, 1, 200)
        stats = self.repos.connections.stats(since)
        top_proc = self.repos.connections.top("process_name", since, 10)
        top_port = self.repos.connections.top("remote_port", since, 10)
        top_ip = self.repos.connections.top("remote_ip", since, 10)
        tools = detect_tools(self.settings)

        sections = [
            {"title": "Executive Summary", "paragraphs": [
                f"This report covers the period '{period}'. NetShield observed {stats['total']} logged connection "
                f"records, of which {stats['blocked']} matched a NetShield block rule (Blocked). "
                f"{len(suspicious)} security event(s) represent potentially suspicious network activity observed "
                f"(indicators only); {len(confirmed)} were marked Confirmed by an analyst. " + DISCLAIMER],
             "kv": [["Observed connections (logged)", stats["total"]], ["Blocked", stats["blocked"]],
                    ["Suspicious (indicators)", len(suspicious)], ["Confirmed (analyst-marked)", len(confirmed)]]},
            {"title": "System Information", "kv": [[k, v] for k, v in system_info().items()] +
             [[t.name, f"{'Installed' if t.installed else 'Not installed'} {t.version}".strip()] for t in tools]},
            {"title": "Firewall Status", "kv": [[f"{p} profile", fw.get(p, "UNKNOWN")] for p in ("Domain", "Private", "Public")],
             "paragraphs": ([fw["error"]] if fw.get("error") else [])},
            {"title": "Network Interfaces", "columns": ["Name", "IPv4", "IPv6", "MAC", "Status", "Bytes sent", "Bytes received"],
             "rows": [[i["name"], i["ipv4"], i["ipv6"], i["mac"], i["status"], i["bytes_sent"], i["bytes_recv"]] for i in interfaces]},
            {"title": "Active Connections (Observed)", "columns": ["Process", "PID", "Local", "Remote", "Proto", "State"],
             "rows": [[r["process_name"], r["pid"], f"{r['local_ip']}:{r['local_port']}",
                       f"{r['remote_ip']}:{r['remote_port']}" if r["remote_ip"] else "", r["protocol"], r["status"]]
                      for r in active[:300]]},
            {"title": "Listening Ports", "columns": ["Process", "PID", "Address", "Port", "Proto"],
             "rows": [[r["process_name"], r["pid"], r["local_ip"], r["local_port"], r["protocol"]] for r in listening[:300]]},
            {"title": "Firewall Rules (NetShield-managed)", "columns": ["Name", "Direction", "Action", "Protocol", "Ports", "Program", "Profile", "Enabled"],
             "rows": [[r["rule_name"], r["direction"], r["action"], r["protocol"],
                       " / ".join(x for x in (r["local_port"], r["remote_port"]) if x) or "Any",
                       r["program_path"] or "All", r["profile"], "Yes" if r["enabled"] else "No"] for r in rules]},
            {"title": "Blocked Connections", "columns": ["Time", "Process", "Remote", "Proto", "Rule"],
             "rows": [[r["timestamp"].strftime("%Y-%m-%d %H:%M:%S"), r["process_name"], f"{r['remote_ip']}:{r['remote_port']}",
                       r["protocol"], r["rule"]] for r in blocked]},
            {"title": "Security Events", "columns": ["Time", "Type", "Severity", "Process", "Description", "Status"],
             "rows": [[e["timestamp"].strftime("%Y-%m-%d %H:%M:%S"), e["event_type"], e["severity"], e["process"],
                       e["description"], e["status"]] for e in events]},
            {"title": "Suspicious Activity (indicators, not proof)", "paragraphs": [
                "Potentially suspicious network activity observed. " + DISCLAIMER],
             "columns": ["Time", "Severity", "Process", "Destination", "Description"],
             "rows": [[e["timestamp"].strftime("%H:%M:%S"), e["severity"], e["process"],
                       f"{e['destination_ip']}:{e['port']}" if e["destination_ip"] else "", e["description"]]
                      for e in suspicious]},
            {"title": "Network Statistics", "kv": [["Total connection records", stats["total"]], ["TCP", stats["tcp"]],
                                                   ["UDP", stats["udp"]], ["Listening ports", stats["listening"]],
                                                   ["Unique remote IPs", stats["unique_remote_ips"]]],
             "columns": ["Top processes", "Records"], "rows": [list(r) for r in top_proc] +
             [["— Top destination ports —", ""]] + [[str(p), n] for p, n in top_port] +
             [["— Top destination IPs —", ""]] + [list(r) for r in top_ip]},
            {"title": "Recommendations", "paragraphs": build_recommendations(
                fw, is_admin(), len(listening), len(suspicious), len(rules))},
            {"title": "Appendix", "paragraphs": [
                "Terminology: Observed = seen by the monitor; Blocked = matched an enabled NetShield block rule "
                "(enforcement is performed by Windows Defender Firewall); Suspicious = rule-based indicator; "
                "Confirmed = manually marked by an analyst. NetShield never states that malware was detected.",
                "Detection is rule-based and transparent (repeated connections, new listening ports, watch-listed ports, "
                "new applications, bursts, firewall changes). No AI or machine learning is used."],
             "kv": [[k, v] for k, v in self.settings.items() if k not in ("wireshark_path",)]},
        ]
        for i, sec in enumerate(sections, 1):
            sec["title"] = f"{i}. {sec['title']}"
        return {"meta": {"title": f"{APP_NAME} Security Report", "subtitle": APP_SUBTITLE, "version": APP_VERSION,
                         "generated_at": datetime.now().strftime("%Y-%m-%d %H:%M:%S"), "period": period},
                "sections": sections}

    # ------------------------------------------------------------ renderers
    @staticmethod
    def to_json(report: dict, path: Path) -> None:
        path.write_text(json.dumps(report, indent=2, default=str), encoding="utf-8")

    @staticmethod
    def to_csv(report: dict, path: Path) -> None:
        with open(path, "w", newline="", encoding="utf-8-sig") as f:
            w = csv.writer(f)
            w.writerow([_csv_safe(report["meta"]["title"]), report["meta"]["generated_at"], report["meta"]["period"]])
            for sec in report["sections"]:
                w.writerow([])
                w.writerow([_csv_safe(sec["title"])])
                for p in sec.get("paragraphs", []):
                    w.writerow([_csv_safe(p)])
                for k, v in sec.get("kv", []):
                    w.writerow([_csv_safe(k), _csv_safe(v)])
                if sec.get("columns"):
                    w.writerow([_csv_safe(c) for c in sec["columns"]])
                    for row in sec["rows"]:
                        w.writerow([_csv_safe(c) for c in row])

    @staticmethod
    def to_html(report: dict, path: Path) -> None:
        e, m = html.escape, report["meta"]
        parts = [f"<!doctype html><html><head><meta charset='utf-8'><title>{e(m['title'])}</title><style>"
                 "body{font-family:Segoe UI,Arial,sans-serif;margin:32px;color:#1f2328}h1{color:#0b3d91}"
                 "h2{border-bottom:2px solid #0b3d91;padding-bottom:4px;margin-top:28px}"
                 "table{border-collapse:collapse;width:100%;font-size:12px;margin:8px 0}"
                 "th,td{border:1px solid #d0d7de;padding:4px 8px;text-align:left;vertical-align:top}"
                 "th{background:#eef2f7}.note{background:#fff8c5;padding:8px;border-left:4px solid #d4a72c}"
                 "</style></head><body>",
                 f"<h1>{e(m['title'])}</h1><p>{e(m['subtitle'])} &middot; v{e(m['version'])}<br>"
                 f"Generated {e(m['generated_at'])} &middot; Period: {e(m['period'])}</p>",
                 f"<p class='note'>{e(DISCLAIMER)}</p>"]
        for sec in report["sections"]:
            parts.append(f"<h2>{e(sec['title'])}</h2>")
            parts += [f"<p>{e(str(p))}</p>" for p in sec.get("paragraphs", [])]
            if sec.get("kv"):
                parts.append("<table>" + "".join(f"<tr><th>{e(str(k))}</th><td>{e(str(v))}</td></tr>" for k, v in sec["kv"]) + "</table>")
            if sec.get("columns"):
                head = "".join(f"<th>{e(c)}</th>" for c in sec["columns"])
                body = "".join("<tr>" + "".join(f"<td>{e(str(c))}</td>" for c in r) + "</tr>" for r in sec["rows"])
                parts.append(f"<table><tr>{head}</tr>{body or '<tr><td colspan=99>No data</td></tr>'}</table>")
        parts.append("</body></html>")
        path.write_text("".join(parts), encoding="utf-8")

    @staticmethod
    def to_pdf(report: dict, path: Path) -> None:
        from reportlab.lib import colors
        from reportlab.lib.pagesizes import A4, landscape
        from reportlab.lib.styles import ParagraphStyle, getSampleStyleSheet
        from reportlab.platypus import Paragraph, SimpleDocTemplate, Spacer, Table, TableStyle

        m, styles = report["meta"], getSampleStyleSheet()
        small = ParagraphStyle("small", parent=styles["BodyText"], fontSize=7, leading=9)
        doc = SimpleDocTemplate(str(path), pagesize=landscape(A4), leftMargin=24, rightMargin=24,
                                topMargin=24, bottomMargin=24, title=m["title"], author=APP_NAME)
        P = lambda t, s=styles["BodyText"]: Paragraph(escape(str(t)), s)  # noqa: E731
        story = [P(m["title"], styles["Title"]),
                 P(f"{m['subtitle']} | v{m['version']} | Generated {m['generated_at']} | Period: {m['period']}"),
                 Spacer(1, 6), P(DISCLAIMER, styles["Italic"])]
        grid = TableStyle([("GRID", (0, 0), (-1, -1), 0.3, colors.grey), ("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#eef2f7")),
                           ("VALIGN", (0, 0), (-1, -1), "TOP")])
        for sec in report["sections"]:
            story += [Spacer(1, 8), P(sec["title"], styles["Heading2"])]
            story += [P(p) for p in sec.get("paragraphs", [])]
            if sec.get("kv"):
                t = Table([[P(k, small), P(v, small)] for k, v in sec["kv"]], colWidths=[220, doc.width - 220])
                t.setStyle(TableStyle([("GRID", (0, 0), (-1, -1), 0.3, colors.grey), ("BACKGROUND", (0, 0), (0, -1), colors.HexColor("#eef2f7"))]))
                story.append(t)
            if sec.get("columns"):
                rows = sec["rows"][:80]
                data = [[P(c, small) for c in sec["columns"]]] + [[P(truncate(c, 90), small) for c in r] for r in rows] \
                    or [[P("No data", small)]]
                t = Table(data, colWidths=[doc.width / len(sec["columns"])] * len(sec["columns"]), repeatRows=1)
                t.setStyle(grid)
                story.append(t)
                if len(sec["rows"]) > 80:
                    story.append(P(f"... {len(sec['rows']) - 80} more rows omitted (see CSV/JSON export).", small))
        doc.build(story)

    # ------------------------------------------------------------ public
    def generate(self, fmt: str, period: str = "Today", live_rows: list | None = None, report: dict | None = None) -> Path:
        fmt = fmt.lower()
        if fmt not in FORMATS:
            raise ValueError(f"Unsupported report format: {fmt}")
        out_dir = validate_directory(self.settings["report_dir"], create=True)
        report = report or self.collect(period, live_rows)
        name = safe_filename(f"netshield_report_{datetime.now():%Y%m%d_%H%M%S}") + f".{fmt}"
        path = out_dir / name
        getattr(self, f"to_{fmt}")(report, path)
        self.repos.reports.add(report["meta"]["title"], fmt.upper(), period, str(path))
        self.repos.audit.add("Report generated", f"{fmt.upper()} {path.name} ({period})")
        return path
