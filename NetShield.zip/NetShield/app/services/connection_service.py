"""Monitoring service: one collection cycle = collect -> match rules -> analyze -> alert -> log."""
from __future__ import annotations

import time
from collections import Counter, defaultdict
from dataclasses import dataclass, field
from datetime import datetime

from app.core.alerts import AlertEngine
from app.core.analyzer import SecurityAnalyzer, Severity, firewall_status_findings, severity_to_risk
from app.core.firewall import FirewallManager, rule_matches_connection, verdict_for
from app.core.monitor import ProcessCache, collect_connections, interface_addresses
from app.core.tools import is_admin
from app.utils.logger import get_logger

log = get_logger("monitor")
FIREWALL_POLL_SECONDS = 30
CLEANUP_SECONDS = 3600


@dataclass
class CycleResult:
    rows: list = field(default_factory=list)
    alerts: list = field(default_factory=list)
    active: int = 0
    established: int = 0
    listening: int = 0
    firewall: dict | None = None
    duration: float = 0.0
    timestamp: datetime = field(default_factory=datetime.now)


class MonitoringService:
    def __init__(self, repos, settings: dict, fw_manager: FirewallManager | None = None):
        self.repos, self.settings, self.fw = repos, dict(settings), fw_manager
        self.cache = ProcessCache()
        self.analyzer = SecurityAnalyzer(self.settings, repos.processes.known_names(), report_unknown=is_admin())
        self.alert_engine = AlertEngine(repos.events, repos.alerts, self.settings["alert_cooldown_seconds"])
        self._logged: set = set()
        self._prev_fw: dict | None = None
        self.last_firewall_status: dict | None = None
        self._last_fw = 0.0
        self._last_cleanup = time.time()

    def update_settings(self, settings: dict) -> None:
        self.settings.clear()
        self.settings.update(settings)        # analyzer shares this dict
        self.alert_engine.cooldown = self.settings["alert_cooldown_seconds"]

    def _filter_interface(self, conns):
        name = self.settings.get("network_interface", "")
        if not name:
            return conns
        addrs = interface_addresses(name) | {"", "0.0.0.0", "::"}
        return [c for c in conns if c.local_ip.split("%")[0] in addrs]

    def _poll_firewall(self) -> list:
        if not self.fw or time.time() - self._last_fw < FIREWALL_POLL_SECONDS:
            return []
        self._last_fw = time.time()
        status = self.fw.get_status()
        self.last_firewall_status = status
        if all(status.get(p) == "UNKNOWN" for p in ("Domain", "Private", "Public")):
            return []
        findings = firewall_status_findings(self._prev_fw, status)
        self._prev_fw = status
        return findings

    def run_cycle(self, collector=None) -> CycleResult:
        t0 = time.time()
        conns = self._filter_interface((collector or collect_connections)(self.cache))
        rules = self.repos.rules.list_enabled()
        listening_ports = {c.local_port for c in conns if c.status == "LISTEN"}
        matches = {}
        for c in conns:
            for rule in rules:
                if rule_matches_connection(rule, c, listening_ports):
                    matches[c.key] = {"rule": rule, "verdict": verdict_for(rule, c)}
                    if rule["action"] == "Block":
                        break

        findings = self.analyzer.analyze(conns, matches) + self._poll_firewall()
        alerts = self.alert_engine.process(findings)
        risk: dict = {}
        for f in findings:
            if f.conn_key is not None:
                risk[f.conn_key] = max(risk.get(f.conn_key, Severity.INFO), f.severity)

        by_proc: dict = defaultdict(lambda: {"count": 0, "pid": None})
        for c in conns:
            agg = by_proc[(c.process_name, c.exe_path)]
            agg["count"] += 1
            agg["pid"] = c.pid
        proc_ids = self.repos.processes.upsert_many(
            [{"name": n, "exe_path": e, "pid": v["pid"], "connection_count": v["count"]}
             for (n, e), v in by_proc.items()])

        rows, new_rows = [], []
        for c in conns:
            m = matches.get(c.key)
            verdict = m["verdict"] if m else "Observed"
            action = verdict if verdict in ("Allowed", "Blocked") else "Observed"
            sev = risk.get(c.key, Severity.INFO)
            if verdict == "Conflict":
                sev = max(sev, Severity.MEDIUM)
            row = {**c.to_dict(), "action": action, "rule": m["rule"]["rule_name"] if m else "",
                   "risk_level": severity_to_risk(sev)}
            rows.append(row)
            if c.key not in self._logged:
                new_rows.append({**{k: row[k] for k in (
                    "timestamp", "process_name", "pid", "local_ip", "local_port", "remote_ip", "remote_port",
                    "protocol", "status", "action", "rule", "risk_level")},
                    "process_id": proc_ids.get((c.process_name, c.exe_path)),
                    "rule_id": m["rule"]["id"] if m else None})
        self.repos.connections.add_many(new_rows)
        self._logged = {c.key for c in conns}

        if time.time() - self._last_cleanup > CLEANUP_SECONDS:
            self._last_cleanup = time.time()
            self.repos.db.cleanup(self.settings["log_retention_days"], self.settings["max_db_size_mb"])

        return CycleResult(
            rows=rows, alerts=alerts,
            active=sum(1 for r in rows if r["status"] != "LISTEN"),
            established=sum(1 for r in rows if r["status"] == "ESTABLISHED"),
            listening=len({(r["protocol"], r["local_port"]) for r in rows if r["status"] == "LISTEN"}),
            firewall=self.last_firewall_status, duration=time.time() - t0)
