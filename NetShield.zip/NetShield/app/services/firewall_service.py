"""Firewall rule workflow: validate -> preview -> (user confirmation) -> apply -> store -> audit."""
from __future__ import annotations

from datetime import datetime

from app.core.firewall import (FirewallError, FirewallManager, describe_rule_effect, managed_name)
from app.utils.validators import ValidationError, validate_rule


class ConfirmationRequired(FirewallError):
    pass


class FirewallService:
    def __init__(self, repos, manager: FirewallManager):
        self.repos, self.manager = repos, manager

    def prepare(self, data: dict, must_exist_program: bool = False) -> tuple[dict, str]:
        """Validate and return (clean_rule, human readable effect). Raises ValidationError."""
        data = dict(data)
        data["rule_name"] = managed_name(data.get("rule_name"))
        clean = validate_rule(data, must_exist_program)
        return clean, describe_rule_effect(clean)

    def _record(self, event_type: str, text: str, rule_id=None) -> None:
        ev = self.repos.events.add({"timestamp": datetime.now(), "event_type": "Firewall Rule Change",
                                    "severity": "INFO", "description": text, "status": "Open", "rule_id": rule_id})
        self.repos.alerts.add({"timestamp": datetime.now(), "severity": "INFO",
                               "title": "NetShield-managed firewall rule changed", "message": text,
                               "status": "New", "event_id": ev["id"]})

    def create_rule(self, data: dict, confirmed: bool = False, must_exist_program: bool = False) -> dict:
        if not confirmed:
            raise ConfirmationRequired("Explicit user confirmation is required to create a rule")
        clean, _ = self.prepare(data, must_exist_program)
        try:
            self.manager.create_rule(clean)
        except Exception as exc:
            self.repos.audit.add("Firewall rule created", f"{clean['rule_name']}: {exc}", "Failed")
            raise
        saved = self.repos.rules.add(clean)
        self.repos.audit.add("Firewall rule created", f"{clean['rule_name']} ({clean['direction']} {clean['action']})")
        self._record("create", f"Rule {clean['rule_name']} created ({clean['direction']} {clean['action']}).", saved["id"])
        return saved

    def delete_rule(self, name: str, confirmed: bool = False) -> None:
        if not confirmed:
            raise ConfirmationRequired("Explicit user confirmation is required to delete a rule")
        if not self.repos.rules.get(name):
            raise FirewallError("Rule is not managed by NetShield")
        try:
            self.manager.delete_rule(name)
        except Exception as exc:
            self.repos.audit.add("Firewall rule deleted", f"{name}: {exc}", "Failed")
            raise
        self.repos.rules.delete(name)
        self.repos.audit.add("Firewall rule deleted", name)
        self._record("delete", f"Rule {name} deleted.")

    def set_enabled(self, name: str, enabled: bool, confirmed: bool = False) -> None:
        if not confirmed:
            raise ConfirmationRequired("Explicit user confirmation is required to change a rule")
        if not self.repos.rules.get(name):
            raise FirewallError("Rule is not managed by NetShield")
        word = "enabled" if enabled else "disabled"
        try:
            self.manager.set_enabled(name, enabled)
        except Exception as exc:
            self.repos.audit.add(f"Firewall rule {word}", f"{name}: {exc}", "Failed")
            raise
        self.repos.rules.set_enabled(name, enabled)
        self.repos.audit.add(f"Firewall rule {word}", name)
        self._record("toggle", f"Rule {name} {word}.")

    def windows_states(self) -> dict:
        """Map rule name -> Windows-reported state (read-only query)."""
        return {r["DisplayName"]: r for r in self.manager.query_rules(managed_only=True)}
