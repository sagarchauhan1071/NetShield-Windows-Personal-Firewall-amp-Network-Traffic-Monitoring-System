"""PCAP/PCAPNG import and summary (pure-Python, read-only) plus optional Wireshark/TShark launchers."""
from __future__ import annotations

import os
import socket
import struct
import subprocess
from collections import Counter
from dataclasses import dataclass, field
from pathlib import Path

from app.utils.helpers import run_command
from app.utils.validators import ValidationError, validate_file_size
from config import MAX_PCAP_BYTES, MAX_PCAP_PACKETS, MAX_TSHARK_SECONDS


class PcapError(Exception):
    pass


@dataclass
class PcapSummary:
    path: str
    fmt: str
    total_packets: int = 0
    parsed_packets: int = 0
    total_bytes: int = 0
    first_ts: float = 0.0
    last_ts: float = 0.0
    truncated: bool = False
    protocols: dict = field(default_factory=dict)
    top_conversations: list = field(default_factory=list)
    top_dest_ips: list = field(default_factory=list)
    top_ports: list = field(default_factory=list)
    packets: list = field(default_factory=list)       # first N packet metadata dicts


# ---------------------------------------------------------------- decoding
def _l3_from_frame(linktype: int, frame: bytes):
    if linktype == 1 and len(frame) >= 14:                     # Ethernet
        et, off = struct.unpack("!H", frame[12:14])[0], 14
        while et in (0x8100, 0x88A8) and len(frame) >= off + 4:
            et, off = struct.unpack("!H", frame[off + 2:off + 4])[0], off + 4
        return et, frame[off:]
    if linktype in (12, 101) and frame:                        # raw IP
        return {4: 0x0800, 6: 0x86DD}.get(frame[0] >> 4), frame
    if linktype == 228:
        return 0x0800, frame
    if linktype == 229:
        return 0x86DD, frame
    if linktype == 113 and len(frame) >= 16:                   # Linux cooked
        return struct.unpack("!H", frame[14:16])[0], frame[16:]
    if linktype == 0 and len(frame) > 4:                       # BSD loopback
        return {4: 0x0800, 6: 0x86DD}.get(frame[4] >> 4), frame[4:]
    return None, b""


def decode_packet(linktype: int, frame: bytes):
    """Return (src, dst, sport, dport, protocol) or None."""
    ethertype, buf = _l3_from_frame(linktype, frame)
    try:
        if ethertype == 0x0800 and len(buf) >= 20:
            ihl = (buf[0] & 0x0F) * 4
            if ihl < 20 or len(buf) < ihl:
                return None
            proto = buf[9]
            src, dst = socket.inet_ntop(socket.AF_INET, buf[12:16]), socket.inet_ntop(socket.AF_INET, buf[16:20])
            frag = struct.unpack("!H", buf[6:8])[0] & 0x1FFF
            payload = b"" if frag else buf[ihl:]
        elif ethertype == 0x86DD and len(buf) >= 40:
            proto = buf[6]
            src, dst = socket.inet_ntop(socket.AF_INET6, buf[8:24]), socket.inet_ntop(socket.AF_INET6, buf[24:40])
            payload = buf[40:]
            for _ in range(8):
                if proto in (0, 43, 60) and len(payload) >= 8:
                    proto, payload = payload[0], payload[(payload[1] + 1) * 8:]
                elif proto == 44 and len(payload) >= 8:
                    proto, payload = payload[0], b""
                else:
                    break
        else:
            return None
    except (struct.error, ValueError, IndexError):
        return None
    sport = dport = 0
    names = {6: "TCP", 17: "UDP", 1: "ICMP", 58: "ICMPv6"}
    if proto in (6, 17) and len(payload) >= 4:
        sport, dport = struct.unpack("!HH", payload[:4])
    return src, dst, sport, dport, names.get(proto, f"IP-{proto}")


# ---------------------------------------------------------------- readers
def _iter_pcap(f):
    hdr = f.read(24)
    magic = hdr[:4]
    table = {b"\xd4\xc3\xb2\xa1": ("<", False), b"\x4d\x3c\xb2\xa1": ("<", True),
             b"\xa1\xb2\xc3\xd4": (">", False), b"\xa1\xb2\x3c\x4d": (">", True)}
    if len(hdr) < 24 or magic not in table:
        raise PcapError("Not a valid pcap file")
    endian, nano = table[magic]
    linktype = struct.unpack(endian + "I", hdr[20:24])[0] & 0x0FFFFFFF
    div = 1e9 if nano else 1e6
    while True:
        rh = f.read(16)
        if len(rh) < 16:
            return
        sec, frac, incl, orig = struct.unpack(endian + "IIII", rh)
        if incl > 1 << 20:
            raise PcapError("Corrupt packet header (oversized capture length)")
        data = f.read(incl)
        if len(data) < incl:
            return
        yield sec + frac / div, orig, linktype, data


def _iter_pcapng(f):
    endian, ifaces = None, []
    while True:
        head = f.read(8)
        if len(head) < 8:
            return
        if head[:4] == b"\n\r\r\n":
            bom = f.read(4)
            endian = {b"\x4d\x3c\x2b\x1a": "<", b"\x1a\x2b\x3c\x4d": ">"}.get(bom)
            if not endian:
                raise PcapError("Invalid pcapng byte-order magic")
            total = struct.unpack(endian + "I", head[4:8])[0]
            if total < 12 or total > 1 << 20:
                raise PcapError("Invalid section header")
            f.read(total - 12)
            ifaces = []
            continue
        if endian is None:
            raise PcapError("Not a valid pcapng file")
        btype, total = struct.unpack(endian + "II", head)
        if total < 12 or total > 1 << 24:
            raise PcapError("Corrupt pcapng block")
        body = f.read(total - 8)
        if len(body) < total - 8:
            return
        body = body[:-4]
        if btype == 1 and len(body) >= 8:                      # Interface Description
            link, div, opts, i = struct.unpack(endian + "H", body[:2])[0], 1e6, body[8:], 0
            while i + 4 <= len(opts):
                code, ln = struct.unpack(endian + "HH", opts[i:i + 4])
                val, i = opts[i + 4:i + 4 + ln], i + 4 + ((ln + 3) & ~3)
                if code == 0:
                    break
                if code == 9 and ln == 1:
                    b = val[0]
                    div = float(2 ** (b & 0x7F) if b & 0x80 else 10 ** (b & 0x7F))
            ifaces.append((link, div))
        elif btype == 6 and len(body) >= 20:                   # Enhanced Packet
            idx, hi, lo, cap, orig = struct.unpack(endian + "IIIII", body[:20])
            link, div = ifaces[idx] if idx < len(ifaces) else (1, 1e6)
            yield ((hi << 32) | lo) / div, orig, link, body[20:20 + cap]
        elif btype == 3 and len(body) >= 4 and ifaces:         # Simple Packet
            orig = struct.unpack(endian + "I", body[:4])[0]
            yield 0.0, orig, ifaces[0][0], body[4:4 + min(orig, len(body) - 4)]


def analyze_pcap(path, max_packets: int = MAX_PCAP_PACKETS, keep: int = 5000) -> PcapSummary:
    p = Path(path)
    if p.suffix.lower() not in (".pcap", ".pcapng", ".cap"):
        raise ValidationError("Only .pcap and .pcapng files can be imported")
    validate_file_size(p, MAX_PCAP_BYTES)
    protocols, convs, dest_ips, ports = Counter(), {}, Counter(), Counter()
    with open(p, "rb") as f:
        magic = f.read(4)
        f.seek(0)
        if magic == b"\n\r\r\n":
            fmt, it = "pcapng", _iter_pcapng(f)
        else:
            fmt, it = "pcap", _iter_pcap(f)
        s = PcapSummary(str(p), fmt)
        try:
            for ts, orig, link, data in it:
                if s.total_packets >= max_packets:
                    s.truncated = True
                    break
                s.total_packets += 1
                s.total_bytes += orig
                if ts:
                    s.first_ts = ts if not s.first_ts else min(s.first_ts, ts)
                    s.last_ts = max(s.last_ts, ts)
                d = decode_packet(link, data)
                if not d:
                    protocols["Other / non-IP"] += 1
                    continue
                src, dst, sport, dport, proto = d
                s.parsed_packets += 1
                protocols[proto] += 1
                dest_ips[dst] += 1
                if dport:
                    ports[(proto, dport)] += 1
                ck = (proto,) + tuple(sorted(((src, sport), (dst, dport))))
                if ck in convs or len(convs) < 100_000:
                    c = convs.setdefault(ck, [0, 0])
                    c[0] += 1
                    c[1] += orig
                if len(s.packets) < keep:
                    s.packets.append({"timestamp": ts, "src_ip": src, "dst_ip": dst, "src_port": sport,
                                      "dst_port": dport, "protocol": proto, "length": orig})
        except struct.error as exc:
            raise PcapError(f"Corrupt capture file: {exc}") from None
    s.protocols = dict(protocols.most_common())
    s.top_conversations = [{"protocol": k[0], "endpoint_a": f"{k[1][0]}:{k[1][1]}",
                            "endpoint_b": f"{k[2][0]}:{k[2][1]}", "packets": v[0], "bytes": v[1]}
                           for k, v in sorted(convs.items(), key=lambda kv: -kv[1][0])[:25]]
    s.top_dest_ips = dest_ips.most_common(15)
    s.top_ports = [(f"{k[0]}/{k[1]}", n) for k, n in ports.most_common(15)]
    return s


# ---------------------------------------------------------------- external tools
def open_wireshark(wireshark_path: str, pcap: str | None = None) -> None:
    if not wireshark_path or not os.path.isfile(wireshark_path) or "wireshark" not in os.path.basename(wireshark_path).lower():
        raise PcapError("Wireshark was not detected. Packet capture import features requiring Wireshark are unavailable.")
    args = [wireshark_path] + ([str(Path(pcap).resolve())] if pcap else [])
    subprocess.Popen(args, shell=False)  # noqa: S603 - fixed executable, validated path


def open_folder(path) -> None:
    folder = Path(path)
    folder.mkdir(parents=True, exist_ok=True)
    if os.name != "nt":
        raise PcapError("Opening folders is only supported on Windows")
    os.startfile(str(folder))  # type: ignore[attr-defined]


def tshark_interfaces(tshark_path: str) -> list[str]:
    res = run_command([tshark_path, "-D"], timeout=15)
    return [ln.strip() for ln in res.stdout.splitlines() if ln.strip()] if res.ok else []


def capture_with_tshark(tshark_path: str, interface_index: int, seconds: int, out_file) -> Path:
    """Short, time-limited capture on the user's own machine. Caller must obtain explicit confirmation."""
    if not tshark_path or not os.path.isfile(tshark_path):
        raise PcapError("TShark was not detected.")
    if not 1 <= int(seconds) <= MAX_TSHARK_SECONDS:
        raise ValidationError(f"Duration must be between 1 and {MAX_TSHARK_SECONDS} seconds")
    if not any(ln.split(".", 1)[0] == str(int(interface_index)) for ln in tshark_interfaces(tshark_path)):
        raise ValidationError("Unknown capture interface")
    out = Path(out_file)
    if out.suffix.lower() != ".pcapng":
        raise ValidationError("Capture file must end with .pcapng")
    res = run_command([tshark_path, "-i", str(int(interface_index)), "-a", f"duration:{int(seconds)}",
                       "-w", str(out)], timeout=int(seconds) + 30)
    if not res.ok:
        raise PcapError(f"Capture failed (administrator rights / Npcap may be required): {res.stderr.strip()}")
    return out
