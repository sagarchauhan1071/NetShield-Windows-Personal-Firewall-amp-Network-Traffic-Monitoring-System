"""Security alerts: acknowledge, dismiss, view details, mark confirmed (manual)."""
from __future__ import annotations

from PySide6.QtWidgets import (QComboBox, QDialog, QHBoxLayout, QLabel, QPushButton, QTextEdit, QVBoxLayout, QWidget)

from app.ui.widgets import SearchableTable, info, severity_color
from config import DISCLAIMER

COLUMNS = [("ID", "id"), ("Time", "timestamp"), ("Severity", "severity"), ("Title", "title"),
           ("Message", "message"), ("Status", "status")]


class AlertsView(QWidget):
    def __init__(self, ctx):
        super().__init__()
        self.ctx = ctx
        root = QVBoxLayout(self)
        note = QLabel(DISCLAIMER)
        note.setObjectName("banner"); note.setWordWrap(True)
        root.addWidget(note)
        bar = QHBoxLayout()
        self.status = QComboBox(); self.status.addItems(["All", "New", "Acknowledged", "Dismissed", "Confirmed"])
        self.sev = QComboBox(); self.sev.addItems(["All", "INFO", "LOW", "MEDIUM", "HIGH", "CRITICAL"])
        self.btn_ack, self.btn_dismiss = QPushButton("Acknowledge"), QPushButton("Dismiss")
        self.btn_details, self.btn_confirm = QPushButton("View Details"), QPushButton("Mark Confirmed (manual)")
        bar.addWidget(QLabel("Status")); bar.addWidget(self.status)
        bar.addWidget(QLabel("Severity")); bar.addWidget(self.sev)
        bar.addStretch(1)
        for b in (self.btn_details, self.btn_ack, self.btn_dismiss, self.btn_confirm):
            bar.addWidget(b)
        root.addLayout(bar)
        self.table = SearchableTable(COLUMNS, key_fn=lambda r: r["id"],
                                     color_fn=lambda r, k: severity_color(r["severity"]) if k == "severity" else None,
                                     placeholder="Search alerts…")
        root.addWidget(self.table, 1)
        self.status.currentTextChanged.connect(self.refresh)
        self.sev.currentTextChanged.connect(self.refresh)
        self.btn_ack.clicked.connect(lambda: self._set("Acknowledged"))
        self.btn_dismiss.clicked.connect(lambda: self._set("Dismissed"))
        self.btn_confirm.clicked.connect(lambda: self._set("Confirmed"))
        self.btn_details.clicked.connect(self.details)
        self.table.view.doubleClicked.connect(lambda *_: self.details())
        self.refresh()

    def refresh(self, *_args) -> None:
        self.table.set_rows(self.ctx.repos.alerts.list(self.status.currentText(), self.sev.currentText()))

    def _set(self, status: str) -> None:
        r = self.table.selected_row()
        if not r:
            info(self, "Select an alert", "Select an alert first.")
            return
        self.ctx.repos.alerts.set_status(r["id"], status)
        self.ctx.repos.audit.add(f"Alert {status.lower()}", f"alert #{r['id']}: {r['title']}")
        self.refresh()

    def details(self) -> None:
        r = self.table.selected_row()
        if not r:
            return
        data = self.ctx.repos.alerts.get_with_event(r["id"])
        lines = [f"Alert #{data['id']}  [{data['severity']}]  {data['timestamp']:%Y-%m-%d %H:%M:%S}",
                 f"Title: {data['title']}", f"Status: {data['status']}", "", data["message"], ""]
        if data["event"]:
            lines += [f"{k}: {v}" for k, v in data["event"].items()]
        lines += ["", DISCLAIMER]
        dlg = QDialog(self)
        dlg.setWindowTitle("Alert details")
        dlg.setMinimumSize(560, 380)
        text = QTextEdit(readOnly=True)
        text.setPlainText("\n".join(lines))
        QVBoxLayout(dlg).addWidget(text)
        dlg.exec()
