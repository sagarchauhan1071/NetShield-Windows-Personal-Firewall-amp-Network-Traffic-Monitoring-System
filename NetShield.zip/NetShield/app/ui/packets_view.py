"""Packet analysis: import .pcap/.pcapng (built-in parser), launch Wireshark, optional lab capture."""
from __future__ import annotations

from datetime import datetime

from PySide6.QtWidgets import (QFileDialog, QHBoxLayout, QInputDialog, QLabel, QPushButton, QTabWidget, QVBoxLayout, QWidget)

from app.core.tools import detect_tshark, detect_wireshark
from app.services import pcapture_service as pc
from app.ui.widgets import SearchableTable, confirm, info, run_async, warn
from app.utils.validators import ValidationError
from config import EXPORT_DIR


class PacketsView(QWidget):
    def __init__(self, ctx):
        super().__init__()
        self.ctx = ctx
        root = QVBoxLayout(self)
        self.tool_label = QLabel()
        self.tool_label.setObjectName("banner"); self.tool_label.setWordWrap(True)
        root.addWidget(self.tool_label)
        bar = QHBoxLayout()
        self.b_open, self.b_folder = QPushButton("Open Wireshark"), QPushButton("Open Capture Folder")
        self.b_import = QPushButton("Import Capture…"); self.b_import.setObjectName("primary")
        self.b_cap = QPushButton("Capture with TShark (lab)…")
        for b in (self.b_import, self.b_open, self.b_folder, self.b_cap):
            bar.addWidget(b)
        bar.addStretch(1)
        root.addLayout(bar)
        self.summary = QLabel("No capture imported. Import only captures you are authorized to analyze.")
        self.summary.setWordWrap(True)
        root.addWidget(self.summary)
        tabs = QTabWidget()
        self.t_pkts = SearchableTable([("Time", "ts"), ("Source IP", "src_ip"), ("Destination IP", "dst_ip"),
                                       ("Src Port", "src_port"), ("Dst Port", "dst_port"), ("Protocol", "protocol"),
                                       ("Length", "length")], max_rows=5000)
        self.t_proto = SearchableTable([("Protocol", "protocol"), ("Packets", "packets")])
        self.t_conv = SearchableTable([("Protocol", "protocol"), ("Endpoint A", "endpoint_a"), ("Endpoint B", "endpoint_b"),
                                       ("Packets", "packets"), ("Bytes", "bytes")])
        self.t_ips = SearchableTable([("Destination IP", "ip"), ("Packets", "packets")])
        self.t_ports = SearchableTable([("Protocol/Port", "port"), ("Packets", "packets")])
        for t, n in ((self.t_pkts, "Packets"), (self.t_proto, "Protocol Distribution"), (self.t_conv, "Top Conversations"),
                     (self.t_ips, "Top Destination IPs"), (self.t_ports, "Top Ports")):
            tabs.addTab(t, n)
        root.addWidget(tabs, 1)
        self._last_path = None
        self.b_import.clicked.connect(self.import_capture)
        self.b_open.clicked.connect(self.open_wireshark)
        self.b_folder.clicked.connect(self.open_folder)
        self.b_cap.clicked.connect(self.capture)
        self.refresh_tools()

    def refresh_tools(self) -> None:
        ws, ts = detect_wireshark(self.ctx.settings["wireshark_path"]), detect_tshark(self.ctx.settings["wireshark_path"])
        self.ws, self.ts = ws, ts
        self.tool_label.setText(f"Wireshark: {'installed – ' + ws.path if ws.installed else ws.message}\n"
                                f"TShark: {'installed – ' + ts.path if ts.installed else ts.message}\n"
                                "Built-in capture import/analysis works without Wireshark.")
        self.b_open.setEnabled(ws.installed)
        self.b_cap.setEnabled(ts.installed)

    def import_capture(self) -> None:
        path, _ = QFileDialog.getOpenFileName(self, "Import capture", str(EXPORT_DIR), "Captures (*.pcap *.pcapng *.cap)")
        if not path:
            return
        self._last_path = path
        self.summary.setText("Analyzing…")
        run_async(lambda: pc.analyze_pcap(path), self._imported)

    def _imported(self, s, err) -> None:
        if err:
            self.summary.setText("Import failed.")
            return warn(self, "Import failed", str(err))
        self.ctx.repos.audit.add("Capture imported", s.path)
        dur = f"{s.last_ts - s.first_ts:.1f}s" if s.last_ts and s.first_ts else "n/a"
        self.summary.setText(f"{s.path} [{s.fmt}] – {s.total_packets} packets ({s.parsed_packets} IP), "
                             f"{s.total_bytes} bytes, duration {dur}" + (" – truncated at packet limit" if s.truncated else ""))
        self.t_pkts.set_rows([{**p, "ts": datetime.fromtimestamp(p["timestamp"]).strftime("%H:%M:%S.%f")[:-3] if p["timestamp"] else ""}
                              for p in s.packets])
        self.t_proto.set_rows([{"protocol": k, "packets": v} for k, v in s.protocols.items()])
        self.t_conv.set_rows(s.top_conversations)
        self.t_ips.set_rows([{"ip": a, "packets": b} for a, b in s.top_dest_ips])
        self.t_ports.set_rows([{"port": a, "packets": b} for a, b in s.top_ports])

    def open_wireshark(self) -> None:
        try:
            pc.open_wireshark(self.ws.path, self._last_path)
        except Exception as exc:
            warn(self, "Wireshark", str(exc))

    def open_folder(self) -> None:
        try:
            pc.open_folder(EXPORT_DIR)
        except Exception as exc:
            warn(self, "Folder", str(exc))

    def capture(self) -> None:
        if not self.ctx.admin:
            return warn(self, "Administrator required", "Packet capture generally requires Administrator privileges and Npcap.")
        ifs = pc.tshark_interfaces(self.ts.path)
        if not ifs:
            return warn(self, "TShark", "No capture interfaces were reported by TShark.")
        choice, ok = QInputDialog.getItem(self, "Capture interface", "Interface", ifs, 0, False)
        if not ok:
            return
        secs, ok = QInputDialog.getInt(self, "Duration", "Seconds (max 300)", 20, 1, 300)
        if not ok or not confirm(self, "Confirm capture", "Capture traffic on this computer for the selected time?",
                                 "Only capture traffic on networks you own or are authorized to monitor. "
                                 "The file is saved to the exports folder."):
            return
        out = EXPORT_DIR / f"capture_{datetime.now():%Y%m%d_%H%M%S}.pcapng"
        idx = int(choice.split(".", 1)[0])
        self.ctx.repos.audit.add("Packet capture started", f"interface {idx}, {secs}s")
        run_async(lambda: pc.capture_with_tshark(self.ts.path, idx, secs, out),
                  lambda res, err: warn(self, "Capture failed", str(err)) if err else info(self, "Capture complete", f"Saved {res}"))
