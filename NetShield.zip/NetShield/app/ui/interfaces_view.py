"""Network interfaces and counters."""
from __future__ import annotations

from PySide6.QtCore import QTimer
from PySide6.QtWidgets import QHBoxLayout, QPushButton, QVBoxLayout, QWidget

from app.core.monitor import get_network_interfaces
from app.ui.widgets import SearchableTable

COLUMNS = [("Interface", "name"), ("MAC Address", "mac"), ("IPv4", "ipv4"), ("IPv6", "ipv6"), ("Status", "status"),
           ("Bytes Sent", "bytes_sent"), ("Bytes Received", "bytes_recv"), ("Packets Sent", "packets_sent"),
           ("Packets Received", "packets_recv")]


class InterfacesView(QWidget):
    def __init__(self, ctx):
        super().__init__()
        self.ctx = ctx
        root = QVBoxLayout(self)
        bar = QHBoxLayout()
        btn = QPushButton("Refresh")
        bar.addWidget(btn); bar.addStretch(1)
        root.addLayout(bar)
        self.table = SearchableTable(COLUMNS, key_fn=lambda r: r["name"], placeholder="Search interfaces…")
        root.addWidget(self.table)
        btn.clicked.connect(self.refresh)
        self.timer = QTimer(self)
        self.timer.timeout.connect(lambda: self.isVisible() and self.refresh())
        self.timer.start(5000)
        self.refresh()

    def refresh(self) -> None:
        rows = get_network_interfaces()
        self.table.set_rows(rows)
        try:
            self.ctx.repos.interfaces.replace_all(rows)
        except Exception:
            pass
