"""Main dashboard: status cards and six charts."""
from __future__ import annotations

import time
from collections import Counter
from datetime import datetime, timedelta

from PySide6.QtWidgets import QGridLayout, QHBoxLayout, QLabel, QVBoxLayout, QWidget

from app.core.firewall import firewall_overall
from app.core.monitor import network_status
from app.ui.theme import BAD, GOOD, WARN
from app.ui.widgets import ChartCanvas, StatCard, badge
from app.utils.helpers import period_start
from config import DISCLAIMER


class Dashboard(QWidget):
    def __init__(self, ctx):
        super().__init__()
        self.ctx, self._last_db = ctx, 0.0
        root = QVBoxLayout(self)
        status = QHBoxLayout()
        self.net_label, self.fw_label = QLabel("Network: …"), QLabel()
        badge(self.fw_label, "Firewall: checking…", "#6e7681")
        status.addWidget(QLabel("Network Status:"))
        status.addWidget(self.net_label)
        status.addSpacing(20)
        status.addWidget(QLabel("Firewall Status:"))
        status.addWidget(self.fw_label)
        status.addStretch(1)
        root.addLayout(status)
        self.fw_warning = QLabel("Windows Defender Firewall appears to be disabled.")
        self.fw_warning.setObjectName("danger")
        self.fw_warning.hide()
        root.addWidget(self.fw_warning)

        grid = QGridLayout()
        names = [("active", "Active Connections"), ("established", "Established Connections"),
                 ("listening", "Listening Ports"), ("blocked", "Blocked Connections (today)"),
                 ("alerts", "Security Alerts (new)"), ("suspicious", "Suspicious Events (today)")]
        self.cards = {k: StatCard(t) for k, t in names}
        for i, (k, _t) in enumerate(names):
            grid.addWidget(self.cards[k], 0, i)
        root.addLayout(grid)

        theme = ctx.settings.get("theme", "dark")
        self.charts = {k: ChartCanvas(t, theme) for k, t in (
            ("proto", "Connections by Protocol"), ("port", "Connections by Port"), ("dest", "Top Destination IPs"),
            ("action", "Allowed vs Blocked vs Observed (today)"), ("events", "Security Events Over Time (last hour)"),
            ("proc", "Top Network Processes"))}
        cg = QGridLayout()
        for i, c in enumerate(self.charts.values()):
            cg.addWidget(c, i // 3, i % 3)
        root.addLayout(cg, 1)
        note = QLabel(DISCLAIMER)
        note.setObjectName("note")
        root.addWidget(note)

    def set_firewall(self, status: dict | None) -> None:
        if not status:
            return
        overall = status.get("overall") or firewall_overall(status)
        text, color = {"ON": ("Firewall: ON", GOOD), "OFF": ("Firewall: OFF", BAD),
                       "PARTIAL": ("Firewall: PARTIALLY OFF", WARN)}.get(overall, ("Firewall: UNKNOWN", "#6e7681"))
        badge(self.fw_label, text, color)
        self.fw_warning.setVisible(overall in ("OFF", "PARTIAL"))

    def update_live(self, res) -> None:
        rows = res.rows
        self.net_label.setText(network_status())
        self.cards["active"].set_value(res.active)
        self.cards["established"].set_value(res.established)
        self.cards["listening"].set_value(res.listening)
        top = lambda counter, n=8: ([str(k) for k, _ in counter.most_common(n)], [v for _, v in counter.most_common(n)])  # noqa: E731
        l, v = top(Counter(r["protocol"] for r in rows))
        self.charts["proto"].pie(l, v)
        l, v = top(Counter(r["remote_port"] for r in rows if r["remote_port"]))
        self.charts["port"].bars(l, v)
        l, v = top(Counter(r["remote_ip"] for r in rows if r["remote_ip"]))
        self.charts["dest"].bars(l, v)
        l, v = top(Counter(r["process_name"] for r in rows))
        self.charts["proc"].bars(l, v)
        if time.time() - self._last_db > 5:
            self.refresh_db()
        self.set_firewall(res.firewall)

    def refresh_db(self) -> None:
        self._last_db = time.time()
        repos, today = self.ctx.repos, period_start("Today")
        acts = repos.connections.counts_by_action(today)
        self.cards["blocked"].set_value(acts["Blocked"])
        self.cards["alerts"].set_value(repos.alerts.count_new())
        self.cards["suspicious"].set_value(repos.events.count(today, min_severity="LOW", suspicious_only=True))
        self.charts["action"].bars(list(acts), list(acts.values()), horizontal=False)
        t = repos.events.timeline(datetime.now() - timedelta(hours=1), 5)
        self.charts["events"].line([a for a, _ in t], [b for _, b in t])

    def showEvent(self, event):  # noqa: N802
        self.refresh_db()
        super().showEvent(event)
