"""Main window: sidebar navigation, header, banners and monitoring thread control."""
from __future__ import annotations

from PySide6.QtCore import Qt
from PySide6.QtGui import QAction
from PySide6.QtWidgets import (QApplication, QHBoxLayout, QLabel, QListWidget, QMainWindow, QStackedWidget, QStyle,
                               QSystemTrayIcon, QVBoxLayout, QWidget)

from app.core.tools import is_windows
from app.ui.alerts_view import AlertsView
from app.ui.dashboard import Dashboard
from app.ui.firewall_view import FirewallView
from app.ui.interfaces_view import InterfacesView
from app.ui.monitor_view import MonitorView
from app.ui.packets_view import PacketsView
from app.ui.processes_view import ProcessesView
from app.ui.reports_view import ReportsView
from app.ui.rules_view import RulesView
from app.ui.settings_view import SettingsView
from app.ui.statistics_view import StatisticsView
from app.ui.theme import BAD, GOOD, WARN, build_stylesheet
from app.ui.widgets import badge, warn
from app.ui.workers import MonitorThread
from config import ADMIN_MSG_GENERAL, APP_NAME, APP_SUBTITLE, APP_TAGLINE, APP_VERSION


class MainWindow(QMainWindow):
    def __init__(self, ctx):
        super().__init__()
        self.ctx, self.thread, self._rows, self._alert_badge = ctx, None, [], 0
        self.setWindowTitle(f"{APP_NAME} v{APP_VERSION} – {APP_SUBTITLE}")
        self.resize(1400, 860)
        central = QWidget()
        self.setCentralWidget(central)
        root = QVBoxLayout(central)

        head = QHBoxLayout()
        title = QLabel(APP_NAME); title.setObjectName("title")
        sub = QLabel(f"{APP_SUBTITLE}\nNetShield v{APP_VERSION} · {APP_TAGLINE}"); sub.setObjectName("subtitle")
        self.admin_badge, self.fw_badge = QLabel(), QLabel()
        badge(self.admin_badge, "Administrator" if ctx.admin else "Standard user", GOOD if ctx.admin else WARN)
        badge(self.fw_badge, "Firewall: …", "#6e7681")
        head.addWidget(title); head.addSpacing(12); head.addWidget(sub); head.addStretch(1)
        head.addWidget(self.admin_badge); head.addWidget(self.fw_badge)
        root.addLayout(head)
        msgs = ([ADMIN_MSG_GENERAL] if not ctx.admin else []) + ([] if is_windows() else [
            "NetShield is designed for Windows 10/11. Firewall management is unavailable on this platform."])
        if msgs:
            banner = QLabel("  ".join(msgs)); banner.setObjectName("banner"); banner.setWordWrap(True)
            root.addWidget(banner)

        body = QHBoxLayout()
        self.nav, self.stack = QListWidget(), QStackedWidget()
        self.nav.setObjectName("nav"); self.nav.setFixedWidth(190)
        self.dashboard, self.monitor_view = Dashboard(ctx), MonitorView(ctx)
        self.firewall_view, self.rules_view = FirewallView(ctx), RulesView(ctx)
        self.alerts_view, self.processes_view = AlertsView(ctx), ProcessesView(ctx)
        self.interfaces_view, self.packets_view = InterfacesView(ctx), PacketsView(ctx)
        self.statistics_view = StatisticsView(ctx)
        self.reports_view = ReportsView(ctx, lambda: self._rows)
        self.settings_view = SettingsView(ctx)
        self.pages = [("Dashboard", self.dashboard), ("Monitor", self.monitor_view), ("Firewall", self.firewall_view),
                      ("Rules", self.rules_view), ("Alerts", self.alerts_view), ("Processes", self.processes_view),
                      ("Interfaces", self.interfaces_view), ("Packets", self.packets_view),
                      ("Statistics", self.statistics_view), ("Reports", self.reports_view), ("Settings", self.settings_view)]
        for name, page in self.pages:
            self.nav.addItem(name)
            self.stack.addWidget(page)
        self.nav.currentRowChanged.connect(self.stack.setCurrentIndex)
        self.nav.setCurrentRow(0)
        body.addWidget(self.nav); body.addWidget(self.stack, 1)
        root.addLayout(body, 1)

        self.monitor_view.start_requested.connect(self.start_monitoring)
        self.monitor_view.pause_requested.connect(self.pause_monitoring)
        self.monitor_view.stop_requested.connect(self.stop_monitoring)
        self.monitor_view.rule_requested.connect(self.rule_from_connection)
        self.firewall_view.status_changed.connect(self.on_firewall)
        self.settings_view.settings_saved.connect(self.on_settings)
        self.tray = QSystemTrayIcon(self.style().standardIcon(QStyle.StandardPixmap.SP_ComputerIcon), self) \
            if QSystemTrayIcon.isSystemTrayAvailable() else None
        if self.tray:
            self.tray.show()
        self.statusBar().showMessage("Ready. Monitoring is stopped.")
        self.ctx.repos.audit.add("Application started", f"NetShield v{APP_VERSION}")
        if ctx.settings["auto_start_monitoring"]:
            self.start_monitoring()

    # ---------------------------------------------------------- monitoring control
    def start_monitoring(self) -> None:
        if self.thread and self.thread.isRunning():
            if self.thread.paused:
                self.thread.resume()
                self.monitor_view.set_state("running")
            return
        self.thread = MonitorThread(self.ctx.monitor, lambda: self.ctx.settings["refresh_interval"], self)
        self.thread.cycle_done.connect(self.on_cycle)
        self.thread.failed.connect(self.on_failure)
        self.thread.start()
        self.monitor_view.set_state("running")
        self.statusBar().showMessage("Monitoring started")
        self.ctx.repos.audit.add("Monitoring started")

    def pause_monitoring(self) -> None:
        if self.thread and self.thread.isRunning():
            self.thread.pause()
            self.monitor_view.set_state("paused")
            self.statusBar().showMessage("Monitoring paused")

    def stop_monitoring(self) -> None:
        if self.thread:
            self.thread.stop()
            self.thread.wait(8000)
            self.thread = None
            self.ctx.repos.audit.add("Monitoring stopped")
        self.monitor_view.set_state("stopped")
        self.statusBar().showMessage("Monitoring stopped")

    def on_failure(self, msg: str) -> None:
        self.statusBar().showMessage(f"Monitoring error: {msg}", 10000)

    def on_cycle(self, res) -> None:
        self._rows = res.rows
        self.monitor_view.update_rows(res.rows)
        self.dashboard.update_live(res)
        self.processes_view.update_rows(res.rows)
        if res.firewall:
            self.on_firewall(res.firewall)
        if res.alerts:
            self.alerts_view.refresh()
            worst = max(res.alerts, key=lambda a: ["INFO", "LOW", "MEDIUM", "HIGH", "CRITICAL"].index(a["severity"]))
            self.statusBar().showMessage(f"{len(res.alerts)} new alert(s): {worst['message']}", 10000)
            if self.tray and worst["severity"] in ("MEDIUM", "HIGH", "CRITICAL"):
                self.tray.showMessage(f"NetShield – {worst['severity']}", worst["message"])
        self.nav.item(4).setText(f"Alerts ({n})" if (n := self.ctx.repos.alerts.count_new()) else "Alerts")
        self.statusBar().showMessage(f"{res.active} active · {res.established} established · {res.listening} listening "
                                     f"· cycle {res.duration * 1000:.0f} ms", 3000) if not res.alerts else None

    def on_firewall(self, status: dict) -> None:
        overall = status.get("overall", "UNKNOWN")
        badge(self.fw_badge, {"ON": "Firewall: ON", "OFF": "Firewall: OFF", "PARTIAL": "Firewall: PARTIAL"}.get(overall, "Firewall: UNKNOWN"),
              {"ON": GOOD, "OFF": BAD, "PARTIAL": WARN}.get(overall, "#6e7681"))
        self.dashboard.set_firewall(status)
        self.firewall_view.set_status(status)

    def on_settings(self) -> None:
        QApplication.instance().setStyleSheet(build_stylesheet(self.ctx.settings["theme"]))
        self.packets_view.refresh_tools()

    def rule_from_connection(self, row: dict) -> None:
        prefill = {"direction": "Outbound", "action": "Block", "protocol": row["protocol"] if row["protocol"] in ("TCP", "UDP") else "TCP",
                   "remote_ip": row["remote_ip"], "remote_port": str(row["remote_port"] or ""),
                   "program_path": row.get("exe_path", ""), "description": f"Created from observed connection of {row['process_name']}"}
        self.nav.setCurrentRow(3)
        self.rules_view.new_rule(prefill)

    def closeEvent(self, event):  # noqa: N802
        self.stop_monitoring()
        self.ctx.repos.audit.add("Application closed")
        super().closeEvent(event)
