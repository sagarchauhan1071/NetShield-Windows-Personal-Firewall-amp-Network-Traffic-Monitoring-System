"""Dark cybersecurity theme."""
PALETTES = {
    "dark": {"bg": "#0d1117", "panel": "#161b22", "border": "#30363d", "text": "#c9d1d9", "muted": "#8b949e",
             "accent": "#2f81f7", "alt": "#1c2128"},
    "midnight": {"bg": "#05080f", "panel": "#0c121c", "border": "#233044", "text": "#d6e2f0", "muted": "#7f93ab",
                 "accent": "#00b4d8", "alt": "#101826"},
}
SEVERITY_COLORS = {"INFO": "#8b949e", "LOW": "#58a6ff", "MEDIUM": "#d29922", "HIGH": "#f0883e", "CRITICAL": "#f85149"}
GOOD, BAD, WARN = "#3fb950", "#f85149", "#d29922"


def build_stylesheet(theme: str = "dark") -> str:
    p = PALETTES.get(theme, PALETTES["dark"])
    return f"""
* {{ font-family: 'Segoe UI', 'Inter', Arial; font-size: 10pt; color: {p['text']}; }}
QMainWindow, QWidget {{ background: {p['bg']}; }}
QLabel {{ background: transparent; }}
QLabel#title {{ font-size: 20pt; font-weight: 700; color: {p['accent']}; }}
QLabel#subtitle, QLabel#muted {{ color: {p['muted']}; }}
QLabel#banner {{ background: #3b2f10; color: #f2cc60; border: 1px solid #6e5a1a; border-radius: 6px; padding: 6px 10px; }}
QLabel#danger {{ background: #3d1518; color: #ff7b72; border: 1px solid #8e2a2f; border-radius: 6px; padding: 6px 10px; font-weight: 600; }}
QLabel#note {{ color: {p['muted']}; font-style: italic; }}
QListWidget#nav {{ background: {p['panel']}; border: none; border-right: 1px solid {p['border']}; outline: 0; padding-top: 6px; }}
QListWidget#nav::item {{ padding: 10px 16px; border-left: 3px solid transparent; }}
QListWidget#nav::item:selected {{ background: {p['alt']}; border-left: 3px solid {p['accent']}; color: white; }}
QListWidget#nav::item:hover {{ background: {p['alt']}; }}
QFrame#card {{ background: {p['panel']}; border: 1px solid {p['border']}; border-radius: 8px; }}
QLabel#cardValue {{ font-size: 22pt; font-weight: 700; color: white; }}
QLabel#cardTitle {{ color: {p['muted']}; font-size: 9pt; }}
QPushButton {{ background: {p['alt']}; border: 1px solid {p['border']}; border-radius: 6px; padding: 6px 14px; }}
QPushButton:hover {{ border-color: {p['accent']}; }}
QPushButton:disabled {{ color: #565f6b; }}
QPushButton#primary {{ background: {p['accent']}; color: white; border: none; font-weight: 600; }}
QPushButton#danger {{ background: #8e2a2f; color: white; border: none; }}
QLineEdit, QComboBox, QSpinBox, QDateEdit, QTextEdit, QPlainTextEdit {{ background: {p['panel']}; border: 1px solid {p['border']};
    border-radius: 5px; padding: 4px 6px; selection-background-color: {p['accent']}; }}
QComboBox QAbstractItemView {{ background: {p['panel']}; selection-background-color: {p['accent']}; }}
QTableView {{ background: {p['panel']}; alternate-background-color: {p['alt']}; gridline-color: {p['border']};
    border: 1px solid {p['border']}; selection-background-color: #1f4a8c; selection-color: white; }}
QHeaderView::section {{ background: {p['alt']}; padding: 5px; border: none; border-right: 1px solid {p['border']};
    border-bottom: 1px solid {p['border']}; font-weight: 600; }}
QTabWidget::pane {{ border: 1px solid {p['border']}; }}
QTabBar::tab {{ background: {p['panel']}; padding: 7px 16px; border: 1px solid {p['border']}; }}
QTabBar::tab:selected {{ background: {p['alt']}; border-bottom: 2px solid {p['accent']}; }}
QGroupBox {{ border: 1px solid {p['border']}; border-radius: 6px; margin-top: 10px; padding-top: 8px; }}
QGroupBox::title {{ subcontrol-origin: margin; left: 10px; padding: 0 4px; color: {p['muted']}; }}
QStatusBar {{ background: {p['panel']}; border-top: 1px solid {p['border']}; }}
QScrollBar:vertical {{ background: {p['bg']}; width: 12px; }} QScrollBar::handle:vertical {{ background: {p['border']}; border-radius: 5px; min-height: 24px; }}
QScrollBar:horizontal {{ background: {p['bg']}; height: 12px; }} QScrollBar::handle:horizontal {{ background: {p['border']}; border-radius: 5px; }}
QScrollBar::add-line, QScrollBar::sub-line {{ width: 0; height: 0; }}
QMessageBox, QDialog {{ background: {p['panel']}; }}
"""
