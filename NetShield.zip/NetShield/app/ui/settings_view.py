"""Settings, configuration test and tool detection."""
from __future__ import annotations

from PySide6.QtCore import Signal
from PySide6.QtWidgets import (QCheckBox, QComboBox, QFileDialog, QFormLayout, QGroupBox, QHBoxLayout, QLabel,
                               QLineEdit, QPushButton, QSpinBox, QTextEdit, QVBoxLayout, QWidget)

from app.core.tools import detect_tools, is_admin, system_info
from app.core.monitor import get_network_interfaces
from app.ui.widgets import confirm, info, run_async, warn
from app.utils.validators import ValidationError, validate_directory
from config import SETTING_SPECS, default_settings, validate_settings


class SettingsView(QWidget):
    settings_saved = Signal()

    def __init__(self, ctx):
        super().__init__()
        self.ctx, self.w = ctx, {}
        root = QVBoxLayout(self)
        box = QGroupBox("Settings")
        form = QFormLayout(box)
        for key, spec in SETTING_SPECS.items():
            if spec.kind == "int":
                w = QSpinBox(); w.setRange(spec.lo, spec.hi)
            elif spec.kind == "bool":
                w = QCheckBox()
            elif spec.kind == "choice":
                w = QComboBox(); w.addItems(spec.choices)
            elif key == "network_interface":
                w = QComboBox(); w.setEditable(True)
                w.addItems([""] + [i["name"] for i in get_network_interfaces()])
            else:
                w = QLineEdit()
            self.w[key] = w
            if key in ("report_dir", "wireshark_path"):
                row = QHBoxLayout(); row.addWidget(w)
                b = QPushButton("Browse…"); b.clicked.connect(lambda _c=False, k=key: self.browse(k)); row.addWidget(b)
                form.addRow(spec.label, row)
            else:
                form.addRow(spec.label, w)
        root.addWidget(box)
        bar = QHBoxLayout()
        self.b_save, self.b_reset, self.b_test = QPushButton("Save"), QPushButton("Reset"), QPushButton("Test Configuration")
        self.b_save.setObjectName("primary")
        for b in (self.b_save, self.b_reset, self.b_test):
            bar.addWidget(b)
        bar.addStretch(1)
        root.addLayout(bar)
        self.out = QTextEdit(readOnly=True)
        root.addWidget(self.out, 1)
        self.b_save.clicked.connect(self.save)
        self.b_reset.clicked.connect(self.reset)
        self.b_test.clicked.connect(self.test)
        self.load(ctx.settings)

    def load(self, values: dict) -> None:
        for key, w in self.w.items():
            v = values.get(key, SETTING_SPECS[key].default)
            if isinstance(w, QSpinBox): w.setValue(int(v))
            elif isinstance(w, QCheckBox): w.setChecked(bool(v))
            elif isinstance(w, QComboBox): w.setCurrentText(str(v))
            else: w.setText(str(v))

    def collect(self) -> dict:
        out = {}
        for key, w in self.w.items():
            out[key] = (w.value() if isinstance(w, QSpinBox) else w.isChecked() if isinstance(w, QCheckBox)
                        else w.currentText() if isinstance(w, QComboBox) else w.text())
        return out

    def browse(self, key: str) -> None:
        if key == "report_dir":
            path = QFileDialog.getExistingDirectory(self, "Report directory", self.w[key].text())
        else:
            path, _ = QFileDialog.getOpenFileName(self, "Wireshark executable", "", "Wireshark.exe (Wireshark.exe)")
        if path:
            self.w[key].setText(path)

    def save(self) -> None:
        clean, errors = validate_settings(self.collect())
        if errors:
            return warn(self, "Invalid settings", "\n".join(errors))
        try:
            validate_directory(clean["report_dir"], create=True)
        except ValidationError as exc:
            return warn(self, "Invalid settings", str(exc))
        self.ctx.repos.settings.set_many(clean)
        self.ctx.apply_settings(clean)
        self.ctx.repos.audit.add("Settings changed", ", ".join(sorted(clean)))
        self.settings_saved.emit()
        info(self, "Settings", "Settings saved.")

    def reset(self) -> None:
        if confirm(self, "Reset settings", "Restore all settings to their defaults?"):
            self.ctx.repos.settings.reset()
            defaults = default_settings()
            self.ctx.apply_settings(defaults)
            self.load(defaults)
            self.ctx.repos.audit.add("Settings changed", "reset to defaults")
            self.settings_saved.emit()

    def test(self) -> None:
        clean, errors = validate_settings(self.collect())
        lines = ["Configuration test", "=" * 40]
        lines += [f"[FAIL] {e}" for e in errors] or ["[ OK ] All settings are valid"]
        try:
            lines.append(f"[ OK ] Report directory writable: {validate_directory(clean['report_dir'], create=True)}")
        except ValidationError as exc:
            lines.append(f"[FAIL] Report directory: {exc}")
        lines.append(f"[ OK ] Database: {self.ctx.db.path} ({self.ctx.db.size_mb():.2f} MB)")
        lines.append(f"[{' OK ' if is_admin() else 'WARN'}] Administrator privileges: {'yes' if is_admin() else 'no (firewall rule management disabled)'}")
        lines += [f"{k}: {v}" for k, v in system_info().items()]
        self.out.setPlainText("\n".join(lines) + "\n\nDetecting tools…")

        def finish(tools, err):
            extra = [f"[{' OK ' if t.installed else 'MISS'}] {t.name}: {'Installed' if t.installed else 'Not installed'} "
                     f"{t.version} {t.path} {t.message}".strip() for t in (tools or [])]
            self.out.setPlainText("\n".join(lines + [""] + extra))

        run_async(lambda: detect_tools(clean), finish)
