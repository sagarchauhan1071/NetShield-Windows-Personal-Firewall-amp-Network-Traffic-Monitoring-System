"""Windows Defender Firewall status page."""
from __future__ import annotations

from datetime import datetime

from PySide6.QtCore import Signal
from PySide6.QtWidgets import QGridLayout, QHBoxLayout, QLabel, QPushButton, QVBoxLayout, QWidget

from app.core.firewall import firewall_overall
from app.core.tools import is_windows
from app.ui.theme import BAD, GOOD
from app.ui.widgets import StatCard, run_async
from config import ADMIN_MSG_GENERAL


class FirewallView(QWidget):
    status_changed = Signal(dict)

    def __init__(self, ctx):
        super().__init__()
        self.ctx = ctx
        root = QVBoxLayout(self)
        self.warning = QLabel("Windows Defender Firewall appears to be disabled.")
        self.warning.setObjectName("danger")
        self.warning.hide()
        root.addWidget(self.warning)
        self.overall = StatCard("Windows Defender Firewall", "…")
        root.addWidget(self.overall)
        grid = QGridLayout()
        self.cards = {p: StatCard(f"{p} profile", "…") for p in ("Domain", "Private", "Public")}
        for i, c in enumerate(self.cards.values()):
            grid.addWidget(c, 0, i)
        root.addLayout(grid)
        bar = QHBoxLayout()
        self.refresh_btn = QPushButton("Refresh")
        self.refresh_btn.setObjectName("primary")
        self.stamp = QLabel("")
        self.stamp.setObjectName("muted")
        bar.addWidget(self.refresh_btn)
        bar.addWidget(self.stamp)
        bar.addStretch(1)
        root.addLayout(bar)
        for text in (ADMIN_MSG_GENERAL if not ctx.admin else "Running with Administrator privileges.",
                     "NetShield never disables or enables the firewall automatically. It manages and monitors; "
                     "rules are enforced by Windows Defender Firewall.",
                     "" if is_windows() else "This computer is not running Windows; status is unavailable."):
            if text:
                lab = QLabel(text)
                lab.setObjectName("note")
                lab.setWordWrap(True)
                root.addWidget(lab)
        self.msg = QLabel("")
        self.msg.setWordWrap(True)
        root.addWidget(self.msg)
        root.addStretch(1)
        self.refresh_btn.clicked.connect(self.refresh)
        self.refresh()

    def refresh(self) -> None:
        self.refresh_btn.setEnabled(False)
        run_async(self.ctx.fw_manager.get_status, self._done)

    def _done(self, status, error) -> None:
        self.refresh_btn.setEnabled(True)
        if error or not status:
            self.msg.setText(f"Unable to query firewall: {error}")
            return
        self.set_status(status)
        self.status_changed.emit(status)

    def set_status(self, status: dict) -> None:
        for p, card in self.cards.items():
            s = status.get(p, "UNKNOWN")
            card.set_value(s, GOOD if s == "ON" else BAD if s == "OFF" else None)
        overall = status.get("overall") or firewall_overall(status)
        self.overall.set_value({"ON": "ON", "OFF": "OFF", "PARTIAL": "PARTIALLY OFF"}.get(overall, "UNKNOWN"),
                               GOOD if overall == "ON" else BAD if overall in ("OFF", "PARTIAL") else None)
        self.warning.setVisible(overall in ("OFF", "PARTIAL"))
        self.msg.setText(status.get("error", ""))
        self.stamp.setText(f"Last checked {datetime.now():%H:%M:%S}")
