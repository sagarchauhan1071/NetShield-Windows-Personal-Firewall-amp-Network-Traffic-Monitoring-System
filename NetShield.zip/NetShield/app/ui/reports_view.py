"""Report generation page."""
from __future__ import annotations

import os
from pathlib import Path

from PySide6.QtWidgets import QComboBox, QHBoxLayout, QLabel, QPushButton, QVBoxLayout, QWidget

from app.services import pcapture_service as pc
from app.ui.widgets import SearchableTable, info, run_async, warn
from config import PERIODS


class ReportsView(QWidget):
    def __init__(self, ctx, live_rows_provider):
        super().__init__()
        self.ctx, self.live_rows = ctx, live_rows_provider
        root = QVBoxLayout(self)
        bar = QHBoxLayout()
        self.period = QComboBox(); self.period.addItems(PERIODS); self.period.setCurrentText("Today")
        bar.addWidget(QLabel("Period")); bar.addWidget(self.period)
        self.buttons = {}
        for fmt in ("PDF", "HTML", "CSV", "JSON"):
            b = QPushButton(f"Generate {fmt}")
            b.clicked.connect(lambda _c=False, f=fmt.lower(): self.generate([f]))
            self.buttons[fmt] = b
            bar.addWidget(b)
        allb = QPushButton("Generate All"); allb.setObjectName("primary")
        allb.clicked.connect(lambda: self.generate(["pdf", "html", "csv", "json"]))
        bar.addWidget(allb)
        bar.addStretch(1)
        root.addLayout(bar)
        self.status = QLabel("")
        self.status.setObjectName("muted")
        root.addWidget(self.status)
        self.table = SearchableTable([("Created", "created_at"), ("Title", "title"), ("Format", "format"),
                                      ("Period", "period"), ("Path", "path")], key_fn=lambda r: r["id"] if "id" in r else r["path"],
                                     placeholder="Search generated reports…")
        root.addWidget(self.table, 1)
        row = QHBoxLayout()
        b_open, b_folder = QPushButton("Open Selected Report"), QPushButton("Open Report Folder")
        row.addWidget(b_open); row.addWidget(b_folder); row.addStretch(1)
        root.addLayout(row)
        b_open.clicked.connect(self.open_selected)
        b_folder.clicked.connect(lambda: self._folder())
        self.refresh()

    def refresh(self) -> None:
        self.table.set_rows(self.ctx.repos.reports.list())

    def generate(self, formats: list[str]) -> None:
        period, live = self.period.currentText(), list(self.live_rows())
        self.status.setText("Generating…")

        def work():
            data = self.ctx.reports.collect(period, live or None)
            return [str(self.ctx.reports.generate(f, period, report=data)) for f in formats]

        run_async(work, self._done)

    def _done(self, paths, err) -> None:
        if err:
            self.status.setText("Report generation failed.")
            return warn(self, "Report", str(err))
        self.status.setText("Generated: " + ", ".join(Path(p).name for p in paths))
        self.refresh()

    def open_selected(self) -> None:
        r = self.table.selected_row()
        if not r:
            return info(self, "Reports", "Select a report first.")
        if os.name == "nt" and Path(r["path"]).is_file():
            os.startfile(r["path"])  # type: ignore[attr-defined]
        else:
            info(self, "Report location", r["path"])

    def _folder(self) -> None:
        try:
            pc.open_folder(self.ctx.settings["report_dir"])
        except Exception as exc:
            info(self, "Report folder", f"{self.ctx.settings['report_dir']}\n\n{exc}")
