"""Real-time connection monitor + searchable history."""
from __future__ import annotations

from datetime import datetime, timedelta

from PySide6.QtCore import QDate, Signal
from PySide6.QtWidgets import (QCheckBox, QComboBox, QDateEdit, QHBoxLayout, QLabel, QLineEdit, QPushButton,
                               QTabWidget, QVBoxLayout, QWidget)

from app.ui.widgets import SearchableTable, severity_color
from app.ui.theme import BAD, GOOD, WARN

COLUMNS = [("Process", "process_name"), ("PID", "pid"), ("Local IP", "local_ip"), ("Local Port", "local_port"),
           ("Remote IP", "remote_ip"), ("Remote Port", "remote_port"), ("Protocol", "protocol"),
           ("Status", "status"), ("Action", "action"), ("Risk", "risk_level"), ("Timestamp", "timestamp"),
           ("Application", "exe_path")]
HIST_COLUMNS = [c for c in COLUMNS if c[1] != "exe_path"] + [("Rule", "rule")]


def _color(row, key):
    if key == "risk_level":
        return {"Low": "#58a6ff", "Medium": WARN, "High": "#f0883e", "Critical": BAD}.get(row.get("risk_level"))
    if key == "action":
        return {"Blocked": BAD, "Allowed": GOOD}.get(row.get("action"))
    return None


class MonitorView(QWidget):
    start_requested = Signal()
    pause_requested = Signal()
    stop_requested = Signal()
    rule_requested = Signal(dict)

    def __init__(self, ctx):
        super().__init__()
        self.ctx, self._page = ctx, 1
        root = QVBoxLayout(self)
        tabs = QTabWidget()
        root.addWidget(tabs)

        live = QWidget()
        lv = QVBoxLayout(live)
        bar = QHBoxLayout()
        self.btn_start, self.btn_pause, self.btn_stop, self.btn_clear = (
            QPushButton("Start Monitoring"), QPushButton("Pause Monitoring"), QPushButton("Stop Monitoring"),
            QPushButton("Clear View"))
        self.btn_start.setObjectName("primary")
        self.btn_rule = QPushButton("Create Firewall Rule from Selection…")
        self.proto = QComboBox()
        self.proto.addItems(["All", "TCP", "UDP"])
        self.state = QComboBox()
        self.state.addItems(["All", "LISTEN", "ESTABLISHED", "TIME_WAIT", "CLOSE_WAIT", "SYN_SENT", "SYN_RECEIVED", "CLOSED"])
        for w in (self.btn_start, self.btn_pause, self.btn_stop, self.btn_clear):
            bar.addWidget(w)
        bar.addStretch(1)
        bar.addWidget(QLabel("Protocol"))
        bar.addWidget(self.proto)
        bar.addWidget(QLabel("State"))
        bar.addWidget(self.state)
        lv.addLayout(bar)
        self.state_label = QLabel("Monitoring stopped")
        self.state_label.setObjectName("muted")
        lv.addWidget(self.state_label)
        self.table = SearchableTable(COLUMNS, key_fn=lambda r: r["key"] if "key" in r else (
            r["pid"], r["protocol"], r["local_ip"], r["local_port"], r["remote_ip"], r["remote_port"]),
            color_fn=_color, max_rows=ctx.settings["max_display_rows"])
        lv.addWidget(self.table, 1)
        lv.addWidget(self.btn_rule)
        tabs.addTab(live, "Live Connections")

        hist = QWidget()
        hv = QVBoxLayout(hist)
        f = QHBoxLayout()
        self.h_use_date = QCheckBox("Date")
        self.h_from, self.h_to = QDateEdit(QDate.currentDate().addDays(-7)), QDateEdit(QDate.currentDate())
        for d in (self.h_from, self.h_to):
            d.setCalendarPopup(True)
            d.setDisplayFormat("yyyy-MM-dd")
        self.h_proc, self.h_ip, self.h_port = QLineEdit(), QLineEdit(), QLineEdit()
        for w, ph in ((self.h_proc, "Process"), (self.h_ip, "IP"), (self.h_port, "Port")):
            w.setPlaceholderText(ph)
        self.h_proto = QComboBox(); self.h_proto.addItems(["All", "TCP", "UDP"])
        self.h_action = QComboBox(); self.h_action.addItems(["All", "Allowed", "Blocked", "Observed"])
        self.h_risk = QComboBox(); self.h_risk.addItems(["All", "Normal", "Low", "Medium", "High", "Critical"])
        btn_search = QPushButton("Search")
        btn_search.setObjectName("primary")
        for w in (self.h_use_date, self.h_from, self.h_to, self.h_proc, self.h_ip, self.h_port, self.h_proto,
                  self.h_action, self.h_risk, btn_search):
            f.addWidget(w)
        hv.addLayout(f)
        self.hist_table = SearchableTable(HIST_COLUMNS, color_fn=_color, max_rows=500)
        hv.addWidget(self.hist_table, 1)
        pg = QHBoxLayout()
        self.prev_btn, self.next_btn, self.page_label = QPushButton("◀ Previous"), QPushButton("Next ▶"), QLabel()
        pg.addWidget(self.prev_btn); pg.addWidget(self.page_label); pg.addWidget(self.next_btn); pg.addStretch(1)
        hv.addLayout(pg)
        tabs.addTab(hist, "History (Logged)")

        self.btn_start.clicked.connect(self.start_requested)
        self.btn_pause.clicked.connect(self.pause_requested)
        self.btn_stop.clicked.connect(self.stop_requested)
        self.btn_clear.clicked.connect(self.table.clear)
        self.btn_rule.clicked.connect(self._emit_rule)
        self.proto.currentTextChanged.connect(self._refilter)
        self.state.currentTextChanged.connect(self._refilter)
        btn_search.clicked.connect(lambda: self.load_history(1))
        self.prev_btn.clicked.connect(lambda: self.load_history(self._page - 1))
        self.next_btn.clicked.connect(lambda: self.load_history(self._page + 1))
        self.set_state("stopped")
        self.load_history(1)

    def set_state(self, state: str) -> None:
        self.btn_start.setEnabled(state != "running")
        self.btn_pause.setEnabled(state == "running")
        self.btn_stop.setEnabled(state != "stopped")
        self.state_label.setText({"running": "Monitoring running…", "paused": "Monitoring paused",
                                  "stopped": "Monitoring stopped"}[state])

    def _refilter(self) -> None:
        p, s = self.proto.currentText(), self.state.currentText()
        self.table.set_filter(lambda r: (p == "All" or r["protocol"] == p) and (s == "All" or r["status"] == s))

    def update_rows(self, rows: list[dict]) -> None:
        self.table.max_rows = self.ctx.settings["max_display_rows"]
        self.table.set_rows(rows)

    def _emit_rule(self) -> None:
        r = self.table.selected_row()
        if r:
            self.rule_requested.emit(r)

    def load_history(self, page: int) -> None:
        self._page = max(page, 1)
        flt = {"process": self.h_proc.text().strip(), "ip": self.h_ip.text().strip(), "port": self.h_port.text().strip(),
               "protocol": self.h_proto.currentText(), "action": self.h_action.currentText(),
               "risk_level": self.h_risk.currentText()}
        if self.h_use_date.isChecked():
            d0, d1 = self.h_from.date().toPython(), self.h_to.date().toPython()
            flt["date_from"] = datetime(d0.year, d0.month, d0.day)
            flt["date_to"] = datetime(d1.year, d1.month, d1.day) + timedelta(days=1)
        rows, total = self.ctx.repos.connections.query(flt, self._page, 200)
        self.hist_table.set_rows(rows)
        pages = max((total + 199) // 200, 1)
        self.page_label.setText(f"Page {self._page} of {pages} ({total} records)")
        self.prev_btn.setEnabled(self._page > 1)
        self.next_btn.setEnabled(self._page < pages)
