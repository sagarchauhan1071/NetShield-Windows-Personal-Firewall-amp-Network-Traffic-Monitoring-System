"""Firewall rule management: searchable list, creation dialog with confirmation, enable/disable/delete."""
from __future__ import annotations

from PySide6.QtWidgets import (QCheckBox, QComboBox, QDialog, QDialogButtonBox, QFormLayout, QHBoxLayout, QLabel,
                               QLineEdit, QPushButton, QTextEdit, QVBoxLayout, QWidget)

from app.core.firewall import FirewallError, describe_rule_effect
from app.ui.widgets import SearchableTable, confirm, info, run_async, warn
from app.utils.validators import ValidationError
from config import ADMIN_MSG_RULES

COLUMNS = [("Rule Name", "rule_name"), ("Direction", "direction"), ("Action", "action"), ("Protocol", "protocol"),
           ("Port", "port"), ("Program", "program_path"), ("Profile", "profile"), ("Enabled", "enabled_txt"),
           ("Status", "status")]


class RuleDialog(QDialog):
    def __init__(self, parent, prefill: dict | None = None):
        super().__init__(parent)
        self.setWindowTitle("New Firewall Rule")
        self.setMinimumWidth(480)
        p = prefill or {}
        form = QFormLayout()
        self.name = QLineEdit(p.get("rule_name", ""))
        self.name.setPlaceholderText("e.g. Block_Test_Port (NetShield_ prefix is added automatically)")
        self.direction = QComboBox(); self.direction.addItems(["Outbound", "Inbound"])
        self.action = QComboBox(); self.action.addItems(["Block", "Allow"])
        self.protocol = QComboBox(); self.protocol.addItems(["TCP", "UDP", "ICMPv4", "ICMPv6", "Any"])
        self.local_port, self.remote_port = QLineEdit(p.get("local_port", "")), QLineEdit(p.get("remote_port", ""))
        self.local_ip, self.remote_ip = QLineEdit(p.get("local_ip", "")), QLineEdit(p.get("remote_ip", ""))
        self.program = QLineEdit(p.get("program_path", ""))
        self.profiles = {n: QCheckBox(n) for n in ("Domain", "Private", "Public")}
        prof = QHBoxLayout()
        for n, cb in self.profiles.items():
            cb.setChecked(True if not p.get("profile") or p["profile"] == "Any" else n in p["profile"])
            prof.addWidget(cb)
        self.enabled = QCheckBox("Enabled"); self.enabled.setChecked(True)
        self.desc = QLineEdit(p.get("description", "Created with NetShield"))
        self.direction.setCurrentText(p.get("direction", "Outbound"))
        self.action.setCurrentText(p.get("action", "Block"))
        self.protocol.setCurrentText(p.get("protocol", "TCP"))
        for label, w in (("Rule Name", self.name), ("Direction", self.direction), ("Action", self.action),
                         ("Protocol", self.protocol), ("Local Port", self.local_port), ("Remote Port", self.remote_port),
                         ("Local IP", self.local_ip), ("Remote IP", self.remote_ip), ("Program Path", self.program)):
            form.addRow(label, w)
        form.addRow("Profile", prof)
        form.addRow("", self.enabled)
        form.addRow("Description", self.desc)
        btns = QDialogButtonBox(QDialogButtonBox.StandardButton.Ok | QDialogButtonBox.StandardButton.Cancel)
        btns.button(QDialogButtonBox.StandardButton.Ok).setText("Review && Create…")
        btns.accepted.connect(self.accept)
        btns.rejected.connect(self.reject)
        lay = QVBoxLayout(self)
        lay.addLayout(form)
        lay.addWidget(btns)

    def data(self) -> dict:
        chosen = [n for n, cb in self.profiles.items() if cb.isChecked()]
        return {"rule_name": self.name.text(), "direction": self.direction.currentText(),
                "action": self.action.currentText(), "protocol": self.protocol.currentText(),
                "local_port": self.local_port.text(), "remote_port": self.remote_port.text(),
                "local_ip": self.local_ip.text(), "remote_ip": self.remote_ip.text(),
                "program_path": self.program.text(), "profile": ",".join(chosen) or "Any",
                "enabled": self.enabled.isChecked(), "description": self.desc.text()}


class RuleDetails(QDialog):
    def __init__(self, parent, rule: dict, windows_state: dict | None):
        super().__init__(parent)
        self.setWindowTitle(f"Rule: {rule['rule_name']}")
        self.setMinimumSize(520, 360)
        text = QTextEdit(readOnly=True)
        lines = [f"{k}: {v}" for k, v in rule.items()]
        lines.append(f"\nWindows state: {windows_state or 'not reported (check administrator rights / rule exists)'}")
        lines.append("\n" + describe_rule_effect({k: rule[k] for k in rule}))
        text.setPlainText("\n".join(lines))
        lay = QVBoxLayout(self)
        lay.addWidget(text)


class RulesView(QWidget):
    def __init__(self, ctx):
        super().__init__()
        self.ctx, self._win = ctx, {}
        root = QVBoxLayout(self)
        bar = QHBoxLayout()
        self.btn_new = QPushButton("New Rule…"); self.btn_new.setObjectName("primary")
        self.btn_view, self.btn_enable, self.btn_disable = QPushButton("View"), QPushButton("Enable"), QPushButton("Disable")
        self.btn_delete = QPushButton("Delete"); self.btn_delete.setObjectName("danger")
        self.btn_refresh = QPushButton("Refresh")
        for b in (self.btn_new, self.btn_view, self.btn_enable, self.btn_disable, self.btn_delete, self.btn_refresh):
            bar.addWidget(b)
        bar.addStretch(1)
        root.addLayout(bar)
        self.table = SearchableTable(COLUMNS, key_fn=lambda r: r["rule_name"], placeholder="Search rules…")
        root.addWidget(self.table, 1)
        note = QLabel("Only NetShield-managed rules (prefix NetShield_) are listed and can be changed. "
                      "Every change requires confirmation and is written to the audit log.")
        note.setObjectName("note"); note.setWordWrap(True)
        root.addWidget(note)
        self.btn_new.clicked.connect(lambda: self.new_rule())
        self.btn_view.clicked.connect(self.view_rule)
        self.btn_enable.clicked.connect(lambda: self.toggle(True))
        self.btn_disable.clicked.connect(lambda: self.toggle(False))
        self.btn_delete.clicked.connect(self.delete)
        self.btn_refresh.clicked.connect(self.refresh)
        self.refresh()

    def refresh(self) -> None:
        self._render()
        run_async(self.ctx.fw_service.windows_states, self._states)

    def _states(self, states, error) -> None:
        self._win = states or {}
        self._render()

    def _render(self) -> None:
        rows = []
        for r in self.ctx.repos.rules.list():
            w = self._win.get(r["rule_name"])
            status = "Not reported" if not self._win and not self.ctx.admin else (
                "Missing in Windows" if w is None else ("Applied" if str(w.get("Enabled")) == "True" else "Present (disabled)"))
            rows.append({**r, "port": " / ".join(x for x in (r["local_port"], r["remote_port"]) if x) or "Any",
                         "enabled_txt": "Yes" if r["enabled"] else "No", "status": status,
                         "program_path": r["program_path"] or "All programs"})
        self.table.set_rows(rows)

    def _need_admin(self) -> bool:
        if not self.ctx.admin:
            warn(self, "Administrator required", ADMIN_MSG_RULES)
            return True
        return False

    def new_rule(self, prefill: dict | None = None) -> None:
        if self._need_admin():
            return
        dlg = RuleDialog(self, prefill)
        if dlg.exec() != QDialog.DialogCode.Accepted:
            return
        try:
            clean, effect = self.ctx.fw_service.prepare(dlg.data(), must_exist_program=True)
        except (ValidationError, ValueError) as exc:
            warn(self, "Invalid rule", str(exc))
            return
        if not confirm(self, "Confirm rule creation", f"Create firewall rule '{clean['rule_name']}'?", effect):
            return
        run_async(lambda: self.ctx.fw_service.create_rule(clean, confirmed=True), self._created)

    def _created(self, res, error) -> None:
        if error:
            warn(self, "Rule not created", str(error))
        else:
            info(self, "Firewall rule", "Rule created successfully.")
        self.refresh()

    def _selected(self):
        r = self.table.selected_row()
        if not r:
            info(self, "Select a rule", "Select a rule first.")
        return r

    def view_rule(self) -> None:
        r = self._selected()
        if r:
            clean = {k: v for k, v in self.ctx.repos.rules.get(r["rule_name"]).items()}
            RuleDetails(self, clean, self._win.get(r["rule_name"])).exec()

    def toggle(self, enabled: bool) -> None:
        r = self._selected()
        if not r or self._need_admin():
            return
        word = "enable" if enabled else "disable"
        if confirm(self, f"Confirm {word}", f"{word.capitalize()} rule '{r['rule_name']}'?",
                   "The change is applied to Windows Defender Firewall and logged."):
            run_async(lambda: self.ctx.fw_service.set_enabled(r["rule_name"], enabled, confirmed=True), self._changed)

    def delete(self) -> None:
        r = self._selected()
        if not r or self._need_admin():
            return
        if confirm(self, "Confirm deletion", f"Permanently delete rule '{r['rule_name']}'?",
                   "The rule is removed from Windows Defender Firewall and from NetShield. This cannot be undone."):
            run_async(lambda: self.ctx.fw_service.delete_rule(r["rule_name"], confirmed=True), self._changed)

    def _changed(self, res, error) -> None:
        if error:
            warn(self, "Operation failed", str(error))
        self.refresh()
