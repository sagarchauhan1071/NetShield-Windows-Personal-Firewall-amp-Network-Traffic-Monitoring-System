"""Per-process network activity, trust information and IP classification."""
from __future__ import annotations

from collections import defaultdict

from PySide6.QtWidgets import QHBoxLayout, QLabel, QPushButton, QSplitter, QTextEdit, QVBoxLayout, QWidget
from PySide6.QtCore import Qt

from app.ui.widgets import SearchableTable, info, run_async
from app.utils.helpers import classify_ip, get_signature_info, reverse_dns

COLUMNS = [("Process", "process_name"), ("PID", "pid"), ("Executable Path", "exe_path"), ("Connections", "count"),
           ("Remote IPs", "remote_ips"), ("Remote Ports", "remote_ports"), ("First Seen", "first_seen"),
           ("Last Seen", "last_seen"), ("Risk", "risk"), ("Trust", "trust")]
RISK_ORDER = ["Normal", "Low", "Medium", "High", "Critical"]


class ProcessesView(QWidget):
    def __init__(self, ctx):
        super().__init__()
        self.ctx, self._rows, self._by_proc = ctx, [], {}
        root = QVBoxLayout(self)
        split = QSplitter(Qt.Orientation.Vertical)
        root.addWidget(split)
        self.table = SearchableTable(COLUMNS, key_fn=lambda r: (r["process_name"], r["exe_path"]),
                                     placeholder="Search processes…")
        split.addWidget(self.table)
        bottom = QWidget()
        bl = QVBoxLayout(bottom)
        bar = QHBoxLayout()
        self.btn_sig = QPushButton("Verify Signature / Publisher")
        self.btn_dns = QPushButton("Resolve Remote Hostnames (DNS)")
        bar.addWidget(self.btn_sig); bar.addWidget(self.btn_dns); bar.addStretch(1)
        bl.addLayout(bar)
        self.detail = QTextEdit(readOnly=True)
        bl.addWidget(self.detail)
        note = QLabel("An unknown publisher, high port or unfamiliar IP is not evidence of malicious activity. "
                      "Items are shown as 'Unknown / Requires Investigation'. DNS lookups run only when you click the button.")
        note.setObjectName("note"); note.setWordWrap(True)
        bl.addWidget(note)
        split.addWidget(bottom)
        self.table.selection_changed.connect(self.show_detail)
        self.btn_sig.clicked.connect(self.verify)
        self.btn_dns.clicked.connect(self.resolve)

    def update_rows(self, conns: list[dict]) -> None:
        groups: dict = defaultdict(list)
        for c in conns:
            groups[(c["process_name"], c["exe_path"])].append(c)
        known = {(p["name"], p["exe_path"]): p for p in self.ctx.repos.processes.list()}
        rows, self._by_proc = [], groups
        for (name, exe), items in groups.items():
            db = known.get((name, exe), {})
            remote = [c for c in items if c["remote_ip"]]
            risk = max((c["risk_level"] for c in items), key=RISK_ORDER.index, default="Normal")
            rows.append({"process_name": name, "pid": items[0]["pid"], "exe_path": exe or "(unavailable)",
                         "count": len(items), "remote_ips": ", ".join(sorted({c["remote_ip"] for c in remote})[:4]),
                         "remote_ports": ", ".join(str(p) for p in sorted({c["remote_port"] for c in remote})[:6]),
                         "first_seen": db.get("first_seen"), "last_seen": db.get("last_seen"), "risk": risk,
                         "trust": db.get("trust") or "Unknown / Requires Investigation"})
        self.table.set_rows(sorted(rows, key=lambda r: -r["count"]))

    def show_detail(self) -> None:
        r = self.table.selected_row()
        if not r:
            return
        items = self._by_proc.get((r["process_name"], "" if r["exe_path"] == "(unavailable)" else r["exe_path"]), [])
        lines = [f"Process: {r['process_name']} (PID {r['pid']})", f"Executable: {r['exe_path']}",
                 f"Trust: {r['trust']}", f"Connections: {len(items)}", "", "Remote addresses:"]
        seen = set()
        for c in items:
            if c["remote_ip"] and (c["remote_ip"], c["remote_port"], c["protocol"]) not in seen:
                seen.add((c["remote_ip"], c["remote_port"], c["protocol"]))
                lines.append(f"  {c['remote_ip']}:{c['remote_port']}  {c['protocol']}  {c['status']}  "
                             f"[{classify_ip(c['remote_ip'])}]")
        self.detail.setPlainText("\n".join(lines))

    def verify(self) -> None:
        r = self.table.selected_row()
        if not r:
            return info(self, "Select a process", "Select a process first.")
        exe = "" if r["exe_path"] == "(unavailable)" else r["exe_path"]
        run_async(lambda: get_signature_info(exe), lambda res, err: self._sig_done(r, exe, res, err))

    def _sig_done(self, r, exe, res, err) -> None:
        if err or not res:
            return info(self, "Signature check", f"Unable to verify: {err}")
        self.ctx.repos.processes.set_signature(r["process_name"], exe, res["signature_status"], res["publisher"], res["trust"])
        self.detail.append(f"\nFile exists: {res['file_exists']}\nSignature status: {res['signature_status']}\n"
                           f"Publisher: {res['publisher'] or 'unknown'}\nAssessment: {res['trust']}")

    def resolve(self) -> None:
        r = self.table.selected_row()
        if not r:
            return info(self, "Select a process", "Select a process first.")
        ips = sorted({c["remote_ip"] for c in self._by_proc.get((r["process_name"], "" if r["exe_path"] == "(unavailable)" else r["exe_path"]), [])
                      if classify_ip(c["remote_ip"]) == "Public IP"})[:10]
        run_async(lambda: {ip: reverse_dns(ip) for ip in ips},
                  lambda res, err: self.detail.append("\nReverse DNS:\n" + "\n".join(f"  {ip} -> {h or '(no PTR record)'}" for ip, h in (res or {}).items())))
