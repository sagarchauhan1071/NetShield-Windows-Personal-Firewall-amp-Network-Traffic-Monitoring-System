"""Background monitoring thread (QThread) with clean start / pause / stop semantics."""
from __future__ import annotations

import threading

from PySide6.QtCore import QThread, Signal

from app.utils.logger import get_logger

log = get_logger("worker")


class MonitorThread(QThread):
    cycle_done = Signal(object)
    failed = Signal(str)

    def __init__(self, service, interval_getter, parent=None):
        super().__init__(parent)
        self.service, self.interval_getter = service, interval_getter
        self._stop_evt, self._pause_evt = threading.Event(), threading.Event()

    @property
    def paused(self) -> bool:
        return self._pause_evt.is_set()

    def run(self) -> None:
        while not self._stop_evt.is_set():
            if not self._pause_evt.is_set():
                try:
                    self.cycle_done.emit(self.service.run_cycle())
                except Exception as exc:
                    log.exception("Monitoring cycle failed")
                    self.failed.emit(str(exc))
            self._stop_evt.wait(max(1, int(self.interval_getter())))

    def pause(self) -> None:
        self._pause_evt.set()

    def resume(self) -> None:
        self._pause_evt.clear()

    def stop(self) -> None:
        self._stop_evt.set()
        self._pause_evt.clear()
