"""Network statistics over selectable periods."""
from __future__ import annotations

from PySide6.QtCore import QTimer
from PySide6.QtWidgets import QComboBox, QGridLayout, QHBoxLayout, QLabel, QVBoxLayout, QWidget

from app.ui.widgets import ChartCanvas, SearchableTable
from app.utils.helpers import period_start
from config import PERIODS


class StatisticsView(QWidget):
    def __init__(self, ctx):
        super().__init__()
        self.ctx = ctx
        root = QVBoxLayout(self)
        bar = QHBoxLayout()
        self.period = QComboBox()
        self.period.addItems(PERIODS)
        self.period.setCurrentText("Today")
        bar.addWidget(QLabel("Period"))
        bar.addWidget(self.period)
        bar.addStretch(1)
        root.addLayout(bar)
        grid = QGridLayout()
        self.metrics = SearchableTable([("Metric", "metric"), ("Value", "value")], placeholder="Filter metrics…")
        grid.addWidget(self.metrics, 0, 0, 2, 1)
        theme = ctx.settings.get("theme", "dark")
        self.c_proc, self.c_port = ChartCanvas("Top Processes", theme), ChartCanvas("Top Destination Ports", theme)
        self.c_ip = ChartCanvas("Top Destination IPs", theme)
        grid.addWidget(self.c_proc, 0, 1)
        grid.addWidget(self.c_port, 0, 2)
        grid.addWidget(self.c_ip, 1, 1, 1, 2)
        grid.setColumnStretch(0, 1); grid.setColumnStretch(1, 1); grid.setColumnStretch(2, 1)
        root.addLayout(grid, 1)
        self.period.currentTextChanged.connect(self.refresh)
        self.timer = QTimer(self)
        self.timer.timeout.connect(self.refresh)
        self.timer.start(15000)
        self.refresh()

    def refresh(self, *_a) -> None:
        if not self.isVisible() and self.metrics.model.rows:
            return
        since, repos = period_start(self.period.currentText()), self.ctx.repos
        s = repos.connections.stats(since)
        tp, tport, tip = (repos.connections.top(c, since, 8) for c in ("process_name", "remote_port", "remote_ip"))
        rows = [("Total Connections", s["total"]), ("TCP Connections", s["tcp"]), ("UDP Connections", s["udp"]),
                ("Listening Ports", s["listening"]), ("Unique Remote IPs", s["unique_remote_ips"]),
                ("Blocked Events", s["blocked"]), ("Security Events", repos.events.count(since)),
                ("Top Process", tp[0][0] if tp else "-"), ("Top Destination Port", tport[0][0] if tport else "-")]
        self.metrics.set_rows([{"metric": m, "value": v} for m, v in rows])
        self.c_proc.bars([a for a, _ in tp], [b for _, b in tp])
        self.c_port.bars([str(a) for a, _ in tport], [b for _, b in tport])
        self.c_ip.bars([a for a, _ in tip], [b for _, b in tip])

    def showEvent(self, e):  # noqa: N802
        self.refresh()
        super().showEvent(e)
