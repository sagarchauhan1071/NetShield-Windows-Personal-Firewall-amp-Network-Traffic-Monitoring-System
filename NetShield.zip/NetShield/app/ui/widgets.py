"""Reusable Qt widgets: cards, searchable tables, charts, confirmation dialogs, async runner."""
from __future__ import annotations

import os

os.environ.setdefault("QT_API", "pyside6")
import matplotlib

matplotlib.use("QtAgg")
from datetime import datetime

from matplotlib.backends.backend_qtagg import FigureCanvasQTAgg
from matplotlib.figure import Figure
from PySide6.QtCore import (QAbstractTableModel, QModelIndex, QObject, QRunnable, QSortFilterProxyModel, Qt,
                            QThreadPool, QTimer, Signal, Slot)
from PySide6.QtGui import QColor
from PySide6.QtWidgets import (QAbstractItemView, QFrame, QHBoxLayout, QHeaderView, QLabel, QLineEdit,
                               QMessageBox, QTableView, QVBoxLayout, QWidget)

from app.ui.theme import PALETTES, SEVERITY_COLORS

BLANK_ZERO = {"remote_port"}


class StatCard(QFrame):
    def __init__(self, title: str, value: str = "0", parent=None):
        super().__init__(parent)
        self.setObjectName("card")
        lay = QVBoxLayout(self)
        self._title, self._value = QLabel(title), QLabel(value)
        self._title.setObjectName("cardTitle")
        self._value.setObjectName("cardValue")
        lay.addWidget(self._title)
        lay.addWidget(self._value)

    def set_value(self, value, color: str | None = None) -> None:
        self._value.setText(str(value))
        self._value.setStyleSheet(f"color: {color};" if color else "")


def badge(label: QLabel, text: str, color: str) -> None:
    label.setText(text)
    label.setStyleSheet(f"background:{color}; color:white; border-radius:9px; padding:2px 10px; font-weight:600;")


class DictTableModel(QAbstractTableModel):
    def __init__(self, columns, color_fn=None, parent=None):
        super().__init__(parent)
        self.columns, self.rows, self.color_fn = columns, [], color_fn

    def rowCount(self, parent=QModelIndex()):
        return 0 if parent.isValid() else len(self.rows)

    def columnCount(self, parent=QModelIndex()):
        return 0 if parent.isValid() else len(self.columns)

    def headerData(self, section, orientation, role=Qt.ItemDataRole.DisplayRole):
        if role == Qt.ItemDataRole.DisplayRole and orientation == Qt.Orientation.Horizontal:
            return self.columns[section][0]
        return None

    def data(self, index, role=Qt.ItemDataRole.DisplayRole):
        if not index.isValid():
            return None
        row, key = self.rows[index.row()], self.columns[index.column()][1]
        val = row.get(key)
        if role == Qt.ItemDataRole.DisplayRole:
            if val is None or (key in BLANK_ZERO and val == 0):
                return ""
            return val.strftime("%Y-%m-%d %H:%M:%S") if isinstance(val, datetime) else str(val)
        if role == Qt.ItemDataRole.UserRole:
            if isinstance(val, datetime):
                return val.isoformat()
            return val if isinstance(val, (int, float)) else ("" if val is None else str(val))
        if role == Qt.ItemDataRole.ForegroundRole and self.color_fn:
            color = self.color_fn(row, key)
            return QColor(color) if color else None
        return None

    def set_rows(self, rows):
        self.beginResetModel()
        self.rows = rows
        self.endResetModel()


class SearchableTable(QWidget):
    """Table with search box, optional pre-filter, bounded row count and selection preservation."""
    selection_changed = Signal()

    def __init__(self, columns, key_fn=None, color_fn=None, max_rows=2000, placeholder="Search…", parent=None):
        super().__init__(parent)
        self.key_fn, self.max_rows, self._filter_fn, self._all = key_fn, max_rows, None, []
        self.model = DictTableModel(columns, color_fn, self)
        self.proxy = QSortFilterProxyModel(self)
        self.proxy.setSourceModel(self.model)
        self.proxy.setFilterCaseSensitivity(Qt.CaseSensitivity.CaseInsensitive)
        self.proxy.setFilterKeyColumn(-1)
        self.proxy.setSortRole(Qt.ItemDataRole.UserRole)
        self.search = QLineEdit()
        self.search.setPlaceholderText(placeholder)
        self.search.setClearButtonEnabled(True)
        self.search.textChanged.connect(self.proxy.setFilterFixedString)
        self.search.textChanged.connect(lambda _t: QTimer.singleShot(0, self._update_count))
        self.count_label = QLabel()
        self.count_label.setObjectName("muted")
        self.view = QTableView()
        self.view.setModel(self.proxy)
        self.view.setSortingEnabled(True)
        self.view.setAlternatingRowColors(True)
        self.view.setSelectionBehavior(QAbstractItemView.SelectionBehavior.SelectRows)
        self.view.setSelectionMode(QAbstractItemView.SelectionMode.SingleSelection)
        self.view.setEditTriggers(QAbstractItemView.EditTrigger.NoEditTriggers)
        self.view.verticalHeader().setVisible(False)
        self.view.horizontalHeader().setStretchLastSection(True)
        self.view.horizontalHeader().setSectionResizeMode(QHeaderView.ResizeMode.Interactive)
        self.view.selectionModel().selectionChanged.connect(lambda *_: self.selection_changed.emit())
        self.top = QHBoxLayout()
        self.top.addWidget(self.search, 1)
        self.top.addWidget(self.count_label)
        lay = QVBoxLayout(self)
        lay.setContentsMargins(0, 0, 0, 0)
        lay.addLayout(self.top)
        lay.addWidget(self.view)
        for i in range(len(columns)):
            self.view.setColumnWidth(i, 110)

    def set_filter(self, fn) -> None:
        self._filter_fn = fn
        self._apply()

    def set_rows(self, rows) -> None:
        self._all = rows
        self._apply()

    def clear(self) -> None:
        self._all = []
        self._apply()

    def _apply(self) -> None:
        rows = [r for r in self._all if self._filter_fn(r)] if self._filter_fn else self._all
        key, bar = self.selected_key(), self.view.verticalScrollBar()
        pos = bar.value()
        self.model.set_rows(rows[: self.max_rows])
        if key is not None and self.key_fn:
            for i, r in enumerate(self.model.rows):
                if self.key_fn(r) == key:
                    idx = self.proxy.mapFromSource(self.model.index(i, 0))
                    if idx.isValid():
                        self.view.selectRow(idx.row())
                    break
        bar.setValue(pos)
        self._update_count()

    def _update_count(self) -> None:
        shown, total = self.proxy.rowCount(), len(self._all)
        capped = " (display capped)" if total > self.max_rows else ""
        self.count_label.setText(f"{shown} shown / {total} total{capped}")

    def selected_row(self) -> dict | None:
        idxs = self.view.selectionModel().selectedRows()
        if not idxs:
            return None
        src = self.proxy.mapToSource(idxs[0])
        return self.model.rows[src.row()] if 0 <= src.row() < len(self.model.rows) else None

    def selected_key(self):
        row = self.selected_row()
        return self.key_fn(row) if row is not None and self.key_fn else None


class ChartCanvas(FigureCanvasQTAgg):
    PALETTE = ["#2f81f7", "#3fb950", "#d29922", "#f85149", "#a371f7", "#39c5cf", "#f0883e", "#db61a2"]

    def __init__(self, title: str, theme: str = "dark", parent=None):
        self.colors = PALETTES.get(theme, PALETTES["dark"])
        self.fig = Figure(figsize=(4, 2.6), dpi=100, facecolor=self.colors["panel"])
        super().__init__(self.fig)
        self.setParent(parent)
        self.title = title
        self.ax = self.fig.add_subplot(111)
        self.setMinimumHeight(220)
        self.draw_empty()

    def _style(self) -> None:
        c = self.colors
        self.ax.set_facecolor(c["panel"])
        self.ax.set_title(self.title, color=c["text"], fontsize=10, loc="left")
        self.ax.tick_params(colors=c["muted"], labelsize=8)
        for s in self.ax.spines.values():
            s.set_color(c["border"])

    def _finish(self) -> None:
        try:
            self.fig.tight_layout()
        except Exception:
            pass
        self.draw_idle()

    def draw_empty(self) -> None:
        self.ax.clear()
        self._style()
        self.ax.text(0.5, 0.5, "No data yet", ha="center", va="center", color=self.colors["muted"],
                     transform=self.ax.transAxes)
        self.ax.set_xticks([])
        self.ax.set_yticks([])
        self._finish()

    def bars(self, labels, values, horizontal=True, color=None) -> None:
        if not labels or not sum(values):
            return self.draw_empty()
        self.ax.clear()
        self._style()
        labels = [str(l)[:20] for l in labels]
        if horizontal:
            self.ax.barh(labels[::-1], values[::-1], color=color or self.PALETTE[0])
        else:
            self.ax.bar(labels, values, color=color or self.PALETTE[0])
        self._finish()

    def pie(self, labels, values) -> None:
        if not labels or not sum(values):
            return self.draw_empty()
        self.ax.clear()
        self._style()
        self.ax.pie(values, labels=labels, colors=self.PALETTE[: len(values)], textprops={"color": self.colors["text"], "fontsize": 8},
                    autopct="%1.0f%%", pctdistance=0.75, wedgeprops={"edgecolor": self.colors["panel"]})
        self._finish()

    def line(self, labels, values) -> None:
        if not labels:
            return self.draw_empty()
        self.ax.clear()
        self._style()
        self.ax.plot(range(len(values)), values, color=self.PALETTE[3], marker="o", markersize=3)
        step = max(len(labels) // 6, 1)
        self.ax.set_xticks(range(0, len(labels), step))
        self.ax.set_xticklabels(labels[::step], rotation=0)
        self.ax.grid(color=self.colors["border"], alpha=0.5)
        self._finish()


def severity_color(name: str) -> str | None:
    return SEVERITY_COLORS.get(str(name).upper())


def confirm(parent, title: str, text: str, detail: str | None = None) -> bool:
    box = QMessageBox(parent)
    box.setIcon(QMessageBox.Icon.Question)
    box.setWindowTitle(title)
    box.setText(text)
    if detail:
        box.setInformativeText(detail)
    box.setStandardButtons(QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.Cancel)
    box.setDefaultButton(QMessageBox.StandardButton.Cancel)
    return box.exec() == QMessageBox.StandardButton.Yes


def info(parent, title: str, text: str) -> None:
    QMessageBox.information(parent, title, text)


def warn(parent, title: str, text: str) -> None:
    QMessageBox.warning(parent, title, text)


# ---------------------------------------------------------------- async helper (keeps GUI responsive)
class _Signals(QObject):
    done = Signal(object, object, object, object)


class _Dispatcher(QObject):
    @Slot(object, object, object, object)
    def deliver(self, task, callback, result, error):
        _LIVE.discard(task)
        if callback:
            callback(result, error)


class _Task(QRunnable):
    def __init__(self, fn, callback, dispatcher):
        super().__init__()
        self.setAutoDelete(False)   # Python keeps the task alive until its result is delivered
        self.fn, self.callback = fn, callback
        self.sig = _Signals()
        self.sig.done.connect(dispatcher.deliver)

    def run(self):
        try:
            result, error = self.fn(), None
        except Exception as exc:  # delivered to callback on the GUI thread
            result, error = None, exc
        try:
            self.sig.done.emit(self, self.callback, result, error)
        except RuntimeError:   # application is shutting down
            pass


_LIVE: set = set()
_dispatcher: _Dispatcher | None = None


def run_async(fn, callback=None) -> None:
    """Run fn() in the global thread pool; callback(result, error) runs on the GUI thread."""
    global _dispatcher
    if _dispatcher is None:
        _dispatcher = _Dispatcher()
    task = _Task(fn, callback, _dispatcher)
    _LIVE.add(task)
    QThreadPool.globalInstance().start(task)
