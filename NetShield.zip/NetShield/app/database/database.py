"""SQLite engine/session management, schema creation and retention cleanup."""
from __future__ import annotations

import os
from contextlib import contextmanager
from datetime import datetime, timedelta
from pathlib import Path

from sqlalchemy import create_engine, delete, event, func, select
from sqlalchemy.orm import sessionmaker

from app.database.models import Alert, AuditLog, Base, Connection, SecurityEvent
from app.utils.logger import get_logger

log = get_logger("database")


def _pragmas(dbapi_conn, _record):
    cur = dbapi_conn.cursor()
    cur.execute("PRAGMA journal_mode=WAL")
    cur.execute("PRAGMA foreign_keys=ON")
    cur.execute("PRAGMA synchronous=NORMAL")
    cur.close()


class Database:
    def __init__(self, path):
        self.path = Path(path)
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self.engine = create_engine(f"sqlite:///{self.path}", connect_args={"check_same_thread": False})
        event.listen(self.engine, "connect", _pragmas)
        self._factory = sessionmaker(self.engine, expire_on_commit=False)

    def init_db(self) -> None:
        Base.metadata.create_all(self.engine)

    @contextmanager
    def session_scope(self):
        session = self._factory()
        try:
            yield session
            session.commit()
        except Exception:
            session.rollback()
            raise
        finally:
            session.close()

    def size_mb(self) -> float:
        total = 0
        for suffix in ("", "-wal", "-shm"):
            p = Path(str(self.path) + suffix)
            if p.exists():
                total += p.stat().st_size
        return total / 1048576

    def cleanup(self, retention_days: int, max_db_mb: int) -> dict:
        """Delete expired rows; if still above the size cap, trim the oldest connection rows."""
        cutoff = datetime.now() - timedelta(days=retention_days)
        removed = {"connections": 0, "events": 0, "alerts": 0, "audit": 0}
        with self.session_scope() as s:
            removed["alerts"] = s.execute(delete(Alert).where(Alert.timestamp < cutoff)).rowcount
            removed["events"] = s.execute(delete(SecurityEvent).where(
                SecurityEvent.timestamp < cutoff,
                ~SecurityEvent.id.in_(select(Alert.event_id).where(Alert.event_id.is_not(None))))).rowcount
            removed["connections"] = s.execute(delete(Connection).where(Connection.timestamp < cutoff)).rowcount
            removed["audit"] = s.execute(delete(AuditLog).where(
                AuditLog.timestamp < datetime.now() - timedelta(days=365))).rowcount
        for _ in range(5):
            if self.size_mb() <= max_db_mb:
                break
            with self.session_scope() as s:
                total = s.scalar(select(func.count()).select_from(Connection)) or 0
                if total == 0:
                    break
                ids = s.scalars(select(Connection.id).order_by(Connection.id).limit(max(total // 5, 1))).all()
                s.execute(delete(Connection).where(Connection.id.in_(ids)))
                removed["connections"] += len(ids)
            self.vacuum()
        if sum(removed.values()):
            self.vacuum()
            log.info("Cleanup removed %s", removed)
        return removed

    def vacuum(self) -> None:
        try:
            with self.engine.connect().execution_options(isolation_level="AUTOCOMMIT") as conn:
                conn.exec_driver_sql("VACUUM")
        except Exception as exc:  # pragma: no cover - best effort
            log.warning("VACUUM failed: %s", exc)

    def dispose(self) -> None:
        self.engine.dispose()
