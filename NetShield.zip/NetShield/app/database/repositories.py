"""Repository layer. All queries are parameterised through SQLAlchemy; rows are returned as plain dicts."""
from __future__ import annotations

import getpass
from collections import Counter
from datetime import datetime, timedelta

from sqlalchemy import distinct, func, insert, or_, select, delete
from sqlalchemy.exc import IntegrityError

from app.database.database import Database
from app.database.models import (Alert, AuditLog, Connection, FirewallRule, NetworkInterface, Process,
                                 Report, SecurityEvent, Setting)

SEVERITIES = ("INFO", "LOW", "MEDIUM", "HIGH", "CRITICAL")
SUSPICIOUS_TYPES = ("Suspicious Connection", "Repeated Connection", "New Listening Port", "Unknown Process")


class DuplicateRuleError(Exception):
    pass


def row_dict(obj) -> dict:
    return {c.name: getattr(obj, c.name) for c in obj.__table__.columns}


class _Repo:
    def __init__(self, db: Database):
        self.db = db


class ConnectionRepository(_Repo):
    def add_many(self, rows: list[dict]) -> int:
        if not rows:
            return 0
        with self.db.session_scope() as s:
            s.execute(insert(Connection), rows)
        return len(rows)

    @staticmethod
    def _filters(stmt, f: dict):
        if f.get("since"):
            stmt = stmt.where(Connection.timestamp >= f["since"])
        if f.get("date_from"):
            stmt = stmt.where(Connection.timestamp >= f["date_from"])
        if f.get("date_to"):
            stmt = stmt.where(Connection.timestamp < f["date_to"])
        if f.get("process"):
            stmt = stmt.where(Connection.process_name.icontains(f["process"], autoescape=True))
        if f.get("ip"):
            stmt = stmt.where(or_(Connection.remote_ip.icontains(f["ip"], autoescape=True),
                                  Connection.local_ip.icontains(f["ip"], autoescape=True)))
        if f.get("port"):
            try:
                port = int(f["port"])
                stmt = stmt.where(or_(Connection.remote_port == port, Connection.local_port == port))
            except ValueError:
                stmt = stmt.where(Connection.id < 0)
        for key, col in (("protocol", Connection.protocol), ("action", Connection.action),
                         ("risk_level", Connection.risk_level)):
            if f.get(key) and f[key] != "All":
                stmt = stmt.where(col == f[key])
        return stmt

    def query(self, filters: dict | None = None, page: int = 1, page_size: int = 200) -> tuple[list[dict], int]:
        filters = filters or {}
        with self.db.session_scope() as s:
            total = s.scalar(self._filters(select(func.count()).select_from(Connection), filters)) or 0
            stmt = self._filters(select(Connection), filters).order_by(Connection.id.desc())
            rows = s.scalars(stmt.offset(max(page - 1, 0) * page_size).limit(page_size)).all()
            return [row_dict(r) for r in rows], total

    def count(self, filters: dict | None = None) -> int:
        with self.db.session_scope() as s:
            return s.scalar(self._filters(select(func.count()).select_from(Connection), filters or {})) or 0

    def counts_by_action(self, since: datetime) -> dict:
        with self.db.session_scope() as s:
            rows = s.execute(select(Connection.action, func.count()).where(Connection.timestamp >= since)
                             .group_by(Connection.action)).all()
        out = {"Allowed": 0, "Blocked": 0, "Observed": 0}
        out.update({a: n for a, n in rows})
        return out

    def top(self, column: str, since: datetime, limit: int = 10) -> list[tuple]:
        col = getattr(Connection, column)
        stmt = select(col, func.count().label("n")).where(Connection.timestamp >= since)
        if column == "remote_ip":
            stmt = stmt.where(Connection.remote_ip != "")
        if column == "remote_port":
            stmt = stmt.where(Connection.remote_port > 0)
        with self.db.session_scope() as s:
            return [tuple(r) for r in s.execute(stmt.group_by(col).order_by(func.count().desc()).limit(limit)).all()]

    def stats(self, since: datetime) -> dict:
        w = Connection.timestamp >= since
        with self.db.session_scope() as s:
            total = s.scalar(select(func.count()).select_from(Connection).where(w)) or 0
            proto = dict(s.execute(select(Connection.protocol, func.count()).where(w)
                                   .group_by(Connection.protocol)).all())
            listening = s.scalar(select(func.count(distinct(Connection.local_port))).where(
                w, Connection.status == "LISTEN")) or 0
            unique_ips = s.scalar(select(func.count(distinct(Connection.remote_ip))).where(
                w, Connection.remote_ip != "")) or 0
            blocked = s.scalar(select(func.count()).select_from(Connection).where(
                w, Connection.action == "Blocked")) or 0
        return {"total": total, "tcp": proto.get("TCP", 0), "udp": proto.get("UDP", 0), "listening": listening,
                "unique_remote_ips": unique_ips, "blocked": blocked}


class EventRepository(_Repo):
    def add(self, data: dict) -> dict:
        with self.db.session_scope() as s:
            obj = SecurityEvent(**data)
            s.add(obj)
            s.flush()
            return row_dict(obj)

    def list(self, limit: int = 500, since: datetime | None = None, min_severity: str | None = None,
             event_type: str | None = None) -> list[dict]:
        stmt = select(SecurityEvent)
        if since:
            stmt = stmt.where(SecurityEvent.timestamp >= since)
        if min_severity:
            stmt = stmt.where(SecurityEvent.severity.in_(SEVERITIES[SEVERITIES.index(min_severity):]))
        if event_type:
            stmt = stmt.where(SecurityEvent.event_type == event_type)
        with self.db.session_scope() as s:
            return [row_dict(r) for r in s.scalars(stmt.order_by(SecurityEvent.id.desc()).limit(limit)).all()]

    def count(self, since: datetime, min_severity: str | None = None, suspicious_only: bool = False,
              status: str | None = None) -> int:
        stmt = select(func.count()).select_from(SecurityEvent).where(SecurityEvent.timestamp >= since)
        if min_severity:
            stmt = stmt.where(SecurityEvent.severity.in_(SEVERITIES[SEVERITIES.index(min_severity):]))
        if suspicious_only:
            stmt = stmt.where(SecurityEvent.event_type.in_(SUSPICIOUS_TYPES))
        if status:
            stmt = stmt.where(SecurityEvent.status == status)
        with self.db.session_scope() as s:
            return s.scalar(stmt) or 0

    def timeline(self, since: datetime, bucket_minutes: int = 5) -> list[tuple[str, int]]:
        with self.db.session_scope() as s:
            stamps = s.scalars(select(SecurityEvent.timestamp).where(SecurityEvent.timestamp >= since)
                               .limit(20000)).all()
        step, counter = bucket_minutes * 60, Counter()
        for ts in stamps:
            counter[int(ts.timestamp() // step) * step] += 1
        start, end = int(since.timestamp() // step) * step, int(datetime.now().timestamp() // step) * step
        return [(datetime.fromtimestamp(t).strftime("%H:%M"), counter.get(t, 0)) for t in range(start, end + step, step)]


class AlertRepository(_Repo):
    def add(self, data: dict) -> dict:
        with self.db.session_scope() as s:
            obj = Alert(**data)
            s.add(obj)
            s.flush()
            return row_dict(obj)

    def list(self, status: str | None = None, severity: str | None = None, limit: int = 1000) -> list[dict]:
        stmt = select(Alert)
        if status and status != "All":
            stmt = stmt.where(Alert.status == status)
        if severity and severity != "All":
            stmt = stmt.where(Alert.severity == severity)
        with self.db.session_scope() as s:
            return [row_dict(r) for r in s.scalars(stmt.order_by(Alert.id.desc()).limit(limit)).all()]

    def get_with_event(self, alert_id: int) -> dict | None:
        with self.db.session_scope() as s:
            alert = s.get(Alert, alert_id)
            if not alert:
                return None
            data = row_dict(alert)
            data["event"] = row_dict(alert.event) if alert.event else None
            return data

    def set_status(self, alert_id: int, status: str) -> None:
        with self.db.session_scope() as s:
            alert = s.get(Alert, alert_id)
            if alert:
                alert.status = status
                if alert.event:
                    alert.event.status = {"Acknowledged": "Acknowledged", "Dismissed": "Dismissed",
                                          "Confirmed": "Confirmed"}.get(status, alert.event.status)

    def counts(self) -> dict:
        with self.db.session_scope() as s:
            return dict(s.execute(select(Alert.status, func.count()).group_by(Alert.status)).all())

    def count_new(self) -> int:
        return self.counts().get("New", 0)


class RuleRepository(_Repo):
    def add(self, data: dict) -> dict:
        now = datetime.now()
        try:
            with self.db.session_scope() as s:
                obj = FirewallRule(**{**data, "created_at": now, "updated_at": now})
                s.add(obj)
                s.flush()
                return row_dict(obj)
        except IntegrityError:
            raise DuplicateRuleError(f"A rule named {data['rule_name']} already exists") from None

    def get(self, name: str) -> dict | None:
        with self.db.session_scope() as s:
            obj = s.scalar(select(FirewallRule).where(FirewallRule.rule_name == name))
            return row_dict(obj) if obj else None

    def list(self, search: str | None = None) -> list[dict]:
        stmt = select(FirewallRule)
        if search:
            stmt = stmt.where(FirewallRule.rule_name.icontains(search, autoescape=True))
        with self.db.session_scope() as s:
            return [row_dict(r) for r in s.scalars(stmt.order_by(FirewallRule.id.desc())).all()]

    def list_enabled(self) -> list[dict]:
        with self.db.session_scope() as s:
            return [row_dict(r) for r in s.scalars(select(FirewallRule).where(FirewallRule.enabled.is_(True))).all()]

    def set_enabled(self, name: str, enabled: bool) -> None:
        with self.db.session_scope() as s:
            obj = s.scalar(select(FirewallRule).where(FirewallRule.rule_name == name))
            if obj:
                obj.enabled, obj.updated_at = enabled, datetime.now()

    def delete(self, name: str) -> None:
        with self.db.session_scope() as s:
            obj = s.scalar(select(FirewallRule).where(FirewallRule.rule_name == name))
            if obj:
                s.execute(Connection.__table__.update().where(Connection.rule_id == obj.id).values(rule_id=None))
                s.execute(SecurityEvent.__table__.update().where(SecurityEvent.rule_id == obj.id).values(rule_id=None))
                s.delete(obj)


class ProcessRepository(_Repo):
    def known_names(self) -> set[str]:
        with self.db.session_scope() as s:
            return set(s.scalars(select(Process.name)).all())

    def upsert_many(self, items: list[dict]) -> dict:
        """items: {name, exe_path, pid, connection_count}. Returns {(name, exe_path): id}."""
        now, ids = datetime.now(), {}
        with self.db.session_scope() as s:
            existing = {(p.name, p.exe_path): p for p in s.scalars(select(Process)).all()}
            for it in items:
                key = (it["name"], it["exe_path"])
                obj = existing.get(key)
                if obj is None:
                    obj = Process(name=it["name"], exe_path=it["exe_path"], pid=it.get("pid"), first_seen=now,
                                  last_seen=now, connection_count=it["connection_count"])
                    s.add(obj)
                    existing[key] = obj
                else:
                    obj.last_seen, obj.pid, obj.connection_count = now, it.get("pid"), it["connection_count"]
            s.flush()
            ids = {k: v.id for k, v in existing.items()}
        return ids

    def list(self) -> list[dict]:
        with self.db.session_scope() as s:
            return [row_dict(p) for p in s.scalars(select(Process).order_by(Process.last_seen.desc())).all()]

    def set_signature(self, name: str, exe_path: str, status: str, publisher: str, trust: str) -> None:
        with self.db.session_scope() as s:
            obj = s.scalar(select(Process).where(Process.name == name, Process.exe_path == exe_path))
            if obj:
                obj.signature_status, obj.publisher, obj.trust = status, publisher, trust


class InterfaceRepository(_Repo):
    def replace_all(self, rows: list[dict]) -> None:
        now = datetime.now()
        with self.db.session_scope() as s:
            s.execute(delete(NetworkInterface))
            for r in rows:
                s.add(NetworkInterface(updated_at=now, **{k: r[k] for k in (
                    "name", "mac", "ipv4", "ipv6", "status", "bytes_sent", "bytes_recv", "packets_sent", "packets_recv")}))

    def list(self) -> list[dict]:
        with self.db.session_scope() as s:
            return [row_dict(r) for r in s.scalars(select(NetworkInterface)).all()]


class AuditRepository(_Repo):
    def add(self, action: str, details: str = "", result: str = "Success", user: str | None = None) -> None:
        try:
            user = user or getpass.getuser()
        except Exception:
            user = "unknown"
        with self.db.session_scope() as s:
            s.add(AuditLog(action=action, details=details[:2000], result=result, user=user))

    def list(self, limit: int = 500) -> list[dict]:
        with self.db.session_scope() as s:
            return [row_dict(r) for r in s.scalars(select(AuditLog).order_by(AuditLog.id.desc()).limit(limit)).all()]


class SettingsRepository(_Repo):
    def get_all(self) -> dict:
        with self.db.session_scope() as s:
            return {r.key: r.value for r in s.scalars(select(Setting)).all()}

    def set_many(self, values: dict) -> None:
        with self.db.session_scope() as s:
            for k, v in values.items():
                obj = s.get(Setting, k)
                if obj:
                    obj.value, obj.updated_at = str(v), datetime.now()
                else:
                    s.add(Setting(key=k, value=str(v)))

    def reset(self) -> None:
        with self.db.session_scope() as s:
            s.execute(delete(Setting))


class ReportRepository(_Repo):
    def add(self, title: str, fmt: str, period: str, path: str) -> None:
        with self.db.session_scope() as s:
            s.add(Report(title=title, format=fmt, period=period, path=path))

    def list(self, limit: int = 200) -> list[dict]:
        with self.db.session_scope() as s:
            return [row_dict(r) for r in s.scalars(select(Report).order_by(Report.id.desc()).limit(limit)).all()]


class Repos:
    """Bundle of all repositories sharing one Database."""

    def __init__(self, db: Database):
        self.db = db
        self.connections = ConnectionRepository(db)
        self.events = EventRepository(db)
        self.alerts = AlertRepository(db)
        self.rules = RuleRepository(db)
        self.processes = ProcessRepository(db)
        self.interfaces = InterfaceRepository(db)
        self.audit = AuditRepository(db)
        self.settings = SettingsRepository(db)
        self.reports = ReportRepository(db)
