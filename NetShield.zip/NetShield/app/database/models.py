"""SQLAlchemy ORM models for NetShield."""
from __future__ import annotations

from datetime import datetime

from sqlalchemy import Boolean, DateTime, ForeignKey, Index, Integer, String, Text, UniqueConstraint
from sqlalchemy.orm import DeclarativeBase, Mapped, mapped_column, relationship


class Base(DeclarativeBase):
    pass


class NetworkInterface(Base):
    __tablename__ = "network_interfaces"
    id: Mapped[int] = mapped_column(primary_key=True)
    name: Mapped[str] = mapped_column(String(128), unique=True)
    mac: Mapped[str] = mapped_column(String(64), default="")
    ipv4: Mapped[str] = mapped_column(String(64), default="")
    ipv6: Mapped[str] = mapped_column(String(64), default="")
    status: Mapped[str] = mapped_column(String(32), default="")
    bytes_sent: Mapped[int] = mapped_column(Integer, default=0)
    bytes_recv: Mapped[int] = mapped_column(Integer, default=0)
    packets_sent: Mapped[int] = mapped_column(Integer, default=0)
    packets_recv: Mapped[int] = mapped_column(Integer, default=0)
    updated_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.now)


class Process(Base):
    __tablename__ = "processes"
    __table_args__ = (UniqueConstraint("name", "exe_path"),)
    id: Mapped[int] = mapped_column(primary_key=True)
    name: Mapped[str] = mapped_column(String(260), index=True)
    exe_path: Mapped[str] = mapped_column(String(520), default="")
    pid: Mapped[int | None] = mapped_column(Integer, nullable=True)
    first_seen: Mapped[datetime] = mapped_column(DateTime, default=datetime.now)
    last_seen: Mapped[datetime] = mapped_column(DateTime, default=datetime.now)
    connection_count: Mapped[int] = mapped_column(Integer, default=0)
    signature_status: Mapped[str] = mapped_column(String(64), default="")
    publisher: Mapped[str] = mapped_column(String(260), default="")
    trust: Mapped[str] = mapped_column(String(128), default="")
    connections: Mapped[list["Connection"]] = relationship(back_populates="process_ref")


class FirewallRule(Base):
    __tablename__ = "firewall_rules"
    id: Mapped[int] = mapped_column(primary_key=True)
    rule_name: Mapped[str] = mapped_column(String(80), unique=True)
    direction: Mapped[str] = mapped_column(String(16))
    action: Mapped[str] = mapped_column(String(16))
    protocol: Mapped[str] = mapped_column(String(16), default="Any")
    local_port: Mapped[str] = mapped_column(String(128), default="")
    remote_port: Mapped[str] = mapped_column(String(128), default="")
    local_ip: Mapped[str] = mapped_column(String(256), default="")
    remote_ip: Mapped[str] = mapped_column(String(256), default="")
    program_path: Mapped[str] = mapped_column(String(520), default="")
    profile: Mapped[str] = mapped_column(String(64), default="Any")
    enabled: Mapped[bool] = mapped_column(Boolean, default=True)
    description: Mapped[str] = mapped_column(Text, default="")
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.now)
    updated_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.now)
    connections: Mapped[list["Connection"]] = relationship(back_populates="rule_ref")
    events: Mapped[list["SecurityEvent"]] = relationship(back_populates="rule_ref")


class Connection(Base):
    __tablename__ = "connections"
    __table_args__ = (Index("ix_conn_remote", "remote_ip", "remote_port"),)
    id: Mapped[int] = mapped_column(primary_key=True)
    timestamp: Mapped[datetime] = mapped_column(DateTime, default=datetime.now, index=True)
    process_name: Mapped[str] = mapped_column(String(260), index=True, default="")
    pid: Mapped[int | None] = mapped_column(Integer, nullable=True)
    local_ip: Mapped[str] = mapped_column(String(64), default="")
    local_port: Mapped[int] = mapped_column(Integer, default=0)
    remote_ip: Mapped[str] = mapped_column(String(64), index=True, default="")
    remote_port: Mapped[int] = mapped_column(Integer, index=True, default=0)
    protocol: Mapped[str] = mapped_column(String(16), index=True, default="")
    status: Mapped[str] = mapped_column(String(32), default="")
    action: Mapped[str] = mapped_column(String(16), default="Observed")
    rule: Mapped[str] = mapped_column(String(80), default="")
    risk_level: Mapped[str] = mapped_column(String(16), default="Normal")
    process_id: Mapped[int | None] = mapped_column(ForeignKey("processes.id"), nullable=True)
    rule_id: Mapped[int | None] = mapped_column(ForeignKey("firewall_rules.id"), nullable=True)
    process_ref: Mapped["Process | None"] = relationship(back_populates="connections")
    rule_ref: Mapped["FirewallRule | None"] = relationship(back_populates="connections")


class SecurityEvent(Base):
    __tablename__ = "security_events"
    id: Mapped[int] = mapped_column(primary_key=True)
    timestamp: Mapped[datetime] = mapped_column(DateTime, default=datetime.now, index=True)
    event_type: Mapped[str] = mapped_column(String(48), index=True)
    severity: Mapped[str] = mapped_column(String(16), index=True)
    process: Mapped[str] = mapped_column(String(260), default="")
    source_ip: Mapped[str] = mapped_column(String(64), default="")
    destination_ip: Mapped[str] = mapped_column(String(64), default="")
    port: Mapped[int] = mapped_column(Integer, default=0)
    protocol: Mapped[str] = mapped_column(String(16), default="")
    description: Mapped[str] = mapped_column(Text, default="")
    status: Mapped[str] = mapped_column(String(24), default="Open")
    rule_id: Mapped[int | None] = mapped_column(ForeignKey("firewall_rules.id"), nullable=True)
    rule_ref: Mapped["FirewallRule | None"] = relationship(back_populates="events")
    alerts: Mapped[list["Alert"]] = relationship(back_populates="event")


class Alert(Base):
    __tablename__ = "alerts"
    id: Mapped[int] = mapped_column(primary_key=True)
    timestamp: Mapped[datetime] = mapped_column(DateTime, default=datetime.now, index=True)
    severity: Mapped[str] = mapped_column(String(16), index=True)
    title: Mapped[str] = mapped_column(String(200))
    message: Mapped[str] = mapped_column(Text, default="")
    status: Mapped[str] = mapped_column(String(24), default="New", index=True)
    event_id: Mapped[int | None] = mapped_column(ForeignKey("security_events.id"), nullable=True)
    event: Mapped["SecurityEvent | None"] = relationship(back_populates="alerts")


class Report(Base):
    __tablename__ = "reports"
    id: Mapped[int] = mapped_column(primary_key=True)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.now, index=True)
    title: Mapped[str] = mapped_column(String(200))
    format: Mapped[str] = mapped_column(String(16))
    period: Mapped[str] = mapped_column(String(32), default="")
    path: Mapped[str] = mapped_column(String(520))


class Setting(Base):
    __tablename__ = "settings"
    key: Mapped[str] = mapped_column(String(64), primary_key=True)
    value: Mapped[str] = mapped_column(Text, default="")
    updated_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.now)


class AuditLog(Base):
    __tablename__ = "audit_logs"
    id: Mapped[int] = mapped_column(primary_key=True)
    timestamp: Mapped[datetime] = mapped_column(DateTime, default=datetime.now, index=True)
    action: Mapped[str] = mapped_column(String(80), index=True)
    user: Mapped[str] = mapped_column(String(80), default="")
    details: Mapped[str] = mapped_column(Text, default="")
    result: Mapped[str] = mapped_column(String(24), default="Success")
