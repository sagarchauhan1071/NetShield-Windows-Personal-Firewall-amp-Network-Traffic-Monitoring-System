"""Application context: wires database, repositories, services and settings together."""
from __future__ import annotations

from dataclasses import dataclass

from app.core.firewall import FirewallManager
from app.core.tools import is_admin
from app.database.database import Database
from app.database.repositories import Repos
from app.services.connection_service import MonitoringService
from app.services.firewall_service import FirewallService
from app.services.report_service import ReportService
from config import DB_PATH, default_settings, validate_settings


@dataclass
class AppContext:
    db: Database
    repos: Repos
    settings: dict
    fw_manager: FirewallManager
    fw_service: FirewallService
    monitor: MonitoringService
    reports: ReportService
    admin: bool

    def apply_settings(self, new: dict) -> None:
        self.settings.clear()
        self.settings.update(new)
        self.monitor.update_settings(self.settings)


def load_settings(repos: Repos) -> dict:
    stored = repos.settings.get_all()
    clean, _errors = validate_settings(stored) if stored else (default_settings(), [])
    return clean


def create_context(db_path=None) -> AppContext:
    db = Database(db_path or DB_PATH)
    db.init_db()
    repos = Repos(db)
    settings = load_settings(repos)
    manager = FirewallManager()
    monitor = MonitoringService(repos, settings, manager)
    reports = ReportService(repos, settings, lambda: monitor.last_firewall_status or manager.get_status())
    return AppContext(db, repos, settings, manager, FirewallService(repos, manager), monitor, reports, is_admin())
