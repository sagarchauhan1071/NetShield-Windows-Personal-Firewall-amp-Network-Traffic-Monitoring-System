# 13 – User Manual
**Start**: `python main.py` (right-click terminal → *Run as administrator* for rule management).
**Dashboard**: cards (active, established, listening, blocked, alerts, suspicious) and six charts. A red banner appears if the firewall is off.
**Monitor**: Start / Pause / Stop / Clear View; search box, protocol and state filters; *History* tab for logged connections with filters (date, process, IP, port, protocol, action, risk) and paging; *Create Firewall Rule from Selection…*.
**Firewall**: per-profile status (Domain/Private/Public) and Refresh.
**Rules**: New Rule…, View, Enable, Disable, Delete – each change shows the effect and asks for confirmation.
**Alerts**: Acknowledge, Dismiss, View Details, Mark Confirmed (manual analyst decision).
**Processes**: per-process connections, remote IPs/ports, first/last seen, *Verify Signature/Publisher*, *Resolve Hostnames* (DNS only on click).
**Interfaces**, **Statistics** (5 min / hour / today / 7 days), **Packets** (import .pcap/.pcapng, open Wireshark, optional TShark lab capture), **Reports** (PDF/HTML/CSV/JSON), **Settings** (Save / Reset / Test Configuration, tool detection).
Remember: *Suspicious activity does not necessarily indicate malicious activity. Manual investigation is required.*
