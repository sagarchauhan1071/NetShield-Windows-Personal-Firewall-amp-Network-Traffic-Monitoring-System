# 01 – Project Overview
**NetShield – Windows Personal Firewall & Network Traffic Monitoring System** (v1.0, Defensive Network Security Platform)

NetShield is a Windows 10/11 desktop application (Python 3.11+, PySide6) that monitors network connections in real time, maps them to processes, logs them to SQLite, applies transparent rule-based detection, raises alerts, manages Windows Defender Firewall rules through a confirmed and audited workflow, and produces PDF/HTML/CSV/JSON reports.

It is a **management, monitoring and analysis layer**. Enforcement is always performed by Windows Defender Firewall. No AI/ML is used. It is intended for the user's own computer or authorized lab environments.
