# 11 – Limitations
1. NetShield is not a replacement for Windows Defender Firewall.
2. It is not a kernel-level firewall and does not intercept packets.
3. Some information needs Administrator privileges (process paths of protected processes, rule management).
4. Process-to-connection mapping on Windows can be incomplete (short-lived sockets, protected processes, PID reuse).
5. Packet capture needs extra permissions/tools (Npcap, TShark).
6. Suspicious activity does not equal confirmed malware – rules produce indicators only.
7. Firewall rules are enforced by Windows; "Blocked" in NetShield means an observed connection matched an enabled NetShield block rule in a non-established state (true drops are visible in the Windows Filtering Platform audit log, which is not read in v1.0).
8. Wireshark is an optional external tool; the built-in PCAP parser is a summary tool, not a Wireshark replacement.
9. Inbound/outbound direction of an existing connection is inferred from listening ports.
10. Developed and unit-tested with cross-platform logic; live firewall integration must be validated on a Windows machine.
