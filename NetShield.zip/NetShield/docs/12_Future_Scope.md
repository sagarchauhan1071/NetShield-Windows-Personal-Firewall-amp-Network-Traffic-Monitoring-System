# 12 – Future Scope
SIEM integration, e-mail alerts, syslog, enterprise policy management, remote monitoring, topology visualization, deeper protocol analysis, Windows Event Log / WFP audit (event 5157) integration for true drop counts, threat-intelligence integration (opt-in), IPv6 improvements, multi-user access, RBAC. No AI/ML unless explicitly requested.
