# 03 – Objectives
1. Real-time connection monitoring without freezing the GUI.
2. Process-to-network mapping (process, PID, path, remote IPs/ports).
3. Safe management of Windows Defender Firewall rules (show, explain, confirm, log).
4. Connection and security-event logging with search, filters and pagination.
5. Transparent rule-based detection and an alert workflow (acknowledge / dismiss / details).
6. Statistics, interface information and optional PCAP/Wireshark integration.
7. Professional reports with careful language (Observed / Blocked / Suspicious / Confirmed).
8. Secure engineering: validation, argument-list subprocesses, parameterised SQL, audit log, tests.
