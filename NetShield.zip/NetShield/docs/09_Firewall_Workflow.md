# 09 – Firewall Workflow
1. User fills the rule form (or starts from a selected connection).
2. `validate_rule` normalises every field (name, IP/CIDR/range, port list/range, `.exe` path, profile, protocol).
3. NetShield shows the rule **and its effect**; the user must confirm.
4. Administrator check; if absent: "Administrator privileges are required for firewall rule management."
5. `netsh advfirewall firewall add rule …` runs with an **argument list, shell=False**.
6. Only on success the rule is saved to SQLite, an audit record and a "Firewall Rule Change" event/alert are written.
7. Delete/enable/disable work only for rules prefixed `NetShield_` that exist in NetShield's database.
NetShield never disables the firewall, never creates hidden rules, and never persists anything outside its own data folder.
