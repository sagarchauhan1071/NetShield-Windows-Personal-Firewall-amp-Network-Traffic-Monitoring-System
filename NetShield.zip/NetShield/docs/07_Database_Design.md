# 07 – Database Design (SQLite, `data/netshield.db`)
Tables: `network_interfaces`, `connections`, `firewall_rules`, `security_events`, `alerts`, `processes`, `reports`, `settings`, `audit_logs`.

Relationships: `connections.process_id → processes.id`; `connections.rule_id → firewall_rules.id`; `security_events.rule_id → firewall_rules.id`; `alerts.event_id → security_events.id`.

Indexes: `connections(timestamp, process_name, remote_ip, remote_port, protocol, (remote_ip,remote_port))`, `security_events(timestamp, event_type, severity)`, `alerts(timestamp, severity, status)`, `audit_logs(timestamp, action)`, `processes(name)`.

`firewall_rules` holds NetShield-managed rule metadata only; live Windows state is queried separately. Growth control: only *new* connections are logged (not every poll), retention cleanup and size cap with VACUUM run hourly, UI row limits and pagination.
