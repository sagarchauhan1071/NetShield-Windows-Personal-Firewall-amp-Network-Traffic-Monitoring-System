# 05 – Module Description
| Module | Responsibility |
|---|---|
| `core/monitor.py` | psutil connection collection, process cache, interface info |
| `core/firewall.py` | firewall status, netsh argument builders, rule/connection matching, admin gate |
| `core/analyzer.py` | 9 transparent detection rules, severity classification |
| `core/alerts.py` | de-duplication (cool-down), event + alert persistence |
| `core/tools.py` | admin, Windows version, Python/Wireshark/TShark detection |
| `services/connection_service.py` | one monitoring cycle: collect → match → analyze → alert → log |
| `services/firewall_service.py` | validate → preview → confirm → apply → store → audit |
| `services/report_service.py` | 13-section report in PDF/HTML/CSV/JSON |
| `services/pcapture_service.py` | built-in pcap/pcapng parser, Wireshark/TShark launchers |
| `ui/*` | Dashboard, Monitor, Firewall, Rules, Alerts, Processes, Interfaces, Packets, Statistics, Reports, Settings |

Detection rules: repeated connections; new listening ports; connections matching block rules; connection bursts; new applications; unusual/watch-listed destination ports; unidentified processes; firewall status/config changes. All are **indicators, not proof**.
