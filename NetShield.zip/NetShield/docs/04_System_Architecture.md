# 04 – System Architecture
```
Windows OS ── NetShield ─┬─ Network Monitor (psutil) ── Connection Collector
                         └─ Firewall Manager (netsh / PowerShell) ── Allow/Block Rules (Windows enforces)
          Collector + Rule matcher ─▶ Event Logger (SQLite) ─▶ Security Analyzer ─▶ Alerts ─▶ Dashboard ─▶ Reports
```
Layers: `app/core` (collector, firewall, analyzer, alerts, tools – no Qt), `app/database` (SQLAlchemy models, repositories), `app/services` (monitoring cycle, firewall workflow, reports, PCAP), `app/ui` (PySide6 views, widgets, QThread worker), `app/context.py` (wiring).

Threading: `MonitorThread (QThread)` runs `MonitoringService.run_cycle()` every N seconds and emits a signal; the GUI only renders. Long one-off tasks (firewall queries, reports, PCAP import, signature checks) use `run_async` on the Qt thread pool and call back on the GUI thread. Pause/Stop use `threading.Event`, so there are no uncontrolled loops.
