# 08 – Network Workflow
Initialize → check Windows environment → check firewall → detect interfaces → start monitoring → collect connections (`psutil.net_connections`) → map PID to process name/path → match against NetShield rules → apply detection rules → de-duplicate and raise alerts → log new connections → update dashboard → user reviews → (optional) rule → report.
A connection is logged once when first seen; state changes are reflected live but not re-logged.
